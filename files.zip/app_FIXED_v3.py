from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime, timedelta, date
import os
import random
import re
import uuid
from werkzeug.utils import secure_filename
import json

# Import Irish school calendar for streak tracking
try:
    from irish_school_calendar import (
        is_school_day, is_consecutive_school_day, should_reset_streak,
        get_streak_milestone, get_next_milestone, STREAK_MILESTONES
    )
    IRISH_CALENDAR_ENABLED = True
except ImportError:
    IRISH_CALENDAR_ENABLED = False
    print("Warning: irish_school_calendar.py not found - using simple streak logic")

app = Flask(__name__)

# ==================== FEATURE FLAGS ====================
# Avatar system can be disabled instantly by setting these to False
# Set via environment variables or change defaults here
FEATURE_FLAGS = {
    'AVATAR_SYSTEM_ENABLED': os.environ.get('AVATAR_SYSTEM_ENABLED', 'false').lower() == 'true',
    'AVATAR_SHOP_ENABLED': os.environ.get('AVATAR_SHOP_ENABLED', 'false').lower() == 'true',
    'AVATAR_ON_QUIZ_ENABLED': os.environ.get('AVATAR_ON_QUIZ_ENABLED', 'false').lower() == 'true',
    'AVATAR_ON_LEADERBOARD_ENABLED': os.environ.get('AVATAR_ON_LEADERBOARD_ENABLED', 'false').lower() == 'true',
    'PRIZE_SYSTEM_ENABLED': os.environ.get('PRIZE_SYSTEM_ENABLED', 'false').lower() == 'true',
}

def get_feature_flag(flag_name):
    """Get a feature flag value"""
    return FEATURE_FLAGS.get(flag_name, False)
app.secret_key = os.environ.get('SECRET_KEY', 'your-secret-key-change-this-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mathquiz.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Session configuration for guest mode
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_COOKIE_SECURE'] = False  # Set to True in production with HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'


# ==================== WHO AM I CONFIGURATION ====================
UPLOAD_FOLDER = 'static/who_am_i_images'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

db = SQLAlchemy(app)

# ==================== TEMPLATE CONTEXT PROCESSOR ====================
@app.context_processor
def inject_feature_flags():
    """Make feature flags available in all templates"""
    return {
        'feature_flags': FEATURE_FLAGS,
        'avatar_enabled': FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False)
    }

# ==================== DATABASE MODELS ====================

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'student', 'teacher', 'admin'
    is_approved = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    quiz_attempts = db.relationship('QuizAttempt', backref='user', lazy=True)
    classes_enrolled = db.relationship('ClassEnrollment', backref='student', lazy=True)
    classes_teaching = db.relationship('Class', backref='teacher', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'full_name': self.full_name,
            'role': self.role,
            'is_approved': self.is_approved,
            'created_at': self.created_at.isoformat()
        }

class Class(db.Model):
    __tablename__ = 'classes'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    teacher_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    enrollments = db.relationship('ClassEnrollment', backref='class_obj', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'teacher_id': self.teacher_id,
            'teacher_name': self.teacher.full_name if self.teacher else None,
            'student_count': len(self.enrollments),
            'created_at': self.created_at.isoformat()
        }

class ClassEnrollment(db.Model):
    __tablename__ = 'class_enrollments'
    id = db.Column(db.Integer, primary_key=True)
    class_id = db.Column(db.Integer, db.ForeignKey('classes.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    enrolled_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (db.UniqueConstraint('class_id', 'student_id', name='unique_enrollment'),)

class Question(db.Model):
    __tablename__ = 'questions'
    id = db.Column(db.Integer, primary_key=True)
    topic = db.Column(db.String(50), nullable=False)
    difficulty = db.Column(db.String(20), nullable=False)
    question_text = db.Column(db.Text, nullable=False)
    option_a = db.Column(db.String(100), nullable=False)
    option_b = db.Column(db.String(100), nullable=False)
    option_c = db.Column(db.String(100), nullable=False)
    option_d = db.Column(db.String(100), nullable=False)
    correct_answer = db.Column(db.Integer, nullable=False)
    explanation = db.Column(db.Text, nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'topic': self.topic,
            'difficulty': self.difficulty,
            'question': self.question_text,
            'options': [self.option_a, self.option_b, self.option_c, self.option_d],
            'correct': self.correct_answer,
            'explanation': self.explanation
        }

class QuestionFlag(db.Model):
    """Track user-reported issues with questions - supports both registered and guest users"""
    __tablename__ = 'question_flags'
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('questions.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)  # Now nullable for guests
    guest_identifier = db.Column(db.String(100), nullable=True)  # For guest users
    guest_email = db.Column(db.String(120), nullable=True)  # Optional guest email
    flag_type = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')
    admin_notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at = db.Column(db.DateTime)
    resolved_by = db.Column(db.Integer, db.ForeignKey('users.id'))

    question = db.relationship('Question', backref='flags')
    reporter = db.relationship('User', foreign_keys=[user_id], backref='flags_reported')
    resolver = db.relationship('User', foreign_keys=[resolved_by], backref='flags_resolved')

    def to_dict(self):
        # Determine reporter name
        if self.user_id:
            reporter_name = self.reporter.full_name if self.reporter else 'Unknown User'
        else:
            reporter_name = f"Guest ({self.guest_identifier or 'Anonymous'})"

        return {
            'id': self.id,
            'question_id': self.question_id,
            'user_id': self.user_id,
            'user_name': reporter_name,
            'guest_email': self.guest_email,
            'flag_type': self.flag_type,
            'description': self.description,
            'status': self.status,
            'admin_notes': self.admin_notes,
            'created_at': self.created_at.isoformat(),
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'resolver_name': self.resolver.full_name if self.resolver else None
        }

class QuestionEdit(db.Model):
    """Track all edits made to questions"""
    __tablename__ = 'question_edits'
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('questions.id'), nullable=False)
    edited_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    edit_type = db.Column(db.String(50), nullable=False)

    old_question_text = db.Column(db.Text)
    old_option_a = db.Column(db.String(100))
    old_option_b = db.Column(db.String(100))
    old_option_c = db.Column(db.String(100))
    old_option_d = db.Column(db.String(100))
    old_correct_answer = db.Column(db.Integer)
    old_explanation = db.Column(db.Text)

    new_question_text = db.Column(db.Text)
    new_option_a = db.Column(db.String(100))
    new_option_b = db.Column(db.String(100))
    new_option_c = db.Column(db.String(100))
    new_option_d = db.Column(db.String(100))
    new_correct_answer = db.Column(db.Integer)
    new_explanation = db.Column(db.Text)

    edit_notes = db.Column(db.Text)
    edited_at = db.Column(db.DateTime, default=datetime.utcnow)

    question = db.relationship('Question', backref='edit_history')
    editor = db.relationship('User', backref='question_edits')

    def to_dict(self):
        changes = {}
        if self.old_question_text != self.new_question_text:
            changes['question_text'] = {'old': self.old_question_text, 'new': self.new_question_text}
        if self.old_option_a != self.new_option_a:
            changes['option_a'] = {'old': self.old_option_a, 'new': self.new_option_a}
        if self.old_option_b != self.new_option_b:
            changes['option_b'] = {'old': self.old_option_b, 'new': self.new_option_b}
        if self.old_option_c != self.new_option_c:
            changes['option_c'] = {'old': self.old_option_c, 'new': self.new_option_c}
        if self.old_option_d != self.new_option_d:
            changes['option_d'] = {'old': self.old_option_d, 'new': self.new_option_d}
        if self.old_correct_answer != self.new_correct_answer:
            changes['correct_answer'] = {'old': self.old_correct_answer, 'new': self.new_correct_answer}
        if self.old_explanation != self.new_explanation:
            changes['explanation'] = {'old': self.old_explanation, 'new': self.new_explanation}

        return {
            'id': self.id,
            'question_id': self.question_id,
            'edited_by': self.editor.full_name,
            'edit_type': self.edit_type,
            'edit_notes': self.edit_notes,
            'edited_at': self.edited_at.isoformat(),
            'changes': changes
        }

class QuizAttempt(db.Model):
    __tablename__ = 'quiz_attempts'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    topic = db.Column(db.String(50), nullable=False)
    difficulty = db.Column(db.String(20), nullable=False)
    score = db.Column(db.Integer, nullable=False)
    total_questions = db.Column(db.Integer, nullable=False)
    percentage = db.Column(db.Float, nullable=False)
    time_taken = db.Column(db.Integer)  # seconds
    completed_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'user_name': self.user.full_name,
            'topic': self.topic,
            'difficulty': self.difficulty,
            'score': self.score,
            'total_questions': self.total_questions,
            'percentage': self.percentage,
            'time_taken': self.time_taken,
            'completed_at': self.completed_at.isoformat()
        }

# ==================== BADGES & PROGRESS TRACKING MODELS ====================

class Badge(db.Model):
    """Badge definitions"""
    __tablename__ = 'badges'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text, nullable=False)
    icon = db.Column(db.String(50), nullable=False)
    category = db.Column(db.String(50), nullable=False)  # beginner, progress, accuracy, streak, mastery
    requirement_type = db.Column(db.String(50), nullable=False)
    requirement_value = db.Column(db.Integer, nullable=False)
    points = db.Column(db.Integer, default=10)
    color = db.Column(db.String(50), default='blue')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'icon': self.icon,
            'category': self.category,
            'requirement_type': self.requirement_type,
            'requirement_value': self.requirement_value,
            'points': self.points,
            'color': self.color
        }

class UserBadge(db.Model):
    """Tracks badges earned by users"""
    __tablename__ = 'user_badges'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    badge_id = db.Column(db.Integer, db.ForeignKey('badges.id'), nullable=False)
    earned_at = db.Column(db.DateTime, default=datetime.utcnow)
    progress = db.Column(db.Integer, default=0)

    __table_args__ = (db.UniqueConstraint('user_id', 'badge_id', name='unique_user_badge'),)

    badge = db.relationship('Badge', backref='earned_by')
    user = db.relationship('User', backref='earned_badges')

    def to_dict(self):
        return {
            'id': self.id,
            'badge': self.badge.to_dict(),
            'earned_at': self.earned_at.isoformat(),
            'progress': self.progress
        }

class UserStats(db.Model):
    """Overall user statistics and progress"""
    __tablename__ = 'user_stats'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)
    total_quizzes = db.Column(db.Integer, default=0)
    total_questions_answered = db.Column(db.Integer, default=0)
    total_correct_answers = db.Column(db.Integer, default=0)
    current_streak_days = db.Column(db.Integer, default=0)
    longest_streak_days = db.Column(db.Integer, default=0)
    last_quiz_date = db.Column(db.Date)
    total_points = db.Column(db.Integer, default=0)
    level = db.Column(db.Integer, default=1)
    topics_mastered = db.Column(db.Integer, default=0)
    perfect_scores = db.Column(db.Integer, default=0)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref='stats', uselist=False)

    def to_dict(self):
        overall_accuracy = 0
        if self.total_questions_answered > 0:
            overall_accuracy = round((self.total_correct_answers / self.total_questions_answered) * 100, 1)

        return {
            'id': self.id,
            'user_id': self.user_id,
            'total_quizzes': self.total_quizzes,
            'total_questions_answered': self.total_questions_answered,
            'total_correct_answers': self.total_correct_answers,
            'overall_accuracy': overall_accuracy,
            'current_streak_days': self.current_streak_days,
            'longest_streak_days': self.longest_streak_days,
            'last_quiz_date': self.last_quiz_date.isoformat() if self.last_quiz_date else None,
            'total_points': self.total_points,
            'level': self.level,
            'topics_mastered': self.topics_mastered,
            'perfect_scores': self.perfect_scores,
            'updated_at': self.updated_at.isoformat()
        }

# ==================== AVATAR SYSTEM MODELS ====================
# These models support the avatar customization feature
# BACKOUT: Set AVATAR_SYSTEM_ENABLED=false to disable without removing code

class AvatarItem(db.Model):
    """Shop items - animals, hats, glasses, backgrounds, accessories"""
    __tablename__ = 'avatar_items'

    id = db.Column(db.Integer, primary_key=True)
    item_type = db.Column(db.String(50), nullable=False)  # 'animal', 'hat', 'glasses', 'background', 'accessory'
    item_key = db.Column(db.String(50), nullable=False)   # 'panda', 'crown', etc.
    display_name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    point_cost = db.Column(db.Integer, nullable=False, default=0)
    rarity = db.Column(db.String(20), default='common')  # 'common', 'rare', 'epic', 'legendary'
    is_default = db.Column(db.Boolean, default=False)    # Free starter items
    is_active = db.Column(db.Boolean, default=True)      # Can hide items without deleting
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (db.UniqueConstraint('item_type', 'item_key', name='unique_item_type_key'),)

    def to_dict(self):
        return {
            'id': self.id,
            'item_type': self.item_type,
            'item_key': self.item_key,
            'display_name': self.display_name,
            'description': self.description,
            'point_cost': self.point_cost,
            'rarity': self.rarity,
            'is_default': self.is_default,
            'is_active': self.is_active,
            'sort_order': self.sort_order
        }

class UserAvatarInventory(db.Model):
    """Tracks which items users/guests have purchased"""
    __tablename__ = 'user_avatar_inventory'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    guest_code = db.Column(db.String(50), nullable=True)
    item_id = db.Column(db.Integer, db.ForeignKey('avatar_items.id'), nullable=False)
    purchased_at = db.Column(db.DateTime, default=datetime.utcnow)

    item = db.relationship('AvatarItem', backref='purchases')

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'guest_code': self.guest_code,
            'item': self.item.to_dict() if self.item else None,
            'purchased_at': self.purchased_at.isoformat() if self.purchased_at else None
        }

class UserAvatarEquipped(db.Model):
    """Tracks currently equipped avatar configuration"""
    __tablename__ = 'user_avatar_equipped'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    guest_code = db.Column(db.String(50), nullable=True)
    animal_key = db.Column(db.String(50), default='panda')
    hat_key = db.Column(db.String(50), default='none')
    glasses_key = db.Column(db.String(50), default='none')
    background_key = db.Column(db.String(50), default='none')
    accessory_key = db.Column(db.String(50), default='none')
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'user_id': self.user_id,
            'guest_code': self.guest_code,
            'animal': self.animal_key,
            'hat': self.hat_key,
            'glasses': self.glasses_key,
            'background': self.background_key,
            'accessory': self.accessory_key,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class AvatarPurchaseLog(db.Model):
    """Audit log for all purchases - useful for debugging and potential refunds"""
    __tablename__ = 'avatar_purchase_log'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=True)
    guest_code = db.Column(db.String(50), nullable=True)
    item_id = db.Column(db.Integer, db.ForeignKey('avatar_items.id'), nullable=False)
    points_spent = db.Column(db.Integer, nullable=False)
    points_before = db.Column(db.Integer, nullable=False)
    points_after = db.Column(db.Integer, nullable=False)
    purchased_at = db.Column(db.DateTime, default=datetime.utcnow)

    item = db.relationship('AvatarItem')

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'guest_code': self.guest_code,
            'item': self.item.to_dict() if self.item else None,
            'points_spent': self.points_spent,
            'points_before': self.points_before,
            'points_after': self.points_after,
            'purchased_at': self.purchased_at.isoformat() if self.purchased_at else None
        }

# ==================== PRIZE SYSTEM MODELS ====================
# Points for Prizes - students redeem points for physical rewards
# BACKOUT: Set PRIZE_SYSTEM_ENABLED=false to disable without removing code

class SystemSetting(db.Model):
    """Global system settings (key-value store)"""
    __tablename__ = 'system_settings'

    key = db.Column(db.String(100), primary_key=True)
    value = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)

    @staticmethod
    def get(key, default=None):
        """Get a setting value"""
        setting = SystemSetting.query.get(key)
        if setting:
            # Try to parse as JSON for complex values
            try:
                import json
                return json.loads(setting.value)
            except:
                return setting.value
        return default

    @staticmethod
    def set(key, value, description=None, user_id=None):
        """Set a setting value"""
        import json
        setting = SystemSetting.query.get(key)
        if not setting:
            setting = SystemSetting(key=key)

        # Serialize complex values as JSON
        if isinstance(value, (dict, list)):
            setting.value = json.dumps(value)
        else:
            setting.value = str(value)

        if description:
            setting.description = description
        setting.updated_by = user_id
        setting.updated_at = datetime.utcnow()

        db.session.add(setting)
        db.session.commit()
        return setting


class PrizeSchool(db.Model):
    """Schools participating in the prize programme"""
    __tablename__ = 'prize_schools'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    roll_number = db.Column(db.String(20), unique=True, nullable=True)  # Irish school roll number
    county = db.Column(db.String(50))
    address = db.Column(db.Text)

    # Status
    status = db.Column(db.String(20), default='pending')  # pending, approved, suspended

    # School-specific settings
    points_multiplier = db.Column(db.Float, default=1.0)  # Multiplied with global multiplier

    # School rep (main contact)
    rep_user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    rep_name = db.Column(db.String(100))
    rep_email = db.Column(db.String(100))

    # Admin tracking
    approved_at = db.Column(db.DateTime)
    approved_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)

    # Relationships
    rep_user = db.relationship('User', foreign_keys=[rep_user_id], backref='rep_for_schools')
    approver = db.relationship('User', foreign_keys=[approved_by])

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'roll_number': self.roll_number,
            'county': self.county,
            'status': self.status,
            'points_multiplier': self.points_multiplier,
            'rep_name': self.rep_name,
            'rep_email': self.rep_email,
            'approved_at': self.approved_at.isoformat() if self.approved_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class Prize(db.Model):
    """Global prize catalogue (templates)"""
    __tablename__ = 'prizes'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)

    # Points (base cost before multipliers)
    base_point_cost = db.Column(db.Integer, nullable=False)

    # Classification
    tier = db.Column(db.String(20), default='bronze')  # bronze, silver, gold, platinum
    prize_type = db.Column(db.String(20), default='physical')  # physical, raffle_entry, digital

    # Level requirement (0 = no requirement)
    minimum_level = db.Column(db.Integer, default=0)

    # Display
    emoji = db.Column(db.String(10), default='🎁')
    image_url = db.Column(db.String(255))
    sort_order = db.Column(db.Integer, default=0)

    # Availability
    is_active = db.Column(db.Boolean, default=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def get_cost_for_school(self, school):
        """Calculate actual point cost for this prize at a specific school"""
        # Check for school-specific override
        override = SchoolPrize.query.filter_by(
            school_id=school.id,
            prize_id=self.id
        ).first()

        if override and override.point_cost_override:
            return override.point_cost_override

        # Apply multipliers
        global_multiplier = float(SystemSetting.get('global_points_multiplier', 5.0))
        school_multiplier = school.points_multiplier or 1.0

        return int(self.base_point_cost * global_multiplier * school_multiplier)

    def to_dict(self, school=None):
        result = {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'base_point_cost': self.base_point_cost,
            'tier': self.tier,
            'prize_type': self.prize_type,
            'minimum_level': self.minimum_level or 0,
            'emoji': self.emoji,
            'image_url': self.image_url,
            'is_active': self.is_active,
            'sort_order': self.sort_order
        }

        if school:
            result['point_cost'] = self.get_cost_for_school(school)

        return result


class SchoolPrize(db.Model):
    """School-specific prize overrides and custom prizes"""
    __tablename__ = 'school_prizes'

    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('prize_schools.id'), nullable=False)

    # If prize_id is set, this is an override for a global prize
    # If prize_id is NULL, this is a school-specific prize
    prize_id = db.Column(db.Integer, db.ForeignKey('prizes.id'), nullable=True)

    # Custom prize details (used when prize_id is NULL)
    custom_name = db.Column(db.String(100))
    custom_description = db.Column(db.Text)
    custom_emoji = db.Column(db.String(10), default='🎁')

    # Override settings
    point_cost_override = db.Column(db.Integer, nullable=True)  # NULL = use calculated cost
    stock_available = db.Column(db.Integer, nullable=True)  # NULL = unlimited
    is_enabled = db.Column(db.Boolean, default=True)  # Can disable for this school

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    school = db.relationship('PrizeSchool', backref='prize_overrides')
    prize = db.relationship('Prize', backref='school_overrides')

    def to_dict(self):
        return {
            'id': self.id,
            'school_id': self.school_id,
            'prize_id': self.prize_id,
            'custom_name': self.custom_name,
            'custom_description': self.custom_description,
            'custom_emoji': self.custom_emoji,
            'point_cost_override': self.point_cost_override,
            'stock_available': self.stock_available,
            'is_enabled': self.is_enabled,
            # Include global prize info if this is an override
            'prize': self.prize.to_dict() if self.prize else None
        }

    def get_display_name(self):
        """Get the display name (custom or from global prize)"""
        if self.custom_name:
            return self.custom_name
        elif self.prize:
            return self.prize.name
        return "Unknown Prize"

    def get_point_cost(self):
        """Get the point cost for this school prize"""
        if self.point_cost_override:
            return self.point_cost_override
        elif self.prize and self.school:
            return self.prize.get_cost_for_school(self.school)
        return 0


class PrizeRedemption(db.Model):
    """Student prize redemptions (token-based, no personal data)"""
    __tablename__ = 'prize_redemptions'

    id = db.Column(db.Integer, primary_key=True)

    # Who redeemed
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    school_id = db.Column(db.Integer, db.ForeignKey('prize_schools.id'), nullable=False)

    # What was redeemed
    prize_id = db.Column(db.Integer, db.ForeignKey('prizes.id'), nullable=True)  # Global prize
    school_prize_id = db.Column(db.Integer, db.ForeignKey('school_prizes.id'), nullable=True)  # School-specific

    # Token for collection (GDPR-safe: no student name stored)
    token = db.Column(db.String(20), unique=True, nullable=False)

    # Points
    points_spent = db.Column(db.Integer, nullable=False)

    # Status tracking
    status = db.Column(db.String(20), default='pending')  # pending, fulfilled, expired, cancelled

    # Timestamps
    redeemed_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime)  # Token expiry
    fulfilled_at = db.Column(db.DateTime)
    fulfilled_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    fulfilment_notes = db.Column(db.Text)

    # Relationships
    user = db.relationship('User', foreign_keys=[user_id], backref='prize_redemptions')
    school = db.relationship('PrizeSchool', backref='redemptions')
    prize = db.relationship('Prize', backref='redemptions')
    school_prize = db.relationship('SchoolPrize', backref='redemptions')
    fulfiller = db.relationship('User', foreign_keys=[fulfilled_by])

    def get_prize_name(self):
        """Get the name of the redeemed prize"""
        if self.school_prize:
            return self.school_prize.get_display_name()
        elif self.prize:
            return self.prize.name
        return "Unknown Prize"

    def get_prize_emoji(self):
        """Get the emoji for the redeemed prize"""
        if self.school_prize and self.school_prize.custom_emoji:
            return self.school_prize.custom_emoji
        elif self.prize:
            return self.prize.emoji
        return "🎁"

    def to_dict(self, include_user=False):
        result = {
            'id': self.id,
            'school_id': self.school_id,
            'school_name': self.school.name if self.school else None,
            'prize_name': self.get_prize_name(),
            'prize_emoji': self.get_prize_emoji(),
            'token': self.token,
            'points_spent': self.points_spent,
            'status': self.status,
            'redeemed_at': self.redeemed_at.isoformat() if self.redeemed_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'fulfilled_at': self.fulfilled_at.isoformat() if self.fulfilled_at else None
        }

        if include_user and self.user:
            result['username'] = self.user.username

        return result


class SchoolRequest(db.Model):
    """Student requests to add their school to the programme"""
    __tablename__ = 'school_requests'

    id = db.Column(db.Integer, primary_key=True)

    # School info from student
    school_name = db.Column(db.String(200), nullable=False)
    county = db.Column(db.String(50))
    suggested_rep_email = db.Column(db.String(100))  # Optional: student suggests a teacher

    # Who requested
    requested_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

    # Status
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    admin_notes = db.Column(db.Text)

    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    processed_at = db.Column(db.DateTime)
    processed_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)

    # If approved, link to created school
    created_school_id = db.Column(db.Integer, db.ForeignKey('prize_schools.id'), nullable=True)

    # Relationships
    requester = db.relationship('User', foreign_keys=[requested_by], backref='school_requests')
    processor = db.relationship('User', foreign_keys=[processed_by])
    created_school = db.relationship('PrizeSchool')

    def to_dict(self):
        return {
            'id': self.id,
            'school_name': self.school_name,
            'county': self.county,
            'suggested_rep_email': self.suggested_rep_email,
            'requested_by_username': self.requester.username if self.requester else None,
            'status': self.status,
            'admin_notes': self.admin_notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None
        }


class RaffleDraw(db.Model):
    """Weekly raffle draws"""
    __tablename__ = 'raffle_draws'

    id = db.Column(db.Integer, primary_key=True)

    # Draw info
    draw_name = db.Column(db.String(100), nullable=False)
    prize_description = db.Column(db.Text, nullable=False)

    # Scheduling
    draw_date = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), default='scheduled')  # scheduled, completed, cancelled

    # Winner
    winner_redemption_id = db.Column(db.Integer, db.ForeignKey('prize_redemptions.id'), nullable=True)

    # Admin
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    drawn_at = db.Column(db.DateTime)

    # Relationships
    winner_redemption = db.relationship('PrizeRedemption')
    creator = db.relationship('User', foreign_keys=[created_by])

    def to_dict(self):
        return {
            'id': self.id,
            'draw_name': self.draw_name,
            'prize_description': self.prize_description,
            'draw_date': self.draw_date.isoformat() if self.draw_date else None,
            'status': self.status,
            'winner': self.winner_redemption.to_dict() if self.winner_redemption else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


# Helper function to generate prize tokens
def generate_prize_token():
    """Generate a unique prize redemption token"""
    import string
    chars = string.ascii_uppercase + string.digits
    while True:
        # Format: PRIZE-XXXX-XXXX
        token = 'PRIZE-' + ''.join(random.choices(chars, k=4)) + '-' + ''.join(random.choices(chars, k=4))
        # Check uniqueness
        existing = PrizeRedemption.query.filter_by(token=token).first()
        if not existing:
            return token


# ==================== DOMAIN RESTRICTION MODELS ====================

class TeacherDomainAccess(db.Model):
    """Tracks which email domains a teacher can access"""
    __tablename__ = 'teacher_domain_access'

    id = db.Column(db.Integer, primary_key=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    email_domain = db.Column(db.String(100), nullable=False)
    granted_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    granted_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)

    # Relationships
    teacher = db.relationship('User', foreign_keys=[teacher_id], backref='domain_access')
    granter = db.relationship('User', foreign_keys=[granted_by], backref='domains_granted')

    # Unique constraint: one teacher can only have one record per domain
    __table_args__ = (db.UniqueConstraint('teacher_id', 'email_domain', name='unique_teacher_domain'),)

    def to_dict(self):
        return {
            'id': self.id,
            'teacher_id': self.teacher_id,
            'teacher_name': self.teacher.full_name,
            'teacher_email': self.teacher.email,
            'email_domain': self.email_domain,
            'granted_by': self.granter.full_name,
            'granted_at': self.granted_at.isoformat(),
            'notes': self.notes
        }

class DomainAccessRequest(db.Model):
    """Tracks teacher requests for domain access"""
    __tablename__ = 'domain_access_requests'

    id = db.Column(db.Integer, primary_key=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    email_domain = db.Column(db.String(100), nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, approved, denied
    requested_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    reviewed_at = db.Column(db.DateTime)
    admin_notes = db.Column(db.Text)

    # Relationships
    teacher = db.relationship('User', foreign_keys=[teacher_id], backref='domain_requests')
    reviewer = db.relationship('User', foreign_keys=[reviewed_by], backref='domain_requests_reviewed')

    def to_dict(self):
        return {
            'id': self.id,
            'teacher_id': self.teacher_id,
            'teacher_name': self.teacher.full_name,
            'teacher_email': self.teacher.email,
            'email_domain': self.email_domain,
            'reason': self.reason,
            'status': self.status,
            'requested_at': self.requested_at.isoformat(),
            'reviewed_by': self.reviewer.full_name if self.reviewer else None,
            'reviewed_at': self.reviewed_at.isoformat() if self.reviewed_at else None,
            'admin_notes': self.admin_notes
        }

class TopicProgress(db.Model):
    """Per-topic progress tracking"""
    __tablename__ = 'topic_progress'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    topic = db.Column(db.String(50), nullable=False)
    difficulty = db.Column(db.String(20), nullable=False)
    attempts = db.Column(db.Integer, default=0)
    best_score = db.Column(db.Integer, default=0)
    best_percentage = db.Column(db.Float, default=0)
    total_questions_answered = db.Column(db.Integer, default=0)
    total_correct = db.Column(db.Integer, default=0)
    is_mastered = db.Column(db.Boolean, default=False)
    last_attempt_at = db.Column(db.DateTime)

    __table_args__ = (db.UniqueConstraint('user_id', 'topic', 'difficulty', name='unique_topic_progress'),)

    user = db.relationship('User', backref='topic_progress')

    def to_dict(self):
        accuracy = 0
        if self.total_questions_answered > 0:
            accuracy = round((self.total_correct / self.total_questions_answered) * 100, 1)

        return {
            'id': self.id,
            'topic': self.topic,
            'difficulty': self.difficulty,
            'attempts': self.attempts,
            'best_score': self.best_score,
            'best_percentage': self.best_percentage,
            'accuracy': accuracy,
            'is_mastered': self.is_mastered,
            'last_attempt_at': self.last_attempt_at.isoformat() if self.last_attempt_at else None
        }

# ==================== DECORATORS ====================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Allow full accounts (user_id), casual guests (is_guest + user_id), and repeat guests (guest_code)
        if 'user_id' not in session and 'guest_code' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Repeat guests are considered students
            if 'guest_code' in session and 'student' in roles:
                return f(*args, **kwargs)

            # Full accounts and casual guests
            if 'user_id' not in session:
                return jsonify({'error': 'Authentication required'}), 401
            user = User.query.get(session['user_id'])
            if not user or user.role not in roles:
                return jsonify({'error': 'Insufficient permissions'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def approved_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Allow casual guests through
        if 'is_guest' in session:
            return f(*args, **kwargs)

        # Allow repeat guests through
        if 'guest_code' in session:
            return f(*args, **kwargs)

        # For regular users, check authentication and approval
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        user = User.query.get(session['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 404
        if user.role == 'teacher' and not user.is_approved:
            return jsonify({'error': 'Teacher account pending approval'}), 403
        return f(*args, **kwargs)
    return decorated_function

def guest_or_login_required(f):
    """Allow both guest users and logged-in users"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'is_guest' not in session and 'user_id' not in session and 'guest_code' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function

# ==================== AVATAR HELPER FUNCTIONS ====================

def get_avatar_user_points(user_id=None, guest_code=None):
    """
    Get current points for user or guest.
    Returns (points, level) tuple.

    NOTE: guest_code takes priority over user_id because repeat guests
    have BOTH set in session (user_id points to shared guest account).
    """
    from sqlalchemy import text

    # Check guest_code FIRST (repeat guests have both user_id and guest_code)
    if guest_code:
        # Guest user - get from guest_users table (NOT guest_stats!)
        result = db.session.execute(text(
            "SELECT total_score FROM guest_users WHERE guest_code = :code"
        ), {"code": guest_code}).fetchone()
        points = result[0] if result else 0
    elif user_id:
        # Registered user - get from UserStats
        result = db.session.execute(text(
            "SELECT total_points FROM user_stats WHERE user_id = :uid"
        ), {"uid": user_id}).fetchone()
        points = result[0] if result else 0
    else:
        points = 0

    level = (points // 100) + 1
    return points, level

def avatar_owns_item(item_id, user_id=None, guest_code=None):
    """Check if user/guest owns a specific item"""
    query = UserAvatarInventory.query.filter_by(item_id=item_id)

    # Check guest_code FIRST (repeat guests have both user_id and guest_code)
    if guest_code:
        return query.filter_by(guest_code=guest_code).first() is not None
    elif user_id:
        return query.filter_by(user_id=user_id).first() is not None

    return False

def get_equipped_avatar(user_id=None, guest_code=None):
    """Get currently equipped avatar configuration

    NOTE: guest_code takes priority because repeat guests have BOTH
    a shared user_id AND their unique guest_code in session.
    """
    equipped = None

    # Check guest_code FIRST (repeat guests have both user_id and guest_code)
    if guest_code:
        equipped = UserAvatarEquipped.query.filter_by(guest_code=guest_code).first()
        print(f"🔍 Looking for equipped by guest_code={guest_code}, found: {equipped}")

    # Only check user_id if no guest_code OR no equipped found for guest
    if not equipped and user_id:
        equipped = UserAvatarEquipped.query.filter_by(user_id=user_id).first()
        print(f"🔍 Looking for equipped by user_id={user_id}, found: {equipped}")

    # Return default configuration if none exists
    if not equipped:
        print(f"⚠️ No equipped record found, returning defaults")
        return {
            'animal': 'panda',
            'hat': 'none',
            'glasses': 'none',
            'background': 'none',
            'accessory': 'none'
        }

    result = equipped.to_dict()
    print(f"✅ Found equipped record: {result}")
    return result

def grant_default_avatar_items(user_id=None, guest_code=None):
    """Grant all default items to a new user/guest"""
    if not FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False):
        return

    default_items = AvatarItem.query.filter_by(is_default=True).all()

    for item in default_items:
        if not avatar_owns_item(item.id, user_id, guest_code):
            # For guests, only store guest_code (not the shared user_id)
            inventory_entry = UserAvatarInventory(
                user_id=user_id if not guest_code else None,
                guest_code=guest_code,
                item_id=item.id
            )
            db.session.add(inventory_entry)

    try:
        db.session.commit()
    except:
        db.session.rollback()

def get_animal_from_guest_code(guest_code):
    """
    Extract animal name from guest code like 'panda42'.
    Returns animal key if it matches an avatar animal.
    For legacy codes (gnat42, slug15, etc.), returns 'panda' as fallback.
    """
    if not guest_code:
        return 'panda'

    code_lower = guest_code.lower()

    # Check for avatar-friendly animals first (these have matching avatars)
    for animal in AVATAR_ANIMALS:
        if code_lower.startswith(animal):
            return animal

    # Check for legacy animals (these get mapped to panda)
    for animal in LEGACY_ANIMALS:
        if code_lower.startswith(animal):
            # Legacy animal without avatar - use panda as fallback
            return 'panda'

    # Unknown format - default to panda
    return 'panda'

# ==================== BADGES HELPER FUNCTIONS ====================

def initialize_user_stats(user_id):
    """Create initial stats record for a user if it doesn't exist"""
    stats = UserStats.query.filter_by(user_id=user_id).first()
    if not stats:
        stats = UserStats(
            user_id=user_id,
            total_quizzes=0,
            total_questions_answered=0,
            total_correct_answers=0,
            current_streak_days=0,
            longest_streak_days=0,
            total_points=0,
            level=1,
            topics_mastered=0,
            perfect_scores=0
        )
        db.session.add(stats)
        db.session.commit()
    return stats

def update_user_stats_after_quiz(user_id, quiz_attempt):
    """Update user stats after completing a quiz"""
    from datetime import date

    stats = initialize_user_stats(user_id)

    # Update basic stats
    stats.total_quizzes += 1
    stats.total_questions_answered += quiz_attempt.total_questions
    stats.total_correct_answers += quiz_attempt.score

    # Check for perfect score
    if quiz_attempt.percentage == 100:
        stats.perfect_scores += 1

    # Award points for quiz completion (base points + performance bonus)
    base_points = 5  # Base points for completing any quiz
    performance_bonus = int(quiz_attempt.percentage / 10)  # 0-10 points based on score
    quiz_points = base_points + performance_bonus
    stats.total_points += quiz_points

    # Update streak (using Irish school calendar if available)
    today = date.today()
    streak_bonus = 0
    streak_milestone = None

    if IRISH_CALENDAR_ENABLED:
        # Smart streak tracking - only counts school days
        if stats.last_quiz_date:
            if stats.last_quiz_date == today:
                # Same day - no change to streak
                pass
            elif is_consecutive_school_day(stats.last_quiz_date, today):
                # Consecutive school day - streak continues!
                stats.current_streak_days += 1
            elif should_reset_streak(stats.last_quiz_date, today):
                # Missed a school day - streak resets
                stats.current_streak_days = 1
            else:
                # Edge case (e.g., activity during holidays) - continue streak
                stats.current_streak_days += 1
        else:
            # First quiz ever
            stats.current_streak_days = 1

        # Check for streak milestone bonus
        streak_milestone = get_streak_milestone(stats.current_streak_days)
        if streak_milestone:
            streak_bonus = streak_milestone['points']
            stats.total_points += streak_bonus
    else:
        # Fallback to simple consecutive day tracking
        if stats.last_quiz_date:
            days_diff = (today - stats.last_quiz_date).days
            if days_diff == 1:
                stats.current_streak_days += 1
            elif days_diff > 1:
                stats.current_streak_days = 1
            # If same day, don't change streak
        else:
            stats.current_streak_days = 1

    # Update longest streak
    if stats.current_streak_days > stats.longest_streak_days:
        stats.longest_streak_days = stats.current_streak_days

    stats.last_quiz_date = today

    # Calculate level (every 100 points = 1 level)
    stats.level = (stats.total_points // 100) + 1

    stats.updated_at = datetime.utcnow()
    db.session.commit()

    # Update topic progress
    update_topic_progress(user_id, quiz_attempt)

    # Check for new badges
    newly_earned = check_and_award_badges(user_id)

    return stats, newly_earned

def update_topic_progress(user_id, quiz_attempt):
    """Update progress for a specific topic/difficulty"""
    progress = TopicProgress.query.filter_by(
        user_id=user_id,
        topic=quiz_attempt.topic,
        difficulty=quiz_attempt.difficulty
    ).first()

    if not progress:
        progress = TopicProgress(
            user_id=user_id,
            topic=quiz_attempt.topic,
            difficulty=quiz_attempt.difficulty,
            attempts=0,
            best_score=0,
            best_percentage=0,
            total_questions_answered=0,
            total_correct=0,
            is_mastered=False
        )
        db.session.add(progress)

    progress.attempts += 1
    progress.total_questions_answered += quiz_attempt.total_questions
    progress.total_correct += quiz_attempt.score

    # Update best score
    if quiz_attempt.score > progress.best_score:
        progress.best_score = quiz_attempt.score
    if quiz_attempt.percentage > progress.best_percentage:
        progress.best_percentage = quiz_attempt.percentage

    progress.last_attempt_at = datetime.utcnow()

    # Check for mastery (90%+ accuracy with 5+ attempts)
    if progress.attempts >= 5:
        accuracy = (progress.total_correct / progress.total_questions_answered) * 100
        if accuracy >= 90 and not progress.is_mastered:
            progress.is_mastered = True

            # Update user's mastered topics count
            stats = UserStats.query.filter_by(user_id=user_id).first()
            if stats:
                # Count total mastered topics across all difficulties
                mastered_count = TopicProgress.query.filter_by(
                    user_id=user_id,
                    is_mastered=True
                ).count()
                stats.topics_mastered = mastered_count

    db.session.commit()

def check_and_award_badges(user_id):
    """Check if user has earned any new badges"""
    # Get all badges
    all_badges = Badge.query.all()

    # Get already earned badges
    earned_badge_ids = {ub.badge_id for ub in UserBadge.query.filter_by(user_id=user_id).all()}

    # Get user stats
    stats = UserStats.query.filter_by(user_id=user_id).first()
    if not stats:
        return []

    newly_earned = []

    for badge in all_badges:
        # Skip if already earned
        if badge.id in earned_badge_ids:
            continue

        # Check if requirements are met
        earned = False

        if badge.requirement_type == 'quizzes_completed':
            earned = stats.total_quizzes >= badge.requirement_value

        elif badge.requirement_type == 'perfect_scores':
            earned = stats.perfect_scores >= badge.requirement_value

        elif badge.requirement_type == 'high_scores':
            # Count quizzes with 90%+
            high_scores = QuizAttempt.query.filter(
                QuizAttempt.user_id == user_id,
                QuizAttempt.percentage >= 90
            ).count()
            earned = high_scores >= badge.requirement_value

        elif badge.requirement_type == 'streak_days':
            earned = stats.current_streak_days >= badge.requirement_value

        elif badge.requirement_type == 'topics_mastered':
            earned = stats.topics_mastered >= badge.requirement_value

        if earned:
            # Award the badge
            user_badge = UserBadge(
                user_id=user_id,
                badge_id=badge.id,
                progress=100
            )
            db.session.add(user_badge)

            # Award points
            stats.total_points += badge.points

            newly_earned.append(badge.to_dict())

    if newly_earned:
        db.session.commit()

    return newly_earned

# ==================== ROUTES ====================

def generate_options_for_answer(correct_answer, count=4, range_size=10, allow_negative=False):
    """
    Helper function to generate multiple choice options

    Args:
        correct_answer: The correct answer
        count: Number of options to generate (default 4)
        range_size: Range for generating wrong answers
        allow_negative: Whether to allow negative wrong answers

    Returns:
        List of options shuffled with correct answer included
    """
    options = [correct_answer]

    # Generate wrong answers
    attempts = 0
    max_attempts = 100

    while len(options) < count and attempts < max_attempts:
        attempts += 1

        # Create wrong answer within range
        offset = random.randint(-range_size, range_size)
        if offset == 0:
            offset = random.choice([-1, 1]) * random.randint(1, range_size)

        wrong_answer = correct_answer + offset

        # Apply negative restriction if needed
        if not allow_negative and wrong_answer < 0:
            wrong_answer = abs(wrong_answer)

        # Ensure unique and not zero (unless correct answer is zero)
        if wrong_answer not in options and (wrong_answer != 0 or correct_answer == 0):
            options.append(wrong_answer)

    # If we couldn't generate enough unique options, add some calculated ones
    while len(options) < count:
        # Generate wrong answers based on common mistakes
        if correct_answer > 0:
            wrong = correct_answer + random.choice([1, -1, 2, -2, 5, -5, 10, -10])
        else:
            wrong = correct_answer + random.choice([1, -1, 2, -2])

        if wrong not in options:
            options.append(wrong)

    # Shuffle so correct answer isn't always first
    random.shuffle(options)

    return options


def generate_multiplication_division_beginner():
    """
    Generate beginner level multiplication and division questions
    - Single digit × single digit (2 × 3 = ?)
    - Simple division with no remainders (6 ÷ 2 = ?)
    - NO NEGATIVE NUMBERS
    """
    operation = random.choice(['multiply', 'divide'])

    if operation == 'multiply':
        a = random.randint(1, 10)
        b = random.randint(1, 10)
        answer = a * b
        question = f"{a} × {b}"
    else:  # divide
        divisor = random.randint(1, 10)
        quotient = random.randint(1, 10)
        dividend = divisor * quotient
        answer = quotient
        question = f"{dividend} ÷ {divisor}"

    options = generate_options_for_answer(answer, count=4, range_size=10)

    return {
        'question': question,
        'answer': answer,
        'options': options,
        'explanation': f"The correct answer is {answer}"
    }


def generate_multiplication_division_intermediate():
    """
    Generate intermediate level multiplication and division questions
    - INCLUDES SINGLE NEGATIVE NUMBERS with low value integers
    """
    operation = random.choice(['multiply', 'divide'])
    include_negative = random.choice([True, False])

    if operation == 'multiply':
        if include_negative:
            a = random.choice(list(range(-10, 0)) + list(range(1, 11)))
            b = random.choice(list(range(-10, 0)) + list(range(1, 11)))

            # Ensure only ONE is negative
            if a < 0 and b < 0:
                b = abs(b)
            elif a > 0 and b > 0:
                if random.choice([True, False]):
                    a = -a
                else:
                    b = -b
        else:
            a = random.randint(10, 25)
            b = random.randint(2, 12)

        answer = a * b
        question = f"{a} × {b}"
    else:  # divide
        if include_negative:
            divisor = random.choice(list(range(-10, 0)) + list(range(2, 11)))
            quotient = random.choice(list(range(-10, 0)) + list(range(1, 11)))

            # Ensure only ONE is negative
            if divisor < 0 and quotient < 0:
                quotient = abs(quotient)
            elif divisor > 0 and quotient > 0:
                if random.choice([True, False]):
                    divisor = -divisor
                else:
                    quotient = -quotient

            dividend = divisor * quotient
            answer = quotient
        else:
            divisor = random.randint(2, 12)
            quotient = random.randint(10, 50)
            dividend = divisor * quotient
            answer = quotient

        question = f"{dividend} ÷ {divisor}"

    options = generate_options_for_answer(answer, count=4, range_size=20, allow_negative=True)

    return {
        'question': question,
        'answer': answer,
        'options': options,
        'explanation': f"The correct answer is {answer}"
    }


def generate_multiplication_division_advanced():
    """
    Generate advanced level multiplication and division questions
    - DOUBLE NEGATIVE CALCULATIONS
    - THREE DIGIT COMPUTATIONS
    """
    operation = random.choice(['multiply', 'divide', 'mixed', 'three_digit'])

    if operation == 'multiply':
        neg_type = random.choices(['double_neg', 'single_neg', 'positive'], weights=[0.4, 0.4, 0.2])[0]

        if neg_type == 'double_neg':
            a = random.randint(-50, -10)
            b = random.randint(-20, -2)
            answer = a * b
            question = f"({a}) × ({b})"
        elif neg_type == 'single_neg':
            a = random.randint(10, 50)
            b = random.randint(2, 25)
            if random.choice([True, False]):
                a = -a
            else:
                b = -b
            answer = a * b
            question = f"{a} × {b}"
        else:
            a = random.randint(20, 99)
            b = random.randint(11, 25)
            answer = a * b
            question = f"{a} × {b}"

    elif operation == 'divide':
        neg_type = random.choices(['double_neg', 'single_neg', 'positive'], weights=[0.4, 0.4, 0.2])[0]

        if neg_type == 'double_neg':
            divisor = random.randint(-25, -2)
            quotient = random.randint(-50, -5)
            dividend = divisor * quotient
            answer = quotient
            question = f"({dividend}) ÷ ({divisor})"
        elif neg_type == 'single_neg':
            divisor = random.randint(2, 25)
            quotient = random.randint(5, 50)
            if random.choice([True, False]):
                divisor = -divisor
            else:
                quotient = -quotient
            dividend = divisor * quotient
            answer = quotient
            question = f"{dividend} ÷ {divisor}"
        else:
            divisor = random.randint(11, 25)
            quotient = random.randint(20, 100)
            dividend = divisor * quotient
            answer = quotient
            question = f"{dividend} ÷ {divisor}"

    elif operation == 'mixed':
        mix_type = random.choice(['mult_then_div', 'div_then_mult'])

        if mix_type == 'mult_then_div':
            a = random.randint(-30, 30)
            if a == 0:
                a = random.choice([-15, 15])
            b = random.randint(2, 10)
            c = random.randint(-10, 10)
            if c == 0:
                c = random.choice([-5, 5])

            temp = a * b
            if temp % c != 0:
                quotient = temp // c
                temp = quotient * c
                a = temp // b

            answer = (a * b) // c
            a_str = f"({a})" if a < 0 else str(a)
            b_str = f"({b})" if b < 0 else str(b)
            c_str = f"({c})" if c < 0 else str(c)
            question = f"({a_str} × {b_str}) ÷ {c_str}"
        else:
            a = random.randint(-100, 100)
            if a == 0:
                a = random.choice([-48, 48])
            b = random.randint(-10, 10)
            if b == 0:
                b = random.choice([-6, 6])
            quotient = random.randint(-20, 20)
            if quotient == 0:
                quotient = random.choice([-8, 8])
            a = quotient * b
            c = random.randint(-10, 10)
            if c == 0:
                c = random.choice([-3, 3])

            answer = (a // b) * c
            a_str = f"({a})" if a < 0 else str(a)
            b_str = f"({b})" if b < 0 else str(b)
            c_str = f"({c})" if c < 0 else str(c)
            question = f"({a_str} ÷ {b_str}) × {c_str}"

    else:  # three_digit
        sub_type = random.choice(['mult_3digit', 'div_3digit'])

        if sub_type == 'mult_3digit':
            a = random.randint(100, 999)
            b = random.randint(10, 99)
            answer = a * b
            question = f"{a} × {b}"
        else:
            divisor = random.randint(10, 99)
            quotient = random.randint(10, 99)
            dividend = divisor * quotient
            answer = quotient
            question = f"{dividend} ÷ {divisor}"

    options = generate_options_for_answer(answer, count=4, range_size=50, allow_negative=True)

    return {
        'question': question,
        'answer': answer,
        'options': options,
        'explanation': f"The correct answer is {answer}"
    }

# ==================== AUTHENTICATION ROUTES ====================

# ==================== DOMAIN RESTRICTION HELPER FUNCTIONS ====================

def extract_domain(email):
    """Extract domain from email address"""
    if not email or '@' not in email:
        return None
    return email.split('@')[1].lower()

def get_all_domains_in_system():
    """Get all unique email domains from both students and teachers"""
    domains = {}

    # Get student domains
    students = User.query.filter_by(role='student').all()
    for student in students:
        domain = extract_domain(student.email)
        if domain:
            if domain not in domains:
                domains[domain] = {
                    'domain': domain,
                    'student_count': 0,
                    'teacher_count': 0,
                    'teachers_with_access': []
                }
            domains[domain]['student_count'] += 1

    # Get teacher domains
    teachers = User.query.filter_by(role='teacher').all()
    for teacher in teachers:
        domain = extract_domain(teacher.email)
        if domain:
            if domain not in domains:
                domains[domain] = {
                    'domain': domain,
                    'student_count': 0,
                    'teacher_count': 0,
                    'teachers_with_access': []
                }
            domains[domain]['teacher_count'] += 1

    # Get teachers with access to each domain
    for domain_name in domains.keys():
        access_records = TeacherDomainAccess.query.filter_by(email_domain=domain_name).all()
        for record in access_records:
            domains[domain_name]['teachers_with_access'].append({
                'id': record.teacher_id,
                'name': record.teacher.full_name,
                'email': record.teacher.email
            })

    return list(domains.values())

def teacher_has_domain_access(teacher_id, domain):
    """Check if a teacher has access to a specific domain"""
    if not domain:
        return True

    # Check if teacher has any domain restrictions
    has_any_restrictions = TeacherDomainAccess.query.filter_by(teacher_id=teacher_id).first()

    # If teacher has NO restrictions at all, they can see ALL students (backward compatible)
    if not has_any_restrictions:
        return True

    # If teacher has restrictions, check if they have access to THIS specific domain
    access = TeacherDomainAccess.query.filter_by(
        teacher_id=teacher_id,
        email_domain=domain
    ).first()

    return access is not None

def get_teacher_accessible_domains(teacher_id):
    """Get all domains a teacher has access to"""
    # Check if teacher has any restrictions
    restrictions = TeacherDomainAccess.query.filter_by(teacher_id=teacher_id).all()

    if not restrictions:
        # No restrictions = access to all domains
        return None  # None means "all domains"

    # Return list of accessible domains
    return [r.email_domain for r in restrictions]

def filter_students_by_domain_access(students_query, teacher_id):
    """Filter a SQLAlchemy query of students based on teacher's domain access"""
    accessible_domains = get_teacher_accessible_domains(teacher_id)

    # If None, teacher has access to all domains
    if accessible_domains is None:
        return students_query

    # If empty list, teacher has no access to any domains
    if not accessible_domains:
        return students_query.filter(User.id == -1)

    # Filter students by accessible domains
    filtered_students = []
    for student in students_query.all():
        student_domain = extract_domain(student.email)
        if student_domain in accessible_domains:
            filtered_students.append(student.id)

    if not filtered_students:
        return students_query.filter(User.id == -1)

    return students_query.filter(User.id.in_(filtered_students))

def get_teacher_domain_statistics(teacher_id):
    """Get statistics about a teacher's domain access"""
    accessible_domains = get_teacher_accessible_domains(teacher_id)

    if accessible_domains is None:
        # Teacher has access to all
        total_students = User.query.filter_by(role='student').count()
        all_domains = set()
        for student in User.query.filter_by(role='student').all():
            domain = extract_domain(student.email)
            if domain:
                all_domains.add(domain)

        return {
            'has_restrictions': False,
            'accessible_domains': list(all_domains),
            'accessible_student_count': total_students,
            'restricted_domains': []
        }

    # Count students in accessible domains
    accessible_count = 0
    all_domains = set()

    for student in User.query.filter_by(role='student').all():
        domain = extract_domain(student.email)
        if domain:
            all_domains.add(domain)
            if domain in accessible_domains:
                accessible_count += 1

    restricted_domains = list(all_domains - set(accessible_domains))

    return {
        'has_restrictions': True,
        'accessible_domains': accessible_domains,
        'accessible_student_count': accessible_count,
        'restricted_domains': restricted_domains
    }

@app.route('/')
def index():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        if user:
            if user.role == 'admin':
                return redirect(url_for('admin_dashboard'))
            elif user.role == 'teacher':
                if not user.is_approved:
                    return render_template('pending_approval.html')
                return redirect(url_for('teacher_dashboard'))
            else:
                return render_template('student_app.html')
    return render_template('login.html')

@app.route('/register', methods=['GET'])
def register_page():
    return render_template('register.html')

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')
    full_name = data.get('full_name', '').strip()
    role = data.get('role', 'student')

    # Validation
    if not email or not password or not full_name:
        return jsonify({'error': 'All fields are required'}), 400

    if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email):
        return jsonify({'error': 'Invalid email format'}), 400

    if len(password) < 6:
        return jsonify({'error': 'Password must be at least 6 characters'}), 400

    if role not in ['student', 'teacher']:
        return jsonify({'error': 'Invalid role'}), 400

    # Check if user exists
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already registered'}), 400

    # Create user
    user = User(
        email=email,
        full_name=full_name,
        role=role,
        is_approved=(role == 'student')  # Students auto-approved, teachers need approval
    )
    user.set_password(password)

    db.session.add(user)
    db.session.commit()

    message = 'Registration successful!' if role == 'student' else 'Registration successful! Your teacher account is pending admin approval.'

    return jsonify({
        'message': message,
        'user': user.to_dict()
    }), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not email or not password:
        return jsonify({'error': 'Email and password are required'}), 400

    user = User.query.filter_by(email=email).first()

    if not user or not user.check_password(password):
        return jsonify({'error': 'Invalid email or password'}), 401

    session['user_id'] = user.id
    session['user_role'] = user.role
    session['user_name'] = user.full_name

    return jsonify({
        'message': 'Login successful',
        'role': user.role,
        'is_approved': user.is_approved,
        'user': user.to_dict()
    }), 200

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'}), 200


# ==================== FIXED GUEST ROUTES ====================
# REPLACE your existing guest routes (lines ~1185-1208) with these:

@app.route('/api/guest-start', methods=['POST'])
def guest_start():
    """Initialize guest session with proper user_id"""
    import uuid

    try:
        session.clear()

        # Get or create the guest user in database
        guest_user = User.query.filter_by(email='guest@agentmath.app').first()

        if not guest_user:
            # Create guest user if it doesn't exist
            guest_user = User(
                email='guest@agentmath.app',
                password_hash='no_password_required',
                full_name='Guest User',
                role='student',
                is_approved=True
            )
            db.session.add(guest_user)
            db.session.commit()

        # Set up guest session properly
        session['is_guest'] = True
        session['guest_session_id'] = str(uuid.uuid4())
        session['user_id'] = guest_user.id  # CRITICAL: Set user_id
        session['role'] = 'student'

        # Try to create guest_sessions table if it doesn't exist
        try:
            from sqlalchemy import text
            db.session.execute(text("""
                CREATE TABLE IF NOT EXISTS guest_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT UNIQUE NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    quiz_attempts INTEGER DEFAULT 0
                )
            """))

            # Insert this guest session
            db.session.execute(
                text("INSERT OR IGNORE INTO guest_sessions (session_id) VALUES (:sid)"),
                {"sid": session['guest_session_id']}
            )
            db.session.commit()
        except Exception as e:
            print(f"Note: Could not create guest_sessions table: {e}")
            # Not critical, continue anyway

        return jsonify({
            'success': True,
            'message': 'Guest session started',
            'redirect': '/student'
        }), 200

    except Exception as e:
        print(f"Error starting guest session: {e}")
        db.session.rollback()
        return jsonify({'error': f'Failed to start guest session: {str(e)}'}), 500


@app.route('/guest')
def guest_app():
    """Guest mode redirect - initializes session if needed"""
    import uuid

    # If not already a guest, set up guest session
    if 'is_guest' not in session or 'user_id' not in session:
        try:
            # Get or create guest user
            guest_user = User.query.filter_by(email='guest@agentmath.app').first()

            if not guest_user:
                guest_user = User(
                    email='guest@agentmath.app',
                    password_hash='no_password_required',
                    full_name='Guest User',
                    role='student',
                    is_approved=True
                )
                db.session.add(guest_user)
                db.session.commit()

            # Set up session
            session['is_guest'] = True
            session['guest_session_id'] = str(uuid.uuid4())
            session['user_id'] = guest_user.id
            session['role'] = 'student'

        except Exception as e:
            print(f"Error setting up guest session: {e}")
            return redirect('/')

    # Redirect to student app
    return redirect('/student')


@app.route('/api/guest-info')
def guest_info():
    """Return guest session information"""
    if session.get('is_guest'):
        return jsonify({
            'is_guest': True,
            'guest_id': session.get('guest_session_id', 'unknown'),
            'user_id': session.get('user_id')
        }), 200
    return jsonify({'is_guest': False}), 200


@app.route('/api/change-password', methods=['POST'])
@login_required
def change_password():
    """Allow users to change their own password"""
    data = request.json
    current_password = data.get('current_password', '')
    new_password = data.get('new_password', '')
    confirm_password = data.get('confirm_password', '')

    # Validation
    if not current_password or not new_password or not confirm_password:
        return jsonify({'error': 'All fields are required'}), 400

    if new_password != confirm_password:
        return jsonify({'error': 'New passwords do not match'}), 400

    if len(new_password) < 6:
        return jsonify({'error': 'Password must be at least 6 characters long'}), 400

    # Get current user
    user = User.query.get(session['user_id'])

    # Verify current password
    if not user.check_password(current_password):
        return jsonify({'error': 'Current password is incorrect'}), 401

    # Update password
    user.set_password(new_password)
    db.session.commit()

    return jsonify({'message': 'Password changed successfully'}), 200

@app.route('/api/current-user')
def current_user():
    """Get current user info - supports both regular and guest users"""
    if 'is_guest' in session:
        return jsonify({
            'is_guest': True,
            'full_name': 'Guest User',
            'email': 'guest@example.com',
            'role': 'student'
        }), 200

    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    user = User.query.get(session['user_id'])
    if not user:
        return jsonify({'error': 'User not found'}), 404
    return jsonify(user.to_dict()), 200

# ==================== STUDENT ROUTES ====================

@app.route('/student')
@login_required
@approved_required
def student_redirect():
    """Redirect /student to /app for backwards compatibility"""
    return redirect(url_for('student_app'))

@app.route('/app')
@login_required
@approved_required
def student_app():
    # Handle repeat guests (they don't have user_id)
    if 'guest_code' in session:
        return render_template('student_app.html')

    # Handle full accounts and casual guests
    user = User.query.get(session['user_id'])
    if user.role != 'student':
        return redirect(url_for('index'))
    return render_template('student_app.html')

@app.route('/api/topics')
@guest_or_login_required
@approved_required
def get_topics():
    """Get topics grouped by strands - reads from topics table (admin managed)"""
    from sqlalchemy import text

    # Strand colors and descriptions
    strand_info = {
        'Number': {
            'color': '#667eea',
            'icon': '📊',
            'description': 'Master the fundamentals of numbers and operations'
        },
        'Algebra and Functions': {
            'color': '#f093fb',
            'icon': '🔢',
            'description': 'Discover patterns, equations, and functions'
        },
        'Statistics and Probability': {
            'color': '#4facfe',
            'icon': '📈',
            'description': 'Analyze data and understand probability'
        },
        'Senior Cycle - Algebra': {
            'color': '#fa709a',
            'icon': '🎓',
            'description': 'Advanced algebraic concepts for senior students'
        },
        'Geometry and Trigonometry': {
            'color': '#764ba2',
            'icon': '📐',
            'description': 'Explore shapes, measurements, and spatial reasoning'
        }
    }

    strands = {}
    topics_flat = {}

    try:
        # Query topics from the topics table (managed by admin)
        # Only get visible topics, ordered by strand and sort_order
        topics_query = db.session.execute(text("""
            SELECT t.topic_id, t.display_name, t.icon, s.name as strand_name, t.sort_order
            FROM topics t
            LEFT JOIN strands s ON t.strand_id = s.id
            WHERE t.is_visible = 1
            ORDER BY
                CASE s.name
                    WHEN 'Number' THEN 1
                    WHEN 'Algebra and Functions' THEN 2
                    WHEN 'Statistics and Probability' THEN 3
                    WHEN 'Senior Cycle - Algebra' THEN 4
                    WHEN 'Geometry and Trigonometry' THEN 5
                    ELSE 6
                END,
                t.sort_order,
                t.display_name
        """)).fetchall()

        if topics_query:
            for topic_id, display_name, icon, strand_name, sort_order in topics_query:
                # Use strand name or 'Other' for unassigned topics
                strand = strand_name or 'Other'

                if strand not in strands:
                    strands[strand] = []

                # Add topic to strand list
                strands[strand].append(topic_id)

                # Add topic metadata to flat dict
                topics_flat[topic_id] = {
                    'title': display_name,
                    'icon': icon or 'book'
                }

            # Add any new strands to strand_info with default styling
            for strand_name in strands.keys():
                if strand_name not in strand_info:
                    strand_info[strand_name] = {
                        'color': '#6b7280',
                        'icon': '📚',
                        'description': f'Topics in {strand_name}'
                    }
        else:
            # No topics in database, use fallback
            raise Exception("No topics found in topics table")

    except Exception as e:
        # Fallback: Query from questions table (old method)
        topic_info = {
            'arithmetic': {'title': 'Arithmetic', 'icon': 'calculator'},
            'fractions': {'title': 'Fractions', 'icon': 'divide'},
            'decimals': {'title': 'Decimals', 'icon': 'percent'},
            'multiplication_division': {'title': 'Multiplication & Division', 'icon': 'x'},
            'number_systems': {'title': 'Number Systems', 'icon': 'hash'},
            'bodmas': {'title': 'BODMAS', 'icon': 'book'},
            'introductory_algebra': {'title': 'Introductory Algebra', 'icon': 'book-open'},
            'functions': {'title': 'Functions', 'icon': 'chart'},
            'patterns': {'title': 'Patterns', 'icon': 'trending-up'},
            'solving_equations': {'title': 'Solving Equations', 'icon': 'equals'},
            'simplifying_expressions': {'title': 'Simplifying Expressions', 'icon': 'calculator'},
            'expanding_factorising': {'title': 'Expanding & Factorising', 'icon': 'brackets'},
            'probability': {'title': 'Probability', 'icon': 'dice'},
            'descriptive_statistics': {'title': 'Descriptive Statistics', 'icon': 'chart-bar'},
            'sets': {'title': 'Sets', 'icon': 'layers'},
            'surds': {'title': 'Surds', 'icon': 'radical'},
            'complex_numbers_intro': {'title': 'Complex Numbers Intro', 'icon': 'infinity'},
            'complex_numbers_expanded': {'title': 'Complex Numbers - Expanded', 'icon': 'rotate'},
            'percentages': {'title': 'Percentages', 'icon': 'percent'},
            'geometry': {'title': 'Geometry', 'icon': 'shapes'},
            'trigonometry': {'title': 'Trigonometry', 'icon': 'ruler'}
        }

        try:
            # Try to get topics from questions table
            topics_query = db.session.execute(text("""
                SELECT DISTINCT topic, strand
                FROM questions
                WHERE strand IS NOT NULL
                ORDER BY strand, topic
            """)).fetchall()

            for topic, strand in topics_query:
                if strand not in strands:
                    strands[strand] = []
                strands[strand].append(topic)

                if topic in topic_info:
                    topics_flat[topic] = topic_info[topic]
                else:
                    topics_flat[topic] = {
                        'title': topic.replace('_', ' ').title(),
                        'icon': 'book'
                    }
        except:
            # Ultimate fallback - hardcoded
            strands = {
                'Number': ['arithmetic', 'multiplication_division', 'number_systems',
                          'bodmas', 'fractions', 'decimals', 'sets'],
                'Algebra and Functions': ['introductory_algebra', 'functions', 'patterns',
                                         'solving_equations', 'simplifying_expressions',
                                         'expanding_factorising'],
                'Statistics and Probability': ['probability', 'descriptive_statistics'],
                'Senior Cycle - Algebra': ['surds', 'complex_numbers_intro',
                                           'complex_numbers_expanded']
            }
            topics_flat = topic_info

    return jsonify({
        'topics': topics_flat,
        'strands': strands,
        'strand_info': strand_info
    })

@app.route('/api/questions/<topic>/<difficulty>')
@guest_or_login_required
@approved_required
def get_questions(topic, difficulty):
    """
    Get 25 random questions from the pool of 40 available questions
    for the given topic and difficulty level.
    Each student gets a different random selection.
    """
    questions = Question.query.filter_by(topic=topic, difficulty=difficulty).all()
    questions_list = [q.to_dict() for q in questions]

    # Shuffle to randomize order
    random.shuffle(questions_list)

    # Return 25 questions (or all available if less than 25)
    return jsonify(questions_list[:25])

@app.route('/api/create-quiz-attempt', methods=['POST'])
@login_required
@approved_required
def create_quiz_attempt():
    """
    Create a quiz attempt and return the ID for Who Am I tracking.
    Called when student starts a quiz in student_app.html.
    """
    data = request.json

    try:
        # Create new quiz attempt record
        quiz_attempt = QuizAttempt(
            user_id=session['user_id'],
            topic=data.get('topic'),
            difficulty=data.get('difficulty'),
            score=0,  # Will be updated when quiz completes
            total_questions=0,
            percentage=0
        )
        db.session.add(quiz_attempt)
        db.session.commit()

        return jsonify({
            'success': True,
            'quiz_attempt_id': quiz_attempt.id
        })

    except Exception as e:
        db.session.rollback()
        import traceback
        error_details = traceback.format_exc()
        print(f"Error creating quiz attempt: {e}")
        print(f"Full traceback: {error_details}")
        return jsonify({'error': str(e), 'details': error_details}), 500

@app.route('/api/submit-quiz', methods=['POST'])
@guest_or_login_required
@approved_required
def submit_quiz():
    """Submit quiz - works for guests, repeat guests, and registered users"""
    data = request.json

    # Normalize topic and difficulty to lowercase
    topic = data.get('topic', '').lower().strip()
    difficulty = data.get('difficulty', '').lower().strip()
    score = data.get('score', 0)
    total = data.get('total_questions', 25)
    percentage = data.get('percentage', 0)
    time_taken = data.get('time_taken', 0)

    # Validate topic and difficulty
    valid_topics = [
        'arithmetic', 'fractions', 'decimals', 'multiplication_division',
        'number_systems',
        'bodmas', 'introductory_algebra', 'functions', 'patterns', 'solving_equations', 'simplifying_expressions', 'expanding_factorising', 'sets', 'probability', 'descriptive_statistics', 'surds',
        'complex_numbers_intro', 'complex_numbers_expanded',
        'trigonometry', 'coordinate_geometry', 'simultaneous_equations'  # Added missing topics
    ]
    valid_difficulties = ['beginner', 'intermediate', 'advanced']

    if topic not in valid_topics:
        return jsonify({'error': f'Invalid topic: {topic}'}), 400

    if difficulty not in valid_difficulties:
        return jsonify({'error': f'Invalid difficulty: {difficulty}'}), 400

    # Handle repeat guests - save to guest tables
    if 'guest_code' in session:
        from sqlalchemy import text
        guest_code = session['guest_code']

        # Get all bonus points
        who_am_i_bonus = data.get('who_am_i_bonus', 0)
        milestone_points = data.get('milestone_points', 0)  # NEW: In-quiz milestone points
        total_points = score + who_am_i_bonus + milestone_points  # Score + all bonuses!

        # Save quiz attempt (try with bonus columns, fallback without them)
        try:
            db.session.execute(text("""
                INSERT INTO guest_quiz_attempts (guest_code, topic, difficulty, score, total_questions, time_spent, who_am_i_bonus, milestone_points)
                VALUES (:code, :topic, :diff, :score, :total, :time, :bonus, :milestone)
            """), {
                "code": guest_code,
                "topic": topic,
                "diff": difficulty,
                "score": score,
                "total": total,
                "time": time_taken,
                "bonus": who_am_i_bonus,
                "milestone": milestone_points
            })
        except:
            # Fallback: table doesn't have bonus columns
            try:
                db.session.execute(text("""
                    INSERT INTO guest_quiz_attempts (guest_code, topic, difficulty, score, total_questions, time_spent, who_am_i_bonus)
                    VALUES (:code, :topic, :diff, :score, :total, :time, :bonus)
                """), {
                    "code": guest_code,
                    "topic": topic,
                    "diff": difficulty,
                    "score": score,
                    "total": total,
                    "time": time_taken,
                    "bonus": who_am_i_bonus
                })
            except:
                # Final fallback: no bonus columns at all
                db.session.execute(text("""
                    INSERT INTO guest_quiz_attempts (guest_code, topic, difficulty, score, total_questions, time_spent)
                    VALUES (:code, :topic, :diff, :score, :total, :time)
                """), {
                    "code": guest_code,
                    "topic": topic,
                    "diff": difficulty,
                    "score": score,
                    "total": total,
                    "time": time_taken
                })

        # Update guest stats (including ALL bonuses!)
        db.session.execute(text("""
            UPDATE guest_users
            SET total_score = total_score + :total_points,
                quizzes_completed = quizzes_completed + 1,
                last_active = :now
            WHERE guest_code = :code
        """), {
            "total_points": total_points,  # Score + who_am_i_bonus + milestone_points!
            "now": datetime.utcnow(),
            "code": guest_code
        })

        db.session.commit()

        return jsonify({
            'message': 'Quiz completed!',
            'score': score,
            'total': total,
            'percentage': percentage,
            'who_am_i_bonus': who_am_i_bonus,
            'milestone_points': milestone_points,
            'total_points_earned': total_points,
            'is_repeat_guest': True
        }), 200

    # For casual guests, save to UserStats so points persist during session
    if 'is_guest' in session:
        user_id = session.get('user_id')
        if user_id:
            # Get or create UserStats for guest user
            stats = UserStats.query.filter_by(user_id=user_id).first()
            if not stats:
                stats = UserStats(user_id=user_id, total_points=0, level=1)
                db.session.add(stats)
                db.session.commit()
            
            # Update points
            stats.total_points += score
            stats.total_quizzes += 1
            stats.total_questions_answered += total
            stats.total_correct_answers += score
            db.session.commit()
        
        return jsonify({
            'message': 'Quiz completed!',
            'score': score,
            'total': total,
            'percentage': percentage,
            'total_points': score,
            'is_guest': True,
            'prompt_register': True
        }), 200

    # For registered users, save to database
    # WHO AM I: Get quiz_attempt_id and bonus if provided
    quiz_attempt_id = data.get('quiz_attempt_id')
    who_am_i_bonus = data.get('who_am_i_bonus', 0)

    # If quiz_attempt_id is provided, update that record instead of creating new
    if quiz_attempt_id:
        attempt = QuizAttempt.query.get(quiz_attempt_id)
        if attempt and attempt.user_id == session['user_id']:
            # Update existing quiz attempt
            attempt.score = score
            attempt.total_questions = total
            attempt.percentage = percentage
            attempt.time_taken = time_taken
            attempt.who_am_i_bonus = who_am_i_bonus
            attempt.completed_at = datetime.utcnow()
        else:
            # Quiz attempt not found or doesn't belong to user, create new
            attempt = QuizAttempt(
                user_id=session['user_id'],
                topic=topic,
                difficulty=difficulty,
                score=score,
                total_questions=total,
                percentage=percentage,
                time_taken=time_taken,
                who_am_i_bonus=who_am_i_bonus
            )
            db.session.add(attempt)
    else:
        # Create new quiz attempt
        attempt = QuizAttempt(
            user_id=session['user_id'],
            topic=topic,
            difficulty=difficulty,
            score=score,
            total_questions=total,
            percentage=percentage,
            time_taken=time_taken,
            who_am_i_bonus=who_am_i_bonus
        )
        db.session.add(attempt)

    db.session.commit()

    # Update stats and check for badges
    stats, newly_earned_badges = update_user_stats_after_quiz(session['user_id'], attempt)

    return jsonify({
        'message': 'Quiz submitted successfully',
        'attempt': attempt.to_dict(),
        'stats': stats.to_dict(),
        'newly_earned_badges': newly_earned_badges
    }), 201

@app.route('/api/my-progress')
@guest_or_login_required
def my_progress():
    # Guest users have no progress
    if 'is_guest' in session:
        return jsonify([]), 200

    attempts = QuizAttempt.query.filter_by(user_id=session['user_id']).order_by(QuizAttempt.completed_at.desc()).all()
    return jsonify([a.to_dict() for a in attempts])

# ==================== BADGES API ROUTES ====================

@app.route('/api/student/badges')
@login_required
@approved_required
def get_student_badges():
    """Get all badges (earned and available) for the current student"""
    from sqlalchemy import text

    # =====================================================================
    # CASUAL GUESTS - Quick Try users (now with session persistence!)
    # =====================================================================
    if 'is_guest' in session and 'guest_code' not in session:
        user_id = session.get('user_id')
        stats = UserStats.query.filter_by(user_id=user_id).first() if user_id else None
        
        return jsonify({
            'earned': [],
            'available': [],
            'level': stats.level if stats else 1,
            'total_points': stats.total_points if stats else 0,
            'total_badges': 0,
            'is_casual_guest': True
        }), 200

    # =====================================================================
    # REPEAT GUESTS - Users with guest_code (persistent points & badges)
    # =====================================================================
    if 'guest_code' in session:
        guest_code = session['guest_code']

        # DEBUG: Print start
        print(f"\n{'='*80}")
        print(f"🔍 LOADING BADGES FOR GUEST: {guest_code}")
        print(f"{'='*80}")

        # Ensure guest_badges table exists
        ensure_guest_badges_table()

        # Get guest stats with error handling
        try:
            guest_stats = db.session.execute(text("""
                SELECT total_score, quizzes_completed
                FROM guest_users
                WHERE guest_code = :code
            """), {"code": guest_code}).fetchone()
            print(f"📊 Guest stats: {guest_stats}")
        except Exception as e:
            # If query fails, return default values
            print(f"❌ Error getting guest stats: {e}")
            guest_stats = None

        # Get guest badges (simplified query - only essential columns)
        try:
            guest_badges = db.session.execute(text("""
                SELECT badge_name, earned_at
                FROM guest_badges
                WHERE guest_code = :code
                ORDER BY earned_at DESC
            """), {"code": guest_code}).fetchall()
            print(f"🏆 Existing badges in DB: {len(guest_badges)} badges")
            for b in guest_badges:
                print(f"   - {b[0]}")
        except Exception as e:
            # If guest_badges table doesn't exist or has issues, just return empty
            print(f"❌ Error getting guest badges: {e}")
            guest_badges = []

        # Calculate level (1 level per 100 points)
        total_points = guest_stats[0] if guest_stats else 0
        quizzes_completed = guest_stats[1] if guest_stats and len(guest_stats) > 1 else 0
        level = (total_points // 100) + 1

        # Format earned badges for frontend
        earned_badges_list = []
        earned_badge_names = set()
        for badge in guest_badges:
            earned_badges_list.append({
                'name': badge[0],
                'earned_at': badge[1] if badge[1] else None,
                'icon': 'fa-trophy'
            })
            earned_badge_names.add(badge[0])

        # GET ALL BADGES FROM DATABASE (same as registered users!)
        try:
            all_badges = Badge.query.all()
            print(f"\n🎯 Total badges in system: {len(all_badges)}")
        except Exception as e:
            print(f"❌ Error loading badges: {e}")
            all_badges = []

        available_badges_list = []

        print(f"\n🔄 Processing badges...")

        # Calculate progress for each badge (same logic as registered users)
        for badge in all_badges:
            # Skip if already earned
            if badge.name in earned_badge_names:
                print(f"  ⏭️  {badge.name}: Already earned, skipping")
                continue

            progress = 0

            print(f"\n  📍 Checking: {badge.name} ({badge.requirement_type})")

            # Calculate progress based on badge requirement
            if badge.requirement_type == 'quizzes_completed':
                progress = min(100, int((quizzes_completed / badge.requirement_value) * 100))
                print(f"     Progress: {quizzes_completed}/{badge.requirement_value} quizzes = {progress}%")
            elif badge.requirement_type == 'perfect_scores':
                # Count perfect scores from guest_quiz_attempts
                try:
                    perfect_count = db.session.execute(text("""
                        SELECT COUNT(*) FROM guest_quiz_attempts
                        WHERE guest_code = :code AND score = total_questions
                    """), {"code": guest_code}).fetchone()[0]
                    progress = min(100, int((perfect_count / badge.requirement_value) * 100))
                except:
                    progress = 0
            elif badge.requirement_type == 'streak_days':
                # Guests don't track daily streaks yet
                progress = 0
            elif badge.requirement_type == 'topics_mastered':
                # Count distinct topics with 90%+ average
                try:
                    topics_result = db.session.execute(text("""
                        SELECT topic, AVG(CAST(score AS FLOAT) / total_questions) as avg_score
                        FROM guest_quiz_attempts
                        WHERE guest_code = :code
                        GROUP BY topic
                        HAVING AVG(CAST(score AS FLOAT) / total_questions) >= 0.9
                    """), {"code": guest_code}).fetchall()
                    topics_mastered = len(topics_result)  # Count how many topics meet criteria
                    progress = min(100, int((topics_mastered / badge.requirement_value) * 100))
                except Exception as e:
                    print(f"Error calculating topics_mastered: {e}")
                    progress = 0
            elif badge.requirement_type == 'high_scores':
                # Count quizzes with 90%+ score
                try:
                    high_scores = db.session.execute(text("""
                        SELECT COUNT(*) FROM guest_quiz_attempts
                        WHERE guest_code = :code
                        AND CAST(score AS FLOAT) / total_questions >= 0.9
                    """), {"code": guest_code}).fetchone()[0]
                    progress = min(100, int((high_scores / badge.requirement_value) * 100))
                except:
                    progress = 0
            else:
                progress = 0

            # AUTO-AWARD: If progress is 100%, award the badge!
            if progress >= 100:
                print(f"     🎯 Badge at 100%! Attempting to award...")
                try:
                    # Check if badge already exists
                    existing = db.session.execute(text("""
                        SELECT COUNT(*) FROM guest_badges
                        WHERE guest_code = :code AND badge_name = :badge_name
                    """), {"code": guest_code, "badge_name": badge.name}).fetchone()[0]

                    print(f"     Existing count in DB: {existing}")

                    if existing == 0:
                        print(f"     → Inserting into guest_badges...")
                        # Award the badge!
                        db.session.execute(text("""
                            INSERT INTO guest_badges (guest_code, badge_name, earned_at)
                            VALUES (:code, :badge_name, :earned_at)
                        """), {
                            "code": guest_code,
                            "badge_name": badge.name,
                            "earned_at": datetime.utcnow()
                        })
                        db.session.commit()
                        print(f"     ✅ Committed to database!")

                        # Add to earned badges instead of available
                        earned_badges_list.append({
                            'name': badge.name,
                            'earned_at': datetime.utcnow().isoformat(),
                            'icon': badge.icon
                        })
                        earned_badge_names.add(badge.name)

                        print(f'     🎉 Auto-awarded badge: {badge.name} to guest {guest_code}')
                        print(f'     📝 Added to earned_badges_list (now {len(earned_badges_list)} badges)')
                        continue  # Skip adding to available badges
                    else:
                        print(f'     ⏭️  Badge {badge.name} already in DB, skipping')
                        continue  # Skip adding to available if already earned
                except Exception as e:
                    # Log error but don't crash
                    print(f'     ❌ Error auto-awarding badge {badge.name}: {str(e)}')
                    import traceback
                    traceback.print_exc()
                    # Fall through to add to available badges

            # Add to available badges
            available_badges_list.append({
                'id': badge.id,
                'name': badge.name,
                'description': badge.description,
                'icon': badge.icon,
                'category': badge.category,
                'requirement_type': badge.requirement_type,
                'requirement_value': badge.requirement_value,
                'points': badge.points,
                'color': badge.color,
                'progress': progress,
                'earned_at': None
            })

        print(f"\n{'='*80}")
        print(f"📊 FINAL RESULTS:")
        print(f"   Earned badges: {len(earned_badges_list)}")
        for b in earned_badges_list:
            print(f"      - {b['name']}")
        print(f"   Available badges: {len(available_badges_list)}")
        print(f"   Total points: {total_points}")
        print(f"   Level: {level}")
        print(f"{'='*80}\n")

        return jsonify({
            'earned': earned_badges_list,
            'available': available_badges_list,  # ALL badges from database!
            'level': level,
            'total_points': total_points,
            'total_badges': len(earned_badges_list) + len(available_badges_list),
            'is_repeat_guest': True
        }), 200

    # =====================================================================
    # REGISTERED USERS - Full badge system
    # =====================================================================
    user_id = session['user_id']

    # Get all badges
    all_badges = Badge.query.all()

    # Get earned badges
    earned_badges = UserBadge.query.filter_by(user_id=user_id).all()
    earned_badge_ids = {ub.badge_id for ub in earned_badges}

    # Get user stats for progress on unearned badges
    stats = UserStats.query.filter_by(user_id=user_id).first()
    if not stats:
        stats = initialize_user_stats(user_id)

    badges_data = {
        'earned': [],
        'available': [],
        'total_points': stats.total_points,
        'level': stats.level,
        'is_registered_user': True
    }

    for badge in all_badges:
        badge_dict = badge.to_dict()

        if badge.id in earned_badge_ids:
            # Badge is earned
            user_badge = next(ub for ub in earned_badges if ub.badge_id == badge.id)
            badge_dict['earned_at'] = user_badge.earned_at.isoformat()
            badge_dict['progress'] = 100
            badges_data['earned'].append(badge_dict)
        else:
            # Badge is available - calculate progress
            progress = 0

            if badge.requirement_type == 'quizzes_completed':
                progress = min(100, int((stats.total_quizzes / badge.requirement_value) * 100))
            elif badge.requirement_type == 'perfect_scores':
                progress = min(100, int((stats.perfect_scores / badge.requirement_value) * 100))
            elif badge.requirement_type == 'streak_days':
                progress = min(100, int((stats.current_streak_days / badge.requirement_value) * 100))
            elif badge.requirement_type == 'topics_mastered':
                progress = min(100, int((stats.topics_mastered / badge.requirement_value) * 100))
            elif badge.requirement_type == 'high_scores':
                high_scores = QuizAttempt.query.filter(
                    QuizAttempt.user_id == user_id,
                    QuizAttempt.percentage >= 90
                ).count()
                progress = min(100, int((high_scores / badge.requirement_value) * 100))

            badge_dict['progress'] = progress
            badge_dict['earned_at'] = None
            badges_data['available'].append(badge_dict)

    return jsonify(badges_data)

@app.route('/api/student/stats')
@login_required
@approved_required
def get_student_stats():
    """Get detailed statistics for the current student"""

    # Handle repeat guests - fetch from guest tables
    if 'guest_code' in session:
        from sqlalchemy import text
        guest_code = session['guest_code']

        # Get guest stats
        guest_stats = db.session.execute(text("""
            SELECT total_score, quizzes_completed
            FROM guest_users
            WHERE guest_code = :code
        """), {"code": guest_code}).fetchone()

        # Get guest quiz attempts
        attempts = db.session.execute(text("""
            SELECT topic, difficulty, score, total_questions, completed_at
            FROM guest_quiz_attempts
            WHERE guest_code = :code
            ORDER BY completed_at DESC
            LIMIT 10
        """), {"code": guest_code}).fetchall()

        # Calculate accuracy
        total_correct = sum(a[2] for a in attempts) if attempts else 0
        total_questions = sum(a[3] for a in attempts) if attempts else 0
        accuracy = (total_correct / total_questions * 100) if total_questions > 0 else 0

        # Get badge count
        badge_count = db.session.execute(text("""
            SELECT COUNT(*) FROM guest_badges WHERE guest_code = :code
        """), {"code": guest_code}).fetchone()[0]

        return jsonify({
            'stats': {
                'total_quizzes': guest_stats[1] if guest_stats else 0,
                'total_questions_answered': total_questions,
                'total_correct_answers': total_correct,
                'overall_accuracy': round(accuracy, 1),
                'current_streak_days': 0,
                'longest_streak_days': 0,
                'total_points': guest_stats[0] if guest_stats else 0,
                'level': 1,
                'topics_mastered': 0,
                'perfect_scores': 0,
                'badges_earned': badge_count
            },
            'topic_progress': [],
            'recent_attempts': [{
                'topic': a[0],
                'difficulty': a[1],
                'score': a[2],
                'total_questions': a[3],
                'completed_at': a[4]
            } for a in attempts]
        }), 200

    # Handle casual guests - no stats
    if 'is_guest' in session:
        return jsonify({
            'stats': {
                'total_quizzes': 0,
                'total_questions_answered': 0,
                'total_correct_answers': 0,
                'overall_accuracy': 0,
                'current_streak_days': 0,
                'longest_streak_days': 0,
                'total_points': 0,
                'level': 1,
                'topics_mastered': 0,
                'perfect_scores': 0
            },
            'topic_progress': [],
            'recent_attempts': []
        }), 200

    # Handle full accounts
    user_id = session['user_id']

    stats = UserStats.query.filter_by(user_id=user_id).first()
    if not stats:
        stats = initialize_user_stats(user_id)

    # Get topic progress
    topic_progress = TopicProgress.query.filter_by(user_id=user_id).all()

    # Get recent quiz attempts
    recent_attempts = QuizAttempt.query.filter_by(user_id=user_id).order_by(
        QuizAttempt.completed_at.desc()
    ).limit(10).all()

    # Get streak info (if Irish calendar enabled)
    streak_info = {}
    if IRISH_CALENDAR_ENABLED:
        next_milestone_days, next_milestone_info = get_next_milestone(stats.current_streak_days)
        streak_info = {
            'is_school_day_streak': True,
            'next_milestone_days': next_milestone_days,
            'next_milestone_name': next_milestone_info['name'] if next_milestone_info else None,
            'next_milestone_points': next_milestone_info['points'] if next_milestone_info else None,
            'days_until_next': (next_milestone_days - stats.current_streak_days) if next_milestone_days else None
        }

    stats_dict = stats.to_dict()
    stats_dict['streak_info'] = streak_info

    return jsonify({
        'stats': stats_dict,
        'topic_progress': [tp.to_dict() for tp in topic_progress],
        'recent_attempts': [qa.to_dict() for qa in recent_attempts]
    })

@app.route('/api/student/progress/<topic>')
@login_required
@approved_required
def get_topic_progress(topic):
    """Get progress for a specific topic"""
    user_id = session['user_id']

    progress = TopicProgress.query.filter_by(user_id=user_id, topic=topic).all()

    return jsonify({
        'topic': topic,
        'progress': [p.to_dict() for p in progress]
    })

@app.route('/api/student/mastery')
@login_required
@approved_required
def get_student_mastery():
    """
    Get student's mastery status for all topics and difficulties.
    Returns best score for each topic/difficulty combination.
    Mastery threshold: >80%
    OPTIMIZED: Single query instead of 36 separate queries
    """
    # Guest users don't have mastery data
    if 'is_guest' in session:
        return jsonify({}), 200

    user_id = session['user_id']

    # Get all topics - MUST match topics in get_topics() API
    topics = [
        'arithmetic', 'fractions', 'decimals', 'multiplication_division',
        'number_systems', 'bodmas', 'introductory_algebra', 'functions', 'patterns', 'solving_equations', 'simplifying_expressions', 'expanding_factorising', 'probability', 'descriptive_statistics', 'sets',
        'surds', 'complex_numbers_intro', 'complex_numbers_expanded'
    ]
    difficulties = ['beginner', 'intermediate', 'advanced']

    # OPTIMIZED: Get all best scores in a single query
    from sqlalchemy import text
    query = text("""
        SELECT topic, difficulty, MAX(percentage) as best_score
        FROM quiz_attempts
        WHERE user_id = :user_id
        GROUP BY topic, difficulty
    """)

    results = db.session.execute(query, {'user_id': user_id}).fetchall()

    # Build lookup dictionary from query results
    best_scores = {}
    for row in results:
        topic, difficulty, best_score = row
        if topic not in best_scores:
            best_scores[topic] = {}
        best_scores[topic][difficulty] = best_score

    # Build mastery data structure
    mastery_data = {}

    for topic in topics:
        mastery_data[topic] = {
            'difficulties': {},
            'topic_mastered': False
        }

        mastered_count = 0

        for difficulty in difficulties:
            best_score = best_scores.get(topic, {}).get(difficulty, 0)

            if best_score > 80:
                mastery_data[topic]['difficulties'][difficulty] = {
                    'mastered': True,
                    'best_score': round(best_score, 1)
                }
                mastered_count += 1
            else:
                mastery_data[topic]['difficulties'][difficulty] = {
                    'mastered': False,
                    'best_score': round(best_score, 1)
                }

        # Topic is mastered if all 3 difficulties are mastered
        mastery_data[topic]['topic_mastered'] = (mastered_count == 3)

    return jsonify(mastery_data)


# ==================== MANUAL BADGE AWARD ROUTE ====================
@app.route('/api/award-badges-now')
@login_required
def award_badges_now():
    """
    Manually trigger badge awarding for current guest code user
    Useful for testing and fixing badges that should be earned
    """
    from sqlalchemy import text

    if 'guest_code' not in session:
        return jsonify({
            'error': 'Only available for guest code users',
            'message': 'Please log in with a guest code to use this feature'
        }), 400

    guest_code = session['guest_code']

    try:
        # Ensure guest_badges table exists
        ensure_guest_badges_table()

        # Get guest stats
        guest_stats = db.session.execute(text("""
            SELECT total_score, quizzes_completed
            FROM guest_users
            WHERE guest_code = :code
        """), {"code": guest_code}).fetchone()

        if not guest_stats:
            return jsonify({'error': 'Guest not found'}), 404

        quizzes = guest_stats[1]
        points = guest_stats[0]

        # Get all badges
        all_badges = Badge.query.all()

        awarded = []
        skipped = []
        errors = []

        for badge in all_badges:
            try:
                # Calculate if badge is earned
                earned = False
                progress = 0

                if badge.requirement_type == 'quizzes_completed':
                    progress = (quizzes / badge.requirement_value) * 100 if badge.requirement_value > 0 else 0
                    if quizzes >= badge.requirement_value:
                        earned = True

                elif badge.requirement_type == 'perfect_scores':
                    perfect_count = db.session.execute(text("""
                        SELECT COUNT(*) FROM guest_quiz_attempts
                        WHERE guest_code = :code AND score = total_questions
                    """), {"code": guest_code}).fetchone()[0]
                    progress = (perfect_count / badge.requirement_value) * 100 if badge.requirement_value > 0 else 0
                    if perfect_count >= badge.requirement_value:
                        earned = True

                elif badge.requirement_type == 'high_scores':
                    high_scores = db.session.execute(text("""
                        SELECT COUNT(*) FROM guest_quiz_attempts
                        WHERE guest_code = :code
                        AND CAST(score AS FLOAT) / total_questions >= 0.9
                    """), {"code": guest_code}).fetchone()[0]
                    progress = (high_scores / badge.requirement_value) * 100 if badge.requirement_value > 0 else 0
                    if high_scores >= badge.requirement_value:
                        earned = True

                elif badge.requirement_type == 'topics_mastered':
                    topics_result = db.session.execute(text("""
                        SELECT topic, AVG(CAST(score AS FLOAT) / total_questions) as avg_score
                        FROM guest_quiz_attempts
                        WHERE guest_code = :code
                        GROUP BY topic
                        HAVING AVG(CAST(score AS FLOAT) / total_questions) >= 0.9
                    """), {"code": guest_code}).fetchall()
                    topics_mastered = len(topics_result)
                    progress = (topics_mastered / badge.requirement_value) * 100 if badge.requirement_value > 0 else 0
                    if topics_mastered >= badge.requirement_value:
                        earned = True

                if earned:
                    # Check if already awarded
                    existing = db.session.execute(text("""
                        SELECT COUNT(*) FROM guest_badges
                        WHERE guest_code = :code AND badge_name = :name
                    """), {"code": guest_code, "name": badge.name}).fetchone()[0]

                    if existing == 0:
                        # Award it!
                        db.session.execute(text("""
                            INSERT INTO guest_badges (guest_code, badge_name, earned_at)
                            VALUES (:code, :name, :now)
                        """), {
                            "code": guest_code,
                            "name": badge.name,
                            "now": datetime.utcnow()
                        })
                        db.session.commit()
                        awarded.append({
                            'name': badge.name,
                            'progress': int(progress),
                            'requirement': f"{badge.requirement_type}: {badge.requirement_value}"
                        })
                    else:
                        skipped.append(f"{badge.name} (already earned)")

            except Exception as e:
                errors.append(f"{badge.name}: {str(e)}")

        return jsonify({
            'success': True,
            'message': 'Badge check complete!',
            'guest_code': guest_code,
            'quizzes_completed': quizzes,
            'total_points': points,
            'newly_awarded': awarded,
            'already_earned': skipped,
            'errors': errors if errors else None
        }), 200

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'message': 'Failed to check badges. See error for details.'
        }), 500


def ensure_guest_badges_table():
    """
    Ensure the guest_badges table exists with correct structure
    Creates it if missing
    """
    from sqlalchemy import text

    try:
        # Check if table exists
        result = db.session.execute(text("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='guest_badges'
        """)).fetchone()

        if not result:
            print("⚠️  guest_badges table does NOT exist! Creating it now...")

            # Create the table
            db.session.execute(text("""
                CREATE TABLE guest_badges (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guest_code TEXT NOT NULL,
                    badge_name TEXT NOT NULL,
                    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(guest_code, badge_name)
                )
            """))
            db.session.commit()
            print("✅ guest_badges table created successfully!")
        else:
            print("✅ guest_badges table exists")

    except Exception as e:
        print(f"❌ Error checking/creating guest_badges table: {e}")
        # Don't raise - just log the error


@app.route('/student/badges')
@login_required
@approved_required
def student_badges_page():
    """Student badges and progress dashboard page"""
    return render_template('student_badges_dashboard.html')

@app.route('/api/class/<int:class_id>/leaderboard')
@login_required
@approved_required
def get_class_leaderboard(class_id):
    """Get leaderboard for a class"""
    # Verify user has access to this class
    user = User.query.get(session['user_id'])

    if user.role == 'teacher':
        # Verify teacher owns this class
        class_obj = Class.query.filter_by(id=class_id, teacher_id=user.id).first()
        if not class_obj:
            return jsonify({'error': 'Unauthorized'}), 403
    elif user.role == 'student':
        # Verify student is in this class
        enrollment = ClassEnrollment.query.filter_by(class_id=class_id, student_id=user.id).first()
        if not enrollment:
            return jsonify({'error': 'Unauthorized'}), 403
    else:
        return jsonify({'error': 'Unauthorized'}), 403

    # Get all students in class
    enrollments = ClassEnrollment.query.filter_by(class_id=class_id).all()
    student_ids = [e.student_id for e in enrollments]

    # Get stats for all students
    students_stats = []
    for student_id in student_ids:
        student = User.query.get(student_id)
        stats = UserStats.query.filter_by(user_id=student_id).first()

        if stats:
            students_stats.append({
                'student_name': student.full_name,
                'student_id': student_id,
                'total_points': stats.total_points,
                'level': stats.level,
                'total_quizzes': stats.total_quizzes,
                'current_streak': stats.current_streak_days,
                'badges_earned': UserBadge.query.filter_by(user_id=student_id).count()
            })

    # Sort by total points
    students_stats.sort(key=lambda x: x['total_points'], reverse=True)

    return jsonify({
        'class_id': class_id,
        'leaderboard': students_stats
    })

# ==================== TEACHER ROUTES ====================

@app.route('/teacher')
@login_required
@role_required('teacher')
@approved_required
def teacher_dashboard():
    """Redirect to the new visual class selector"""
    return redirect(url_for('teacher_classes_page'))

@app.route('/teacher/class-monitor')
@login_required
@role_required('teacher')
@approved_required
def class_monitor():
    """
    Class Monitor Dashboard - Live monitoring view for teachers
    Shows performance matrix for all students in teacher's classes
    """
    return render_template('class_monitor.html')

@app.route('/api/teacher/my-classes')
@login_required
@role_required('teacher')
@approved_required
def teacher_classes():
    classes = Class.query.filter_by(teacher_id=session['user_id']).all()
    return jsonify([c.to_dict() for c in classes])

@app.route('/api/teacher/create-class', methods=['POST'])
@login_required
@role_required('teacher')
@approved_required
def create_class():
    data = request.json
    name = data.get('name', '').strip()

    if not name:
        return jsonify({'error': 'Class name is required'}), 400

    new_class = Class(
        name=name,
        teacher_id=session['user_id']
    )

    db.session.add(new_class)
    db.session.commit()

    return jsonify({
        'message': 'Class created successfully',
        'class': new_class.to_dict()
    }), 201

@app.route('/api/teacher/students/search')
@login_required
@role_required('teacher')
@approved_required
def search_students():
    """Search for students (filtered by teacher's domain access)"""
    query = request.args.get('q', '').strip()
    teacher_id = session['user_id']
    if len(query) < 2:
        return jsonify([])
    students_query = User.query.filter(
        User.role == 'student',
        (User.email.ilike(f'%{query}%')) | (User.full_name.ilike(f'%{query}%'))
    )
    accessible_domains = get_teacher_accessible_domains(teacher_id)
    if accessible_domains is not None:
        filtered_ids = []
        for student in students_query.all():
            student_domain = extract_domain(student.email)
            if student_domain in accessible_domains:
                filtered_ids.append(student.id)
        students_query = students_query.filter(User.id.in_(filtered_ids)) if filtered_ids else students_query.filter(User.id == -1)
    students = students_query.limit(20).all()
    return jsonify([s.to_dict() for s in students])
@app.route('/api/teacher/class/<int:class_id>/enroll', methods=['POST'])
@login_required
@role_required('teacher')
@approved_required
def enroll_student(class_id):
    """Enroll a student in a class (with domain access check)"""
    class_obj = Class.query.get_or_404(class_id)
    teacher_id = session['user_id']
    if class_obj.teacher_id != teacher_id:
        return jsonify({'error': 'Unauthorized'}), 403
    data = request.json
    student_id = data.get('student_id')
    if not student_id:
        return jsonify({'error': 'Student ID required'}), 400
    student = User.query.get(student_id)
    if not student or student.role != 'student':
        return jsonify({'error': 'Invalid student'}), 400
    student_domain = extract_domain(student.email)
    if not teacher_has_domain_access(teacher_id, student_domain):
        return jsonify({'error': f'Access denied. You do not have permission to enroll students from the domain: {student_domain}. Please request access from an administrator.'}), 403
    existing = ClassEnrollment.query.filter_by(class_id=class_id, student_id=student_id).first()
    if existing:
        return jsonify({'error': 'Student already enrolled'}), 400
    enrollment = ClassEnrollment(class_id=class_id, student_id=student_id)
    db.session.add(enrollment)
    db.session.commit()
    return jsonify({'message': 'Student enrolled successfully'}), 201

@app.route('/api/teacher/class/<int:class_id>/students')
@login_required
@role_required('teacher')
@approved_required
def class_students(class_id):
    """Get students in class - FILTERED BY DOMAIN ACCESS"""
    class_obj = Class.query.get_or_404(class_id)
    teacher_id = session['user_id']

    if class_obj.teacher_id != teacher_id:
        return jsonify({'error': 'Unauthorized'}), 403

    enrollments = ClassEnrollment.query.filter_by(class_id=class_id).all()

    # Filter by domain access
    accessible_domains = get_teacher_accessible_domains(teacher_id)
    if accessible_domains is not None:
        filtered_enrollments = []
        for enrollment in enrollments:
            student = enrollment.student
            if student:
                student_domain = extract_domain(student.email)
                if student_domain in accessible_domains:
                    filtered_enrollments.append(enrollment)
        enrollments = filtered_enrollments

    students_data = []
    for enrollment in enrollments:
        student = enrollment.student
        if not student:  # Safety check
            continue
        attempts = QuizAttempt.query.filter_by(user_id=student.id).all()

        students_data.append({
            'id': student.id,
            'full_name': student.full_name,
            'email': student.email,
            'enrolled_at': enrollment.enrolled_at.isoformat(),
            'total_quizzes': len(attempts),
            'average_score': sum(a.percentage for a in attempts) / len(attempts) if attempts else 0,
            'last_activity': max([a.completed_at for a in attempts]).isoformat() if attempts else None
        })

    return jsonify(students_data)

@app.route('/api/teacher/class/<int:class_id>/progress')
@login_required
@role_required('teacher')
@approved_required
def class_progress(class_id):
    class_obj = Class.query.get_or_404(class_id)

    if class_obj.teacher_id != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403

    enrollments = ClassEnrollment.query.filter_by(class_id=class_id).all()
    student_ids = [e.student_id for e in enrollments]

    # Get all attempts for students in this class
    attempts = QuizAttempt.query.filter(QuizAttempt.user_id.in_(student_ids)).order_by(QuizAttempt.completed_at.desc()).all()

    return jsonify([a.to_dict() for a in attempts])

@app.route('/api/teacher/class/<int:class_id>/remove-student/<int:student_id>', methods=['DELETE'])
@login_required
@role_required('teacher')
@approved_required
def remove_student(class_id, student_id):
    class_obj = Class.query.get_or_404(class_id)

    if class_obj.teacher_id != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403

    enrollment = ClassEnrollment.query.filter_by(class_id=class_id, student_id=student_id).first()
    if not enrollment:
        return jsonify({'error': 'Enrollment not found'}), 404

    db.session.delete(enrollment)
    db.session.commit()

    return jsonify({'message': 'Student removed successfully'})

# ==================== NEW ENHANCED TEACHER ROUTES ====================

@app.route('/teacher/classes')
@login_required
@role_required('teacher')
@approved_required
def teacher_classes_page():
    """Visual class selector page"""
    return render_template('teacher_classes_selector.html')

@app.route('/api/teacher/classes', methods=['GET', 'POST'])
@login_required
@role_required('teacher')
@approved_required
def teacher_classes_api():
    """Get all classes for teacher or create new class"""
    teacher_id = session['user_id']

    if request.method == 'GET':
        # Get all classes for this teacher
        classes = Class.query.filter_by(teacher_id=teacher_id).order_by(Class.created_at.desc()).all()
        teacher = User.query.get(teacher_id)

        return jsonify({
            'classes': [c.to_dict() for c in classes],
            'teacher': teacher.to_dict() if teacher else None
        })

    elif request.method == 'POST':
        # Create new class
        data = request.json
        class_name = data.get('name', '').strip()

        if not class_name:
            return jsonify({'error': 'Class name is required'}), 400

        new_class = Class(
            name=class_name,
            teacher_id=teacher_id
        )

        db.session.add(new_class)
        db.session.commit()

        return jsonify({
            'message': 'Class created successfully',
            'class': new_class.to_dict()
        }), 201

@app.route('/api/teacher/class/<int:class_id>')
@login_required
@role_required('teacher')
@approved_required
def get_class_info(class_id):
    """Get basic class information"""
    class_obj = Class.query.get_or_404(class_id)

    # Verify teacher owns this class
    if class_obj.teacher_id != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403

    return jsonify(class_obj.to_dict())

@app.route('/teacher/class-manage/<int:class_id>')
@login_required
@role_required('teacher')
@approved_required
def class_manage_page(class_id):
    """Student management page for a class"""
    class_obj = Class.query.get_or_404(class_id)

    # Verify teacher owns this class
    if class_obj.teacher_id != session['user_id']:
        flash('Unauthorized access to class', 'error')
        return redirect(url_for('teacher_classes_page'))

    return render_template('teacher_class_manage_students.html',
                         class_id=class_id,
                         class_name=class_obj.name)

@app.route('/api/teacher/available-students/<int:class_id>')
@login_required
@role_required('teacher')
@approved_required
def get_available_students(class_id):
    """Get all students NOT enrolled in this class (filtered by domain access)"""
    class_obj = Class.query.get_or_404(class_id)
    teacher_id = session['user_id']
    if class_obj.teacher_id != teacher_id:
        return jsonify({'error': 'Unauthorized'}), 403
    enrolled_ids = db.session.query(ClassEnrollment.student_id).filter_by(class_id=class_id).all()
    enrolled_ids = [e[0] for e in enrolled_ids]
    available_students_query = User.query.filter(User.role == 'student').filter(~User.id.in_(enrolled_ids))
    accessible_domains = get_teacher_accessible_domains(teacher_id)
    if accessible_domains is not None:
        filtered_ids = []
        for student in available_students_query.all():
            student_domain = extract_domain(student.email)
            if student_domain in accessible_domains:
                filtered_ids.append(student.id)
        available_students_query = available_students_query.filter(User.id.in_(filtered_ids)) if filtered_ids else available_students_query.filter(User.id == -1)
    available_students = available_students_query.order_by(User.full_name).all()
    return jsonify([{'id': s.id, 'full_name': s.full_name, 'email': s.email} for s in available_students])

@app.route('/api/teacher/class/<int:class_id>/enroll-bulk', methods=['POST'])
@login_required
@role_required('teacher')
@approved_required
def enroll_students_bulk(class_id):
    """Enroll multiple students at once (with domain access checks)"""
    class_obj = Class.query.get_or_404(class_id)
    teacher_id = session['user_id']
    if class_obj.teacher_id != teacher_id:
        return jsonify({'error': 'Unauthorized'}), 403
    data = request.json
    student_ids = data.get('student_ids', [])
    if not student_ids:
        return jsonify({'error': 'No students selected'}), 400
    enrolled_count = 0
    already_enrolled = 0
    access_denied = []
    for student_id in student_ids:
        student = User.query.get(student_id)
        if student:
            student_domain = extract_domain(student.email)
            if not teacher_has_domain_access(teacher_id, student_domain):
                access_denied.append({'id': student_id, 'name': student.full_name, 'domain': student_domain})
                continue
        existing = ClassEnrollment.query.filter_by(class_id=class_id, student_id=student_id).first()
        if existing:
            already_enrolled += 1
            continue
        enrollment = ClassEnrollment(class_id=class_id, student_id=student_id)
        db.session.add(enrollment)
        enrolled_count += 1
    db.session.commit()
    response = {'message': f'Enrolled {enrolled_count} students', 'enrolled_count': enrolled_count, 'already_enrolled': already_enrolled}
    if access_denied:
        response['access_denied'] = access_denied
        response['access_denied_count'] = len(access_denied)
    return jsonify(response)

@app.route('/api/teacher/class/<int:class_id>/students-list')
@login_required
@role_required('teacher')
@approved_required
def get_class_students_list(class_id):
    """Get detailed list of students in a class with their progress (filtered by domain)"""
    class_obj = Class.query.get_or_404(class_id)
    teacher_id = session['user_id']
    if class_obj.teacher_id != teacher_id:
        return jsonify({'error': 'Unauthorized'}), 403
    enrollments = ClassEnrollment.query.filter_by(class_id=class_id).all()
    accessible_domains = get_teacher_accessible_domains(teacher_id)
    if accessible_domains is not None:
        filtered_enrollments = []
        for enrollment in enrollments:
            student = User.query.get(enrollment.student_id)
            if student:
                student_domain = extract_domain(student.email)
                if student_domain in accessible_domains:
                    filtered_enrollments.append(enrollment)
        enrollments = filtered_enrollments
    students_data = []
    for enrollment in enrollments:
        student = User.query.get(enrollment.student_id)
        if not student:
            continue
        attempts = QuizAttempt.query.filter_by(user_id=student.id).all()
        total_quizzes = len(attempts)
        if attempts:
            avg_score = sum(a.percentage for a in attempts) / len(attempts)
            recent_attempts = sorted(attempts, key=lambda x: x.completed_at, reverse=True)[:5]
        else:
            avg_score = 0
            recent_attempts = []
        students_data.append({'id': student.id, 'full_name': student.full_name, 'email': student.email, 'total_quizzes': total_quizzes, 'avg_score': round(avg_score, 1), 'recent_attempts': [a.to_dict() for a in recent_attempts], 'enrolled_at': enrollment.enrolled_at.isoformat()})
    return jsonify({'class': class_obj.to_dict(), 'students': students_data})

@app.route('/api/teacher/class/<int:class_id>/performance-matrix')
@login_required
@role_required('teacher')
@approved_required
def get_class_performance_matrix(class_id):
    """
    Get performance matrix for all students in a class
    Returns: percentage correct and attempts for each topic/difficulty combination
    Used by: Class Monitor Dashboard for live performance tracking
    """
    # Verify teacher owns this class
    class_obj = Class.query.filter_by(id=class_id, teacher_id=session['user_id']).first()
    if not class_obj:
        return jsonify({'error': 'Class not found or access denied'}), 403

    # Get all students in class
    enrollments = ClassEnrollment.query.filter_by(class_id=class_id).all()
    student_ids = [e.student_id for e in enrollments]
    students = User.query.filter(User.id.in_(student_ids)).all()

    # Get all topics and difficulties
    topics = ['arithmetic', 'fractions', 'decimals', 'multiplication_division', 'number_systems', 'bodmas', 'probability', 'descriptive_statistics', 'introductory_algebra', 'functions', 'patterns', 'solving_equations', 'simplifying_expressions', 'expanding_factorising', 'sets', 'surds', 'complex_numbers_intro', 'complex_numbers_expanded']
    difficulties = ['beginner', 'intermediate', 'advanced']

    students_data = []

    for student in students:
        performance = {}

        for topic in topics:
            for difficulty in difficulties:
                key = f"{topic}_{difficulty}"

                # Get all attempts for this topic/difficulty
                attempts = QuizAttempt.query.filter_by(
                    user_id=student.id,
                    topic=topic,
                    difficulty=difficulty
                ).all()

                if attempts:
                    # Calculate average percentage
                    avg_percentage = sum(a.percentage for a in attempts) / len(attempts)
                    performance[key] = {
                        'percentage': round(avg_percentage, 1),
                        'attempts': len(attempts)
                    }
                else:
                    performance[key] = {
                        'percentage': None,
                        'attempts': 0
                    }

        students_data.append({
            'student_id': student.id,
            'student_name': student.full_name,
            'performance': performance
        })

    return jsonify({
        'class_name': class_obj.name,
        'total_students': len(students_data),
        'students': students_data,
        'topics': topics,
        'difficulties': difficulties
    })

# ==================== ADMIN ROUTES ====================

@app.route('/admin')
@login_required
@role_required('admin')
def admin_dashboard():
    return render_template('admin_dashboard.html')

@app.route('/api/admin/pending-teachers')
@login_required
@role_required('admin')
def pending_teachers():
    teachers = User.query.filter_by(role='teacher', is_approved=False).all()
    return jsonify([t.to_dict() for t in teachers])

@app.route('/api/admin/approve-teacher/<int:teacher_id>', methods=['POST'])
@login_required
@role_required('admin')
def approve_teacher(teacher_id):
    teacher = User.query.get_or_404(teacher_id)

    if teacher.role != 'teacher':
        return jsonify({'error': 'User is not a teacher'}), 400

    teacher.is_approved = True
    db.session.commit()

    return jsonify({'message': 'Teacher approved successfully'})

@app.route('/api/admin/all-users')
@login_required
@role_required('admin')
def all_users():
    role_filter = request.args.get('role')

    query = User.query
    if role_filter:
        query = query.filter_by(role=role_filter)

    users = query.all()
    return jsonify([u.to_dict() for u in users])

@app.route('/api/admin/all-classes')
@login_required
@role_required('admin')
def all_classes():
    classes = Class.query.all()
    return jsonify([c.to_dict() for c in classes])

@app.route('/api/admin/rename-class/<int:class_id>', methods=['PUT'])
@login_required
@role_required('admin')
def rename_class(class_id):
    class_obj = Class.query.get_or_404(class_id)
    data = request.json
    new_name = data.get('name', '').strip()

    if not new_name:
        return jsonify({'error': 'Class name required'}), 400

    class_obj.name = new_name
    db.session.commit()

    return jsonify({'message': 'Class renamed successfully', 'class': class_obj.to_dict()})

@app.route('/api/admin/reassign-student', methods=['POST'])
@login_required
@role_required('admin')
def reassign_student():
    data = request.json
    student_id = data.get('student_id')
    from_class_id = data.get('from_class_id')
    to_class_id = data.get('to_class_id')

    if not all([student_id, from_class_id, to_class_id]):
        return jsonify({'error': 'Missing required parameters'}), 400

    # Remove from old class
    old_enrollment = ClassEnrollment.query.filter_by(class_id=from_class_id, student_id=student_id).first()
    if old_enrollment:
        db.session.delete(old_enrollment)

    # Add to new class
    new_enrollment = ClassEnrollment(class_id=to_class_id, student_id=student_id)
    db.session.add(new_enrollment)
    db.session.commit()

    return jsonify({'message': 'Student reassigned successfully'})

@app.route('/api/admin/class-comparison')
@login_required
@role_required('admin')
def class_comparison():
    classes = Class.query.all()
    comparison_data = []

    for class_obj in classes:
        enrollments = ClassEnrollment.query.filter_by(class_id=class_obj.id).all()
        student_ids = [e.student_id for e in enrollments]

        attempts = QuizAttempt.query.filter(QuizAttempt.user_id.in_(student_ids)).all()

        avg_score = sum(a.percentage for a in attempts) / len(attempts) if attempts else 0

        comparison_data.append({
            'class_id': class_obj.id,
            'class_name': class_obj.name,
            'teacher_name': class_obj.teacher.full_name,
            'student_count': len(enrollments),
            'total_quizzes': len(attempts),
            'average_score': round(avg_score, 2)
        })

    return jsonify(comparison_data)


# ==================== USER MANAGEMENT ADMIN ROUTES ====================

@app.route('/admin/users')
@login_required
@role_required('admin')
def admin_user_management():
    """Admin page for managing all users"""
    return render_template('admin_user_management.html')

@app.route('/api/admin/user/<int:user_id>', methods=['GET'])
@login_required
@role_required('admin')
def get_user_details(user_id):
    """Get detailed user information"""
    user = User.query.get_or_404(user_id)

    # Get additional stats
    stats = UserStats.query.filter_by(user_id=user_id).first()
    quiz_count = QuizAttempt.query.filter_by(user_id=user_id).count()

    # Get class enrollments if student
    classes = []
    if user.role == 'student':
        enrollments = ClassEnrollment.query.filter_by(student_id=user_id).all()
        classes = [{'id': e.class_obj.id, 'name': e.class_obj.name,
                   'teacher': e.class_obj.teacher.full_name} for e in enrollments]

    # Get classes teaching if teacher
    elif user.role == 'teacher':
        teaching_classes = Class.query.filter_by(teacher_id=user_id).all()
        classes = [{'id': c.id, 'name': c.name,
                   'student_count': len(c.enrollments)} for c in teaching_classes]

    return jsonify({
        'user': user.to_dict(),
        'stats': {
            'total_points': stats.total_points if stats else 0,
            'level': stats.level if stats else 1,
            'quiz_count': quiz_count
        },
        'classes': classes
    })

@app.route('/api/admin/user/<int:user_id>', methods=['PUT'])
@login_required
@role_required('admin')
def update_user(user_id):
    """Update user details (name, email)"""
    user = User.query.get_or_404(user_id)
    data = request.json

    # Update name
    if 'full_name' in data:
        new_name = data['full_name'].strip()
        if new_name:
            user.full_name = new_name

    # Update email (check for duplicates)
    if 'email' in data:
        new_email = data['email'].strip().lower()
        if new_email and new_email != user.email:
            existing = User.query.filter_by(email=new_email).first()
            if existing:
                return jsonify({'error': 'Email already in use'}), 400
            user.email = new_email

    # Update approval status
    if 'is_approved' in data:
        user.is_approved = data['is_approved']

    db.session.commit()

    return jsonify({
        'message': 'User updated successfully',
        'user': user.to_dict()
    })

@app.route('/api/admin/user/<int:user_id>', methods=['DELETE'])
@login_required
@role_required('admin')
def delete_user(user_id):
    """Delete a user and all associated data"""
    try:
        user = User.query.get_or_404(user_id)

        # Don't allow deleting yourself
        if user.id == session['user_id']:
            return jsonify({'error': 'Cannot delete your own account'}), 400

        # Don't allow deleting other admins
        if user.role == 'admin':
            return jsonify({'error': 'Cannot delete admin accounts'}), 403

        # Delete associated data in proper order to avoid foreign key violations

        # 1. Quiz attempts
        QuizAttempt.query.filter_by(user_id=user_id).delete()

        # 2. User stats
        UserStats.query.filter_by(user_id=user_id).delete()

        # 3. Topic progress
        TopicProgress.query.filter_by(user_id=user_id).delete()

        # 4. User badges
        UserBadge.query.filter_by(user_id=user_id).delete()

        # 5. Question flags - BOTH as reporter AND as resolver
        QuestionFlag.query.filter_by(user_id=user_id).delete()
        # Set resolved_by to NULL for flags this user resolved
        QuestionFlag.query.filter_by(resolved_by=user_id).update({'resolved_by': None})

        # 6. Question edits - Set editor to NULL (keep edit history but anonymize)
        QuestionEdit.query.filter_by(edited_by=user_id).update({'edited_by': None})

        # 7. Domain access records (for teachers)
        TeacherDomainAccess.query.filter_by(teacher_id=user_id).delete()
        # Set granted_by to NULL for domain access this admin granted
        TeacherDomainAccess.query.filter_by(granted_by=user_id).update({'granted_by': None})

        # 8. Domain access requests
        DomainAccessRequest.query.filter_by(teacher_id=user_id).delete()
        # Set reviewed_by to NULL for requests this admin reviewed
        DomainAccessRequest.query.filter_by(reviewed_by=user_id).update({'reviewed_by': None})

        # 9. Class enrollments (if student)
        ClassEnrollment.query.filter_by(student_id=user_id).delete()

        # 10. Classes (if teacher) - also delete all enrollments
        if user.role == 'teacher':
            classes = Class.query.filter_by(teacher_id=user_id).all()
            for class_obj in classes:
                ClassEnrollment.query.filter_by(class_id=class_obj.id).delete()
                db.session.delete(class_obj)

        # Finally, delete the user
        db.session.delete(user)
        db.session.commit()

        return jsonify({
            'message': f'User {user.full_name} deleted successfully'
        })

    except Exception as e:
        db.session.rollback()
        print(f"Error deleting user {user_id}: {str(e)}")  # Log the error
        return jsonify({
            'error': f'Failed to delete user: {str(e)}'
        }), 500

@app.route('/api/admin/users/bulk-delete', methods=['POST'])
@login_required
@role_required('admin')
def bulk_delete_users():
    """Delete multiple users at once"""
    try:
        data = request.json
        user_ids = data.get('user_ids', [])

        if not user_ids:
            return jsonify({'error': 'No users selected'}), 400

        deleted_count = 0
        errors = []

        for user_id in user_ids:
            try:
                user = User.query.get(user_id)

                if not user:
                    errors.append(f"User {user_id} not found")
                    continue

                # Don't allow deleting yourself
                if user.id == session['user_id']:
                    errors.append(f"Cannot delete your own account")
                    continue

                # Don't allow deleting other admins
                if user.role == 'admin':
                    errors.append(f"Cannot delete admin account: {user.full_name}")
                    continue

                # Delete associated data (same as single delete)
                QuizAttempt.query.filter_by(user_id=user_id).delete()
                UserStats.query.filter_by(user_id=user_id).delete()
                TopicProgress.query.filter_by(user_id=user_id).delete()
                UserBadge.query.filter_by(user_id=user_id).delete()

                QuestionFlag.query.filter_by(user_id=user_id).delete()
                QuestionFlag.query.filter_by(resolved_by=user_id).update({'resolved_by': None})

                QuestionEdit.query.filter_by(edited_by=user_id).update({'edited_by': None})

                TeacherDomainAccess.query.filter_by(teacher_id=user_id).delete()
                TeacherDomainAccess.query.filter_by(granted_by=user_id).update({'granted_by': None})

                DomainAccessRequest.query.filter_by(teacher_id=user_id).delete()
                DomainAccessRequest.query.filter_by(reviewed_by=user_id).update({'reviewed_by': None})

                ClassEnrollment.query.filter_by(student_id=user_id).delete()

                if user.role == 'teacher':
                    classes = Class.query.filter_by(teacher_id=user_id).all()
                    for class_obj in classes:
                        ClassEnrollment.query.filter_by(class_id=class_obj.id).delete()
                        db.session.delete(class_obj)

                # Delete the user
                db.session.delete(user)
                deleted_count += 1

            except Exception as e:
                errors.append(f"Error deleting user {user_id}: {str(e)}")
                continue

        # Commit all deletions
        db.session.commit()

        response_data = {
            'deleted_count': deleted_count,
            'total_requested': len(user_ids)
        }

        if errors:
            response_data['errors'] = errors

        return jsonify(response_data)

    except Exception as e:
        db.session.rollback()
        print(f"Error in bulk delete: {str(e)}")
        return jsonify({
            'error': f'Failed to delete users: {str(e)}'
        }), 500

@app.route('/api/admin/user/<int:user_id>/toggle-approval', methods=['POST'])
@login_required
@role_required('admin')
def toggle_user_approval(user_id):
    """Toggle user approval status"""
    user = User.query.get_or_404(user_id)

    user.is_approved = not user.is_approved
    db.session.commit()

    status = 'approved' if user.is_approved else 'unapproved'

    return jsonify({
        'message': f'User {status} successfully',
        'is_approved': user.is_approved
    })



# ==================== DOMAIN MANAGEMENT ADMIN ROUTES ====================

@app.route('/api/admin/domains')
@login_required
@role_required('admin')
def get_all_domains():
    """Get all email domains in the system with statistics"""
    domains = get_all_domains_in_system()
    domains.sort(key=lambda x: x['student_count'], reverse=True)
    return jsonify({
        'domains': domains,
        'total_domains': len(domains)
    })


@app.route('/api/admin/teacher/<int:teacher_id>/domains')
@login_required
@role_required('admin')
def get_teacher_domains(teacher_id):
    """Get all domains assigned to a specific teacher"""
    teacher = User.query.get_or_404(teacher_id)
    if teacher.role != 'teacher':
        return jsonify({'error': 'User is not a teacher'}), 400
    access_records = TeacherDomainAccess.query.filter_by(teacher_id=teacher_id).all()
    stats = get_teacher_domain_statistics(teacher_id)
    all_domains = get_all_domains_in_system()
    return jsonify({
        'teacher': teacher.to_dict(),
        'assigned_domains': [r.to_dict() for r in access_records],
        'statistics': stats,
        'available_domains': all_domains
    })


@app.route('/api/admin/teacher/<int:teacher_id>/domains', methods=['POST'])
@login_required
@role_required('admin')
def assign_domain_to_teacher(teacher_id):
    """Assign a domain to a teacher"""
    teacher = User.query.get_or_404(teacher_id)
    if teacher.role != 'teacher':
        return jsonify({'error': 'User is not a teacher'}), 400
    data = request.json
    domain = data.get('domain', '').strip().lower()
    notes = data.get('notes', '').strip()
    if not domain:
        return jsonify({'error': 'Domain is required'}), 400
    if '.' not in domain or '@' in domain:
        return jsonify({'error': 'Invalid domain format. Use format like: school.edu'}), 400
    existing = TeacherDomainAccess.query.filter_by(teacher_id=teacher_id, email_domain=domain).first()
    if existing:
        return jsonify({'error': 'Domain already assigned to this teacher'}), 400
    access = TeacherDomainAccess(teacher_id=teacher_id, email_domain=domain, granted_by=session['user_id'], notes=notes)
    db.session.add(access)
    pending_request = DomainAccessRequest.query.filter_by(teacher_id=teacher_id, email_domain=domain, status='pending').first()
    if pending_request:
        pending_request.status = 'approved'
        pending_request.reviewed_by = session['user_id']
        pending_request.reviewed_at = datetime.utcnow()
        pending_request.admin_notes = 'Automatically approved when domain was granted'
    db.session.commit()
    return jsonify({'message': 'Domain access granted successfully', 'access': access.to_dict()}), 201


@app.route('/api/admin/teacher/<int:teacher_id>/domains/<domain>', methods=['DELETE'])
@login_required
@role_required('admin')
def revoke_domain_from_teacher(teacher_id, domain):
    """Revoke a domain from a teacher"""
    domain = domain.lower()
    access = TeacherDomainAccess.query.filter_by(teacher_id=teacher_id, email_domain=domain).first()
    if not access:
        return jsonify({'error': 'Domain access not found'}), 404
    db.session.delete(access)
    db.session.commit()
    return jsonify({'message': 'Domain access revoked successfully'})


@app.route('/api/admin/teacher/<int:teacher_id>/domains/bulk', methods=['POST'])
@login_required
@role_required('admin')
def assign_domains_bulk(teacher_id):
    """Assign multiple domains to a teacher at once"""
    teacher = User.query.get_or_404(teacher_id)
    if teacher.role != 'teacher':
        return jsonify({'error': 'User is not a teacher'}), 400
    data = request.json
    domains = data.get('domains', [])
    notes = data.get('notes', '').strip()
    if not domains:
        return jsonify({'error': 'No domains provided'}), 400
    added, already_assigned, invalid = [], [], []
    for domain in domains:
        domain = domain.strip().lower()
        if '.' not in domain or '@' in domain:
            invalid.append(domain)
            continue
        existing = TeacherDomainAccess.query.filter_by(teacher_id=teacher_id, email_domain=domain).first()
        if existing:
            already_assigned.append(domain)
            continue
        access = TeacherDomainAccess(teacher_id=teacher_id, email_domain=domain, granted_by=session['user_id'], notes=notes)
        db.session.add(access)
        added.append(domain)
        pending_request = DomainAccessRequest.query.filter_by(teacher_id=teacher_id, email_domain=domain, status='pending').first()
        if pending_request:
            pending_request.status = 'approved'
            pending_request.reviewed_by = session['user_id']
            pending_request.reviewed_at = datetime.utcnow()
            pending_request.admin_notes = 'Automatically approved in bulk assignment'
    db.session.commit()
    return jsonify({'message': f'Processed {len(domains)} domains', 'added': added, 'already_assigned': already_assigned, 'invalid': invalid, 'added_count': len(added)})


@app.route('/api/admin/domain-requests')
@login_required
@role_required('admin')
def get_domain_requests():
    """Get all domain access requests"""
    status_filter = request.args.get('status', 'pending')
    query = DomainAccessRequest.query
    if status_filter and status_filter != 'all':
        query = query.filter_by(status=status_filter)
    requests = query.order_by(DomainAccessRequest.requested_at.desc()).all()
    return jsonify({'requests': [r.to_dict() for r in requests], 'total': len(requests)})


@app.route('/api/admin/domain-requests/<int:request_id>/approve', methods=['POST'])
@login_required
@role_required('admin')
def approve_domain_request(request_id):
    """Approve a domain access request"""
    access_request = DomainAccessRequest.query.get_or_404(request_id)
    if access_request.status != 'pending':
        return jsonify({'error': 'Request is not pending'}), 400
    data = request.json
    admin_notes = data.get('admin_notes', '').strip()
    access = TeacherDomainAccess(teacher_id=access_request.teacher_id, email_domain=access_request.email_domain, granted_by=session['user_id'], notes=f"Requested: {access_request.reason}")
    access_request.status = 'approved'
    access_request.reviewed_by = session['user_id']
    access_request.reviewed_at = datetime.utcnow()
    access_request.admin_notes = admin_notes
    db.session.add(access)
    db.session.commit()
    return jsonify({'message': 'Domain access request approved', 'access': access.to_dict(), 'request': access_request.to_dict()})


@app.route('/api/admin/domain-requests/<int:request_id>/deny', methods=['POST'])
@login_required
@role_required('admin')
def deny_domain_request(request_id):
    """Deny a domain access request"""
    access_request = DomainAccessRequest.query.get_or_404(request_id)
    if access_request.status != 'pending':
        return jsonify({'error': 'Request is not pending'}), 400
    data = request.json
    admin_notes = data.get('admin_notes', '').strip()
    if not admin_notes:
        return jsonify({'error': 'Please provide a reason for denial'}), 400
    access_request.status = 'denied'
    access_request.reviewed_by = session['user_id']
    access_request.reviewed_at = datetime.utcnow()
    access_request.admin_notes = admin_notes
    db.session.commit()
    return jsonify({'message': 'Domain access request denied', 'request': access_request.to_dict()})


@app.route('/api/admin/teacher/<int:teacher_id>/remove-all-restrictions', methods=['POST'])
@login_required
@role_required('admin')
def remove_all_teacher_restrictions(teacher_id):
    """Remove all domain restrictions from a teacher (grant full access)"""
    teacher = User.query.get_or_404(teacher_id)
    if teacher.role != 'teacher':
        return jsonify({'error': 'User is not a teacher'}), 400
    TeacherDomainAccess.query.filter_by(teacher_id=teacher_id).delete()
    db.session.commit()
    return jsonify({'message': 'All domain restrictions removed. Teacher now has full access to all students.'})


# ==================== TEACHER DOMAIN ACCESS ROUTES ====================

@app.route('/api/teacher/my-domain-access')
@login_required
@role_required('teacher')
@approved_required
def get_my_domain_access():
    """Get current teacher's domain access information"""
    teacher_id = session['user_id']
    access_records = TeacherDomainAccess.query.filter_by(teacher_id=teacher_id).all()
    stats = get_teacher_domain_statistics(teacher_id)
    pending_requests = DomainAccessRequest.query.filter_by(teacher_id=teacher_id, status='pending').all()
    all_domains = get_all_domains_in_system()
    assigned_domains = [r.email_domain for r in access_records]
    requested_domains = [r.email_domain for r in pending_requests]
    available_to_request = [d for d in all_domains if d['domain'] not in assigned_domains and d['domain'] not in requested_domains]
    return jsonify({
        'has_restrictions': stats['has_restrictions'],
        'assigned_domains': [r.to_dict() for r in access_records],
        'accessible_student_count': stats['accessible_student_count'],
        'restricted_domains': stats['restricted_domains'],
        'pending_requests': [r.to_dict() for r in pending_requests],
        'available_to_request': available_to_request
    })


@app.route('/api/teacher/request-domain-access', methods=['POST'])
@login_required
@role_required('teacher')
@approved_required
def request_domain_access():
    """Request access to a specific email domain"""
    teacher_id = session['user_id']
    data = request.json
    domain = data.get('domain', '').strip().lower()
    reason = data.get('reason', '').strip()
    if not domain:
        return jsonify({'error': 'Domain is required'}), 400
    if not reason:
        return jsonify({'error': 'Please provide a reason for this request'}), 400
    if '.' not in domain or '@' in domain:
        return jsonify({'error': 'Invalid domain format. Use format like: school.edu'}), 400
    existing_access = TeacherDomainAccess.query.filter_by(teacher_id=teacher_id, email_domain=domain).first()
    if existing_access:
        return jsonify({'error': 'You already have access to this domain'}), 400
    existing_request = DomainAccessRequest.query.filter_by(teacher_id=teacher_id, email_domain=domain, status='pending').first()
    if existing_request:
        return jsonify({'error': 'You already have a pending request for this domain'}), 400
    access_request = DomainAccessRequest(teacher_id=teacher_id, email_domain=domain, reason=reason)
    db.session.add(access_request)
    db.session.commit()
    return jsonify({'message': 'Domain access request submitted successfully', 'request': access_request.to_dict()}), 201


@app.route('/api/teacher/domain-requests')
@login_required
@role_required('teacher')
@approved_required
def get_my_domain_requests():
    """Get all domain access requests by the current teacher"""
    teacher_id = session['user_id']
    requests = DomainAccessRequest.query.filter_by(teacher_id=teacher_id).order_by(DomainAccessRequest.requested_at.desc()).all()
    return jsonify({'requests': [r.to_dict() for r in requests]})


@app.route('/api/teacher/domain-requests/<int:request_id>', methods=['DELETE'])
@login_required
@role_required('teacher')
@approved_required
def cancel_domain_request(request_id):
    """Cancel a pending domain access request"""
    teacher_id = session['user_id']
    access_request = DomainAccessRequest.query.get_or_404(request_id)
    if access_request.teacher_id != teacher_id:
        return jsonify({'error': 'Unauthorized'}), 403
    if access_request.status != 'pending':
        return jsonify({'error': 'Can only cancel pending requests'}), 400
    db.session.delete(access_request)
    db.session.commit()
    return jsonify({'message': 'Request cancelled successfully'})


@app.route('/api/admin/statistics')
@login_required
@role_required('admin')
def admin_statistics():
    stats = {
        'total_students': User.query.filter_by(role='student').count(),
        'total_teachers': User.query.filter_by(role='teacher', is_approved=True).count(),
        'pending_teachers': User.query.filter_by(role='teacher', is_approved=False).count(),
        'total_classes': Class.query.count(),
        'total_quizzes': QuizAttempt.query.count(),
        'total_questions': Question.query.count()
    }

    # Add prize system statistics if enabled
    if FEATURE_FLAGS.get('PRIZE_SYSTEM_ENABLED', False):
        stats['prize_stats'] = {
            'active_prizes': Prize.query.filter_by(is_active=True).count(),
            'total_schools': PrizeSchool.query.filter_by(is_active=True).count(),
            'pending_redemptions': PrizeRedemption.query.filter_by(status='pending').count(),
            'total_redemptions': PrizeRedemption.query.count()
        }

    return jsonify(stats)


@app.route('/api/admin/topics-list')
@login_required
@role_required('admin')
def admin_topics_list():
    """Get all distinct topics from questions table with counts"""
    from sqlalchemy import func

    # Query to get topics and their question counts
    topics_query = db.session.query(
        Question.topic,
        func.count(Question.id).label('count')
    ).group_by(Question.topic).order_by(Question.topic).all()

    # Format topic names for display
    def format_topic_name(topic):
        """Convert topic key to display name"""
        return topic.replace('_', ' ').title()

    topics = [
        {
            'value': topic,
            'name': format_topic_name(topic),
            'count': count
        }
        for topic, count in topics_query
    ]

    return jsonify({'topics': topics})


# ==================== REAL-TIME CLASS DASHBOARD ROUTES ====================

@app.route('/teacher/class-dashboard/<int:class_id>')
@login_required
@role_required('teacher')
@approved_required
def class_dashboard(class_id):
    """
    Enhanced Class Performance Dashboard
    - Shows ALL students by default
    - Smart search and filtering
    - Student selection for export
    - Hover tooltips with recommendations
    """
    class_obj = Class.query.get_or_404(class_id)

    # Verify teacher owns this class
    if class_obj.teacher_id != session['user_id']:
        flash('Unauthorized access to class', 'error')
        return redirect(url_for('teacher_classes_page'))

    return render_template('teacher_class_dashboard_v2.html',
                         class_id=class_id,
                         class_name=class_obj.name)

@app.route('/api/teacher/class/<int:class_id>/matrix-data')
@login_required
@role_required('teacher')
@approved_required
def get_class_matrix_data(class_id):
    """Get matrix data for class dashboard with Junior Cycle strands"""
    class_obj = Class.query.get_or_404(class_id)

    # Verify teacher owns this class
    if class_obj.teacher_id != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403

    # Get all students in class
    enrollments = ClassEnrollment.query.filter_by(class_id=class_id).all()

    # NEW: Get topics grouped by strand from database
    try:
        from sqlalchemy import text
        topics_query = db.session.execute(text("""
            SELECT DISTINCT strand, topic
            FROM questions
            WHERE strand IS NOT NULL
            ORDER BY
                CASE strand
                    WHEN 'Number' THEN 1
                    WHEN 'Algebra and Functions' THEN 2
                    WHEN 'Statistics and Probability' THEN 3
                    WHEN 'Senior Cycle - Algebra' THEN 4
                    WHEN 'Geometry and Trigonometry' THEN 5
                    ELSE 6
                END,
                CASE topic
                    -- Order for Number strand
                    WHEN 'arithmetic' THEN 1
                    WHEN 'multiplication_division' THEN 2
                    WHEN 'number_systems' THEN 3
                    WHEN 'bodmas' THEN 4
                    WHEN 'fractions' THEN 5
                    WHEN 'decimals' THEN 6
                    WHEN 'sets' THEN 7
                    -- Order for Algebra and Functions strand (Junior Cycle)
                    WHEN 'introductory_algebra' THEN 1
                    WHEN 'functions' THEN 2
                    WHEN 'patterns' THEN 3
                    WHEN 'solving_equations' THEN 4
                    WHEN 'simplifying_expressions' THEN 5
                    WHEN 'expanding_factorising' THEN 6
                    -- Order for Statistics and Probability strand
                    WHEN 'probability' THEN 1
                    WHEN 'descriptive_statistics' THEN 2
                    -- Order for Senior Cycle - Algebra strand
                    WHEN 'surds' THEN 1
                    WHEN 'complex_numbers_intro' THEN 2
                    WHEN 'complex_numbers_expanded' THEN 3
                    -- Default order for other topics
                    ELSE 10
                END,
                topic
        """)).fetchall()
    except Exception as e:
        print(f"Warning: Could not query strand column in matrix-data: {e}")
        topics_query = []

    # Build strands structure
    strands = {}
    all_topics = []

    for strand, topic in topics_query:
        if strand not in strands:
            strands[strand] = []
        strands[strand].append(topic)
        all_topics.append(topic)

    # If no strands found (strands not yet added), fall back to hardcoded list
    if not all_topics:
        all_topics = ['arithmetic', 'multiplication_division', 'number_systems',
                      'bodmas', 'fractions', 'decimals', 'sets',
                      'introductory_algebra', 'functions', 'patterns', 'solving_equations', 'simplifying_expressions', 'expanding_factorising', 'surds', 'complex_numbers_intro', 'complex_numbers_expanded',
                      'probability', 'descriptive_statistics']
        strands = {
            'Number': ['arithmetic', 'multiplication_division', 'number_systems',
                      'bodmas', 'fractions', 'decimals', 'sets'],
            'Algebra and Functions': ['functions', 'patterns', 'solving_equations',
                                      'simplifying_expressions', 'expanding_factorising',
                                      'surds', 'complex_numbers_intro', 'complex_numbers_expanded'],
        }

    difficulties = ['beginner', 'intermediate', 'advanced']

    # Build matrix data
    matrix_data = []

    for enrollment in enrollments:
        student = enrollment.student

        # Get student stats
        stats = UserStats.query.filter_by(user_id=student.id).first()

        student_data = {
            'student_id': student.id,
            'student_name': student.full_name,
            'total_points': stats.total_points if stats else 0,
            'level': stats.level if stats else 1,
            'modules': {}
        }

        # For each topic/difficulty combination
        for topic in all_topics:
            for difficulty in difficulties:
                module_key = f"{topic}_{difficulty}"

                # Get all attempts for this module
                attempts = QuizAttempt.query.filter_by(
                    user_id=student.id,
                    topic=topic,
                    difficulty=difficulty
                ).all()

                if attempts:
                    # Calculate average percentage
                    avg_percentage = sum(a.percentage for a in attempts) / len(attempts)
                    total_attempts = len(attempts)

                    # Determine color based on performance
                    if avg_percentage < 20:
                        color = 'grey'
                    elif avg_percentage <= 80:
                        color = 'yellow'
                    else:
                        color = 'green'

                    student_data['modules'][module_key] = {
                        'percentage': round(avg_percentage, 1),
                        'attempts': total_attempts,
                        'color': color,
                        'completed': True
                    }
                else:
                    # Not attempted yet
                    student_data['modules'][module_key] = {
                        'percentage': 0,
                        'attempts': 0,
                        'color': 'grey',
                        'completed': False
                    }

        matrix_data.append(student_data)

    return jsonify({
        'students': matrix_data,
        'topics': all_topics,
        'difficulties': difficulties,
        'strands': strands,  # NEW: Include strand grouping
        'class_name': class_obj.name,
        'total_students': len(matrix_data)
    })

@app.route('/api/teacher/class/<int:class_id>/dashboard-settings', methods=['GET', 'POST'])
@login_required
@role_required('teacher')
@approved_required
def dashboard_settings(class_id):
    """Save/load dashboard display settings"""
    class_obj = Class.query.get_or_404(class_id)

    # Verify teacher owns this class
    if class_obj.teacher_id != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403

    if request.method == 'POST':
        settings = request.json
        return jsonify({'message': 'Settings saved', 'settings': settings})
    else:
        # Return default settings
        return jsonify({
            'visible_modules': {
                'arithmetic': True,
                'fractions': True,
                'decimals': True,
                'bodmas': True,
                'functions': True,
                'sets': True
            },
            'visible_difficulties': {
                'beginner': True,
                'intermediate': True,
                'advanced': True
            },
            'refresh_rate': 10,
            'students_per_page': 12
        })

# ==================== QUESTION FLAGGING ROUTES ====================

@app.route('/api/student/flag-question', methods=['POST'])
def flag_question():
    """Flag a question - works for both registered and guest users"""
    data = request.json

    question_id = data.get('question_id')
    flag_type = data.get('flag_type')
    description = data.get('description', '').strip()
    guest_email = data.get('guest_email', '').strip()  # Optional for guests

    if not all([question_id, flag_type, description]):
        return jsonify({'error': 'Question ID, flag type, and description are required'}), 400

    if flag_type not in ['incorrect', 'ambiguous', 'typo', 'other']:
        return jsonify({'error': 'Invalid flag type'}), 400

    question = Question.query.get(question_id)
    if not question:
        return jsonify({'error': 'Question not found'}), 404

    # Check if user is logged in
    if 'user_id' in session:
        # Registered user
        flag = QuestionFlag(
            question_id=question_id,
            user_id=session['user_id'],
            flag_type=flag_type,
            description=description
        )
    else:
        # Guest user - use IP address or session ID as identifier
        import hashlib
        guest_id = request.remote_addr or 'unknown'
        # Create a hash of IP + user agent for better privacy
        user_agent = request.headers.get('User-Agent', '')
        guest_identifier = hashlib.md5(f"{guest_id}{user_agent}".encode()).hexdigest()[:16]

        flag = QuestionFlag(
            question_id=question_id,
            user_id=None,
            guest_identifier=guest_identifier,
            guest_email=guest_email if guest_email else None,
            flag_type=flag_type,
            description=description
        )

    db.session.add(flag)
    db.session.commit()

    return jsonify({
        'message': 'Question flagged successfully. An administrator will review it.',
        'flag': flag.to_dict()
    }), 201

@app.route('/api/student/my-flags')
def get_my_flags():
    """Get all flags submitted by current user or guest"""
    if 'user_id' in session:
        # Registered user
        flags = QuestionFlag.query.filter_by(user_id=session['user_id']).order_by(QuestionFlag.created_at.desc()).all()
    else:
        # Guest user - use their identifier
        import hashlib
        guest_id = request.remote_addr or 'unknown'
        user_agent = request.headers.get('User-Agent', '')
        guest_identifier = hashlib.md5(f"{guest_id}{user_agent}".encode()).hexdigest()[:16]

        flags = QuestionFlag.query.filter_by(guest_identifier=guest_identifier).order_by(QuestionFlag.created_at.desc()).all()
    return jsonify([f.to_dict() for f in flags])

@app.route('/api/admin/flags/pending')
@login_required
@role_required('admin')
def get_pending_flags():
    """Get all pending question flags"""
    flags = QuestionFlag.query.filter_by(status='pending').order_by(QuestionFlag.created_at.desc()).all()

    flags_with_questions = []
    for flag in flags:
        flag_dict = flag.to_dict()
        flag_dict['question'] = flag.question.to_dict()
        flags_with_questions.append(flag_dict)

    return jsonify(flags_with_questions)

@app.route('/api/admin/flags/all')
@login_required
@role_required('admin')
def get_all_flags():
    """Get all question flags"""
    status_filter = request.args.get('status')

    query = QuestionFlag.query
    if status_filter:
        query = query.filter_by(status=status_filter)

    flags = query.order_by(QuestionFlag.created_at.desc()).all()

    flags_with_questions = []
    for flag in flags:
        flag_dict = flag.to_dict()
        flag_dict['question'] = flag.question.to_dict()
        flags_with_questions.append(flag_dict)

    return jsonify(flags_with_questions)

@app.route('/api/admin/flag/<int:flag_id>/dismiss', methods=['POST'])
@login_required
@role_required('admin')
def dismiss_flag(flag_id):
    """Dismiss a flag without making changes"""
    flag = QuestionFlag.query.get_or_404(flag_id)
    data = request.json

    flag.status = 'dismissed'
    flag.admin_notes = data.get('notes', '')
    flag.resolved_at = datetime.utcnow()
    flag.resolved_by = session['user_id']

    db.session.commit()

    return jsonify({
        'message': 'Flag dismissed',
        'flag': flag.to_dict()
    })

@app.route('/api/admin/question/<int:question_id>')
@login_required
@role_required('admin')
def get_question_for_edit(question_id):
    """Get question details for editing"""
    question = Question.query.get_or_404(question_id)
    flags = QuestionFlag.query.filter_by(question_id=question_id).order_by(QuestionFlag.created_at.desc()).all()
    edits = QuestionEdit.query.filter_by(question_id=question_id).order_by(QuestionEdit.edited_at.desc()).all()

    return jsonify({
        'question': question.to_dict(),
        'flags': [f.to_dict() for f in flags],
        'edit_history': [e.to_dict() for e in edits]
    })

@app.route('/api/admin/all-questions')
@login_required
@role_required('admin')
def get_all_questions():
    """Get all questions with optional filters for management"""
    topic = request.args.get('topic', '')
    difficulty = request.args.get('difficulty', '')

    query = Question.query

    if topic:
        query = query.filter_by(topic=topic)
    if difficulty:
        query = query.filter_by(difficulty=difficulty)

    questions = query.order_by(Question.topic, Question.difficulty, Question.id).all()
    return jsonify([q.to_dict() for q in questions])

@app.route('/api/admin/question/<int:question_id>/edit', methods=['PUT'])
@login_required
@role_required('admin')
def edit_question(question_id):
    """Edit a question and track the changes"""
    question = Question.query.get_or_404(question_id)
    data = request.json

    edit_record = QuestionEdit(
        question_id=question_id,
        edited_by=session['user_id'],
        edit_type=data.get('edit_type', 'correction'),
        old_question_text=question.question_text,
        old_option_a=question.option_a,
        old_option_b=question.option_b,
        old_option_c=question.option_c,
        old_option_d=question.option_d,
        old_correct_answer=question.correct_answer,
        old_explanation=question.explanation,
        edit_notes=data.get('notes', '')
    )

    # Update topic if provided
    if 'topic' in data:
        question.topic = data['topic']

    # Update difficulty if provided
    if 'difficulty' in data:
        question.difficulty = data['difficulty']

    if 'question_text' in data:
        question.question_text = data['question_text']
        edit_record.new_question_text = data['question_text']
    else:
        edit_record.new_question_text = question.question_text

    if 'option_a' in data:
        question.option_a = data['option_a']
        edit_record.new_option_a = data['option_a']
    else:
        edit_record.new_option_a = question.option_a

    if 'option_b' in data:
        question.option_b = data['option_b']
        edit_record.new_option_b = data['option_b']
    else:
        edit_record.new_option_b = question.option_b

    if 'option_c' in data:
        question.option_c = data['option_c']
        edit_record.new_option_c = data['option_c']
    else:
        edit_record.new_option_c = question.option_c

    if 'option_d' in data:
        question.option_d = data['option_d']
        edit_record.new_option_d = data['option_d']
    else:
        edit_record.new_option_d = question.option_d

    if 'correct_answer' in data:
        question.correct_answer = data['correct_answer']
        edit_record.new_correct_answer = data['correct_answer']
    else:
        edit_record.new_correct_answer = question.correct_answer

    if 'explanation' in data:
        question.explanation = data['explanation']
        edit_record.new_explanation = data['explanation']
    else:
        edit_record.new_explanation = question.explanation

    db.session.add(edit_record)
    db.session.commit()

    if 'resolve_flag_ids' in data:
        for flag_id in data['resolve_flag_ids']:
            flag = QuestionFlag.query.get(flag_id)
            if flag and flag.question_id == question_id:
                flag.status = 'resolved'
                flag.resolved_at = datetime.utcnow()
                flag.resolved_by = session['user_id']
                flag.admin_notes = f"Question edited: {edit_record.edit_notes}"
        db.session.commit()

    return jsonify({
        'message': 'Question updated successfully',
        'question': question.to_dict(),
        'edit': edit_record.to_dict()
    })

@app.route('/api/admin/question/<int:question_id>/history')
@login_required
@role_required('admin')
def get_question_history(question_id):
    """Get complete edit history for a question"""
    question = Question.query.get_or_404(question_id)
    edits = QuestionEdit.query.filter_by(question_id=question_id).order_by(QuestionEdit.edited_at.desc()).all()

    return jsonify({
        'question': question.to_dict(),
        'edit_history': [e.to_dict() for e in edits]
    })

@app.route('/api/admin/questions/flagged')
@login_required
@role_required('admin')
def get_flagged_questions():
    """Get all questions that have pending flags"""
    flagged_question_ids = db.session.query(QuestionFlag.question_id).filter_by(status='pending').distinct().all()
    question_ids = [q[0] for q in flagged_question_ids]

    questions_with_flags = []
    for qid in question_ids:
        question = Question.query.get(qid)
        flags = QuestionFlag.query.filter_by(question_id=qid, status='pending').all()

        questions_with_flags.append({
            'question': question.to_dict(),
            'flag_count': len(flags),
            'flags': [f.to_dict() for f in flags]
        })

    return jsonify(questions_with_flags)

@app.route('/api/admin/flags/statistics')
@login_required
@role_required('admin')
def flag_statistics():
    """Get statistics about question flags"""
    stats = {
        'total_flags': QuestionFlag.query.count(),
        'pending_flags': QuestionFlag.query.filter_by(status='pending').count(),
        'resolved_flags': QuestionFlag.query.filter_by(status='resolved').count(),
        'dismissed_flags': QuestionFlag.query.filter_by(status='dismissed').count(),
        'flagged_questions': db.session.query(QuestionFlag.question_id).filter_by(status='pending').distinct().count(),
        'total_edits': QuestionEdit.query.count(),
        'by_flag_type': {}
    }

    for flag_type in ['incorrect', 'ambiguous', 'typo', 'other']:
        stats['by_flag_type'][flag_type] = QuestionFlag.query.filter_by(flag_type=flag_type, status='pending').count()

    return jsonify(stats)



# GET all users endpoint (frontend expects /api/admin/users plural)
@app.route('/api/admin/users', methods=['GET'])
@login_required
@role_required('admin')
def admin_get_all_users():
    """Get all users for admin management"""
    users = User.query.order_by(User.created_at.desc()).all()

    users_data = []
    for user in users:
        stats = UserStats.query.filter_by(user_id=user.id).first()
        quiz_count = QuizAttempt.query.filter_by(user_id=user.id).count()

        users_data.append({
            'id': user.id,
            'username': user.full_name,  # FIXED: Use full_name instead of username
            'email': user.email,
            'role': user.role,
            'is_approved': user.is_approved,
            'created_at': user.created_at.isoformat() if user.created_at else None,
            'total_quizzes': quiz_count,
            'total_points': stats.total_points if stats else 0,
            'level': stats.level if stats else 1
        })

    return jsonify(users_data), 200



if __name__ == '__main__':
    with app.app_context():
        db.create_all()

        # Create default admin if doesn't exist
        admin = User.query.filter_by(email='admin@agentmath.app').first()
        if not admin:
            admin = User(
                email='admin@agentmath.app',
                full_name='System Administrator',
                role='admin',
                is_approved=True
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print("Default admin created: admin@agentmath.app / admin123")

        # Create default badges if they don't exist
        if Badge.query.count() == 0:
            default_badges = [
                # Beginner badges
                Badge(name='First Steps', description='Complete your first quiz', icon='fa-star',
                      category='beginner', requirement_type='quizzes_completed', requirement_value=1,
                      points=10, color='yellow'),
                Badge(name='Curious Learner', description='Complete 5 quizzes', icon='fa-book',
                      category='progress', requirement_type='quizzes_completed', requirement_value=5,
                      points=20, color='blue'),
                Badge(name='Dedicated Student', description='Complete 10 quizzes', icon='fa-graduation-cap',
                      category='progress', requirement_type='quizzes_completed', requirement_value=10,
                      points=30, color='purple'),
                Badge(name='Math Enthusiast', description='Complete 25 quizzes', icon='fa-heart',
                      category='progress', requirement_type='quizzes_completed', requirement_value=25,
                      points=50, color='red'),
                Badge(name='Quiz Master', description='Complete 50 quizzes', icon='fa-trophy',
                      category='progress', requirement_type='quizzes_completed', requirement_value=50,
                      points=100, color='gold'),

                # Streak badges
                Badge(name='Week Warrior', description='Practice 7 days in a row', icon='fa-bolt',
                      category='streak', requirement_type='streak_days', requirement_value=7,
                      points=40, color='orange'),
                Badge(name='Unstoppable', description='Practice 14 days in a row', icon='fa-rocket',
                      category='streak', requirement_type='streak_days', requirement_value=14,
                      points=75, color='red'),

                # Mastery badges
                Badge(name='Topic Master', description='Master any topic (all 3 difficulties)', icon='fa-certificate',
                      category='mastery', requirement_type='topics_mastered', requirement_value=1,
                      points=30, color='green'),
                Badge(name='Subject Expert', description='Master 3 different topics', icon='fa-brain',
                      category='mastery', requirement_type='topics_mastered', requirement_value=3,
                      points=75, color='purple'),
                Badge(name='Mathematics Genius', description='Master 5 different topics', icon='fa-infinity',
                      category='mastery', requirement_type='topics_mastered', requirement_value=5,
                      points=150, color='gold'),

                # Accuracy badges
                Badge(name='Perfect Score', description='Get 100% on a quiz', icon='fa-gem',
                      category='accuracy', requirement_type='perfect_scores', requirement_value=1,
                      points=15, color='cyan'),
                Badge(name='Perfectionist', description='Get 5 perfect scores', icon='fa-star',
                      category='accuracy', requirement_type='perfect_scores', requirement_value=5,
                      points=50, color='gold'),
                Badge(name='High Achiever', description='Score 90%+ on 10 quizzes', icon='fa-bullseye',
                      category='accuracy', requirement_type='high_scores', requirement_value=10,
                      points=40, color='green'),
                Badge(name='Excellence Personified', description='Score 90%+ on 25 quizzes', icon='fa-crown',
                      category='accuracy', requirement_type='high_scores', requirement_value=25,
                      points=100, color='gold'),
            ]

            for badge in default_badges:
                db.session.add(badge)

            db.session.commit()
            print(f"✅ Created {len(default_badges)} default badges")

    app.run(debug=True)


# ============================================================
# Minimal class actions via simple HTML forms (stable)
# ============================================================

@app.route('/logout', methods=['GET'])
def logout_simple():
    session.clear()
    try:
        return redirect(url_for('index'))
    except Exception:
        return redirect('/')

@app.route('/teacher/class/<int:class_id>/rename', methods=['POST'], endpoint='teacher_simple_rename_class')
@login_required
@role_required('teacher')
@approved_required
def teacher_simple_rename_class(class_id):
    class_obj = Class.query.get_or_404(class_id)
    if class_obj.teacher_id != session.get('user_id'):
        return jsonify({'error': 'Unauthorized'}), 403

    new_name = (request.form.get('new_name') or '').strip()
    if not new_name:
        flash('Class name cannot be empty.', 'error')
        return redirect('/teacher/classes')

    existing = Class.query.filter(
        Class.teacher_id == session['user_id'],
        Class.name == new_name,
        Class.id != class_id
    ).first()
    if existing:
        flash('You already have a class with that name.', 'error')
        return redirect('/teacher/classes')

    class_obj.name = new_name
    db.session.commit()
    flash('Class renamed successfully.', 'success')
    return redirect('/teacher/classes')

@app.route('/teacher/class/<int:class_id>/delete', methods=['POST'], endpoint='teacher_simple_delete_class')
@login_required
@role_required('teacher')
@approved_required
def teacher_simple_delete_class(class_id):
    class_obj = Class.query.get_or_404(class_id)
    if class_obj.teacher_id != session.get('user_id'):
        return jsonify({'error': 'Unauthorized'}), 403

    ClassEnrollment.query.filter_by(class_id=class_id).delete()
    db.session.delete(class_obj)
    db.session.commit()
    flash('Class deleted.', 'success')
    return redirect('/teacher/classes')

# ==================== DUAL GUEST SYSTEM ====================
# Supports both casual guests and repeat guests with codes

# Animal codes for repeat guests
# Curated list of avatar-friendly animals for guest codes
# These all have matching avatar images in the shop
AVATAR_ANIMALS = [
    'panda', 'fox', 'cat', 'owl', 'lion', 'bear', 'wolf', 'rabbit', 'tiger', 'penguin',
    'koala', 'elephant', 'monkey', 'dog', 'dolphin', 'horse', 'deer', 'eagle', 'parrot', 'turtle'
]

# Legacy list for reference - DO NOT USE for new codes
# These were the old animals, some of which don't make good avatars
LEGACY_ANIMALS = [
    'ant', 'ape', 'bat', 'bear', 'bee', 'bird', 'cat', 'clam', 'cod', 'cow',
    'crab', 'crow', 'deer', 'dog', 'dove', 'duck', 'eagle', 'eel', 'elk', 'fish',
    'fly', 'fox', 'frog', 'gnat', 'goat', 'goose', 'hawk', 'hog', 'horse', 'jay',
    'lark', 'lion', 'loon', 'lynx', 'mink', 'mole', 'moth', 'mouse', 'mule', 'newt',
    'orca', 'owl', 'ox', 'panda', 'pig', 'puma', 'rat', 'ray', 'seal', 'shark',
    'sheep', 'shrew', 'sloth', 'slug', 'snail', 'snake', 'swan', 'tiger', 'toad', 'trout',
    'viper', 'vole', 'wasp', 'whale', 'wolf', 'worm', 'yak', 'zebra', 'bison', 'boar',
    'bunny', 'camel', 'cobra', 'coral', 'crane', 'dingo', 'drake', 'gecko', 'hippo', 'hyena',
    'koala', 'lemur', 'llama', 'moose', 'otter', 'pony', 'quail', 'raven', 'rhino', 'robin',
    'skunk', 'squid', 'stork', 'tapir', 'tern', 'tuna', 'weasel', 'betta', 'finch', 'guppy'
]

# Use AVATAR_ANIMALS for new guest codes
ANIMALS = AVATAR_ANIMALS

def generate_guest_code():
    """Generate unique animal code (e.g., panda42)"""
    max_attempts = 100

    for _ in range(max_attempts):
        animal = random.choice(ANIMALS)
        number = random.randint(0, 99)
        code = f"{animal}{number:02d}"

        # Check if code is already taken
        from sqlalchemy import text
        existing = db.session.execute(
            text("SELECT 1 FROM guest_users WHERE guest_code = :code"),
            {"code": code}
        ).fetchone()

        if not existing:
            return code

    raise Exception("Could not generate unique guest code. Please try again.")


def get_current_user_info():
    """
    Get user info for either full account, repeat guest, or casual guest
    Returns dict with user data or None
    """
    # Check full account
    if 'user_id' in session and 'guest_code' not in session and not session.get('is_guest'):
        user = User.query.get(session['user_id'])
        if user and user.email != 'guest@agentmath.app':
            return {
                'type': 'full',
                'id': user.id,
                'name': user.full_name,
                'email': user.email,
                'role': user.role,
                'total_score': getattr(user, 'total_score', 0),
                'quizzes_completed': getattr(user, 'quizzes_completed', 0)
            }

    # Check repeat guest
    if 'guest_code' in session:
        from sqlalchemy import text
        result = db.session.execute(
            text("""SELECT guest_code, total_score, quizzes_completed, created_at, last_active
               FROM guest_users WHERE guest_code = :code AND is_active = 1"""),
            {"code": session['guest_code']}
        ).fetchone()

        if result:
            return {
                'type': 'repeat_guest',
                'guest_code': result[0],
                'name': f"Guest {result[0].title()}",
                'total_score': result[1] or 0,
                'quizzes_completed': result[2] or 0,
                'created_at': result[3],
                'last_active': result[4]
            }

    # Check casual guest (shared guest@agentmath.app user)
    if session.get('is_guest') and 'user_id' in session:
        user = User.query.get(session['user_id'])
        if user and user.email == 'guest@agentmath.app':
            return {
                'type': 'casual_guest',
                'name': 'Guest User',
                'session_id': session.get('guest_session_id', 'unknown')
            }

    return None


def update_guest_last_active(guest_code):
    """Update last_active timestamp for repeat guest"""
    from sqlalchemy import text
    db.session.execute(
        text("UPDATE guest_users SET last_active = :now WHERE guest_code = :code"),
        {"now": datetime.utcnow(), "code": guest_code}
    )
    db.session.commit()


# ==================== CASUAL GUEST ROUTES ====================

@app.route('/api/casual-guest-start', methods=['POST'])
def casual_guest_start():
    """Initialize casual guest session (temporary, no code)"""
    try:
        session.clear()

        # Get or create the shared casual guest user
        guest_user = User.query.filter_by(email='guest@agentmath.app').first()

        if not guest_user:
            guest_user = User(
                email='guest@agentmath.app',
                password_hash='no_password_required',
                full_name='Guest User',
                role='student',
                is_approved=True
            )
            db.session.add(guest_user)
            db.session.commit()

        # Set up casual guest session
        session['is_guest'] = True
        session['guest_session_id'] = str(uuid.uuid4())
        session['user_id'] = guest_user.id
        session['role'] = 'student'
        session['guest_type'] = 'casual'

        return jsonify({
            'success': True,
            'message': 'Casual guest session started',
            'redirect': '/student'
        }), 200

    except Exception as e:
        print(f"Error starting casual guest session: {e}")
        db.session.rollback()
        return jsonify({'error': f'Failed to start guest session: {str(e)}'}), 500


# ==================== REPEAT GUEST ROUTES ====================

@app.route('/api/repeat-guest/generate', methods=['POST'])
def generate_repeat_guest():
    """Generate new repeat guest code"""
    try:
        from sqlalchemy import text

        # Generate unique code
        code = generate_guest_code()

        # Create guest user in database
        db.session.execute(text("""
            INSERT INTO guest_users (guest_code, created_at, last_active)
            VALUES (:code, :now, :now)
        """), {"code": code, "now": datetime.utcnow()})
        db.session.commit()

        # AVATAR: Auto-setup avatar for new guest
        animal = get_animal_from_guest_code(code)
        avatar_animal = animal if animal else 'panda'

        if FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False):
            try:
                # Grant default items to new guest
                grant_default_avatar_items(guest_code=code)

                # Create equipped avatar with their animal
                equipped = UserAvatarEquipped(
                    guest_code=code,
                    animal_key=avatar_animal,
                    hat_key='none',
                    glasses_key='none',
                    background_key='none',
                    accessory_key='none'
                )
                db.session.add(equipped)
                db.session.commit()
            except Exception as avatar_error:
                print(f"Avatar setup error (non-fatal): {avatar_error}")
                # Don't fail the guest creation if avatar setup fails

        return jsonify({
            'success': True,
            'guest_code': code,
            'message': f'Your code is: {code}',
            'animal': avatar_animal  # Return animal for frontend display
        }), 200

    except Exception as e:
        print(f"Error generating guest code: {e}")
        db.session.rollback()
        return jsonify({'error': 'Failed to generate code. Please try again.'}), 500


@app.route('/api/repeat-guest/login', methods=['POST'])
def repeat_guest_login():
    """Login with repeat guest code"""
    try:
        from sqlalchemy import text
        data = request.json
        code = data.get('guest_code', '').strip().lower()

        if not code:
            return jsonify({'error': 'Please enter your guest code'}), 400

        # Check if code exists and is active
        result = db.session.execute(
            text("SELECT guest_code FROM guest_users WHERE guest_code = :code AND is_active = 1"),
            {"code": code}
        ).fetchone()

        if not result:
            return jsonify({'error': 'Code not found. Please check and try again.'}), 404

        # Get or create the shared guest user for repeat guests
        guest_user = User.query.filter_by(email='guest@agentmath.app').first()

        if not guest_user:
            guest_user = User(
                email='guest@agentmath.app',
                password_hash='no_password_required',
                full_name='Guest User',
                role='student',
                is_approved=True
            )
            db.session.add(guest_user)
            db.session.commit()

        # Set up repeat guest session
        session.clear()
        session['guest_code'] = code
        session['user_id'] = guest_user.id  # CRITICAL: Set user_id for @login_required
        session['role'] = 'student'
        session['guest_type'] = 'repeat'

        # Update last active
        update_guest_last_active(code)

        # AVATAR: Ensure returning guest has avatar setup
        animal = get_animal_from_guest_code(code)
        if FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False):
            try:
                # Check if guest has equipped avatar
                existing_equipped = UserAvatarEquipped.query.filter_by(guest_code=code).first()

                if not existing_equipped:
                    # First time with avatar system - set up defaults
                    grant_default_avatar_items(guest_code=code)

                    equipped = UserAvatarEquipped(
                        guest_code=code,
                        animal_key=animal if animal else 'panda',
                        hat_key='none',
                        glasses_key='none',
                        background_key='none',
                        accessory_key='none'
                    )
                    db.session.add(equipped)
                    db.session.commit()
            except Exception as avatar_error:
                print(f"Avatar setup error (non-fatal): {avatar_error}")

        return jsonify({
            'success': True,
            'message': 'Welcome back!',
            'redirect': '/student',
            'animal': animal  # Return animal for frontend display
        }), 200

    except Exception as e:
        print(f"Error logging in guest: {e}")
        db.session.rollback()
        return jsonify({'error': 'Login failed. Please try again.'}), 500


@app.route('/api/repeat-guest/stats')
def repeat_guest_stats():
    """Get stats for current repeat guest"""
    if 'guest_code' not in session:
        return jsonify({'error': 'Not logged in'}), 401

    try:
        from sqlalchemy import text
        code = session['guest_code']

        # Get stats
        result = db.session.execute(text("""
            SELECT
                total_score,
                quizzes_completed,
                (SELECT COUNT(*) FROM guest_badges WHERE guest_code = :code) as badges_earned
            FROM guest_users
            WHERE guest_code = :code
        """), {"code": code}).fetchone()

        if result:
            return jsonify({
                'total_score': result[0] or 0,
                'quizzes_completed': result[1] or 0,
                'badges_earned': result[2] or 0
            }), 200

        return jsonify({'error': 'Stats not found'}), 404

    except Exception as e:
        print(f"Error getting guest stats: {e}")
        return jsonify({'error': 'Failed to load stats'}), 500


@app.route('/api/repeat-guest/convert', methods=['POST'])
def convert_guest_to_full():
    """Convert repeat guest to full account"""
    if 'guest_code' not in session:
        return jsonify({'error': 'Not logged in as guest'}), 401

    try:
        from sqlalchemy import text
        data = request.json

        email = data.get('email', '').strip()
        password = data.get('password', '').strip()
        full_name = data.get('full_name', '').strip()

        # Validation
        if not email or not password or not full_name:
            return jsonify({'error': 'All fields required'}), 400

        if len(password) < 6:
            return jsonify({'error': 'Password must be at least 6 characters'}), 400

        # Check if email already exists
        existing = User.query.filter_by(email=email).first()
        if existing:
            return jsonify({'error': 'Email already registered'}), 400

        guest_code = session['guest_code']

        # Get guest data
        guest_data = db.session.execute(text("""
            SELECT total_score, quizzes_completed
            FROM guest_users
            WHERE guest_code = :code
        """), {"code": guest_code}).fetchone()

        # Create new full user account
        new_user = User(
            email=email,
            full_name=full_name,
            role='student',
            is_approved=True
        )
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.flush()

        # Migrate quiz attempts
        db.session.execute(text("""
            INSERT INTO quiz_attempts (user_id, topic, difficulty, score, total_questions, completed_at)
            SELECT :user_id, topic, difficulty, score, total_questions, completed_at
            FROM guest_quiz_attempts
            WHERE guest_code = :code
        """), {"user_id": new_user.id, "code": guest_code})

        # Migrate badges
        db.session.execute(text("""
            INSERT INTO user_badges (user_id, badge_id, earned_at)
            SELECT :user_id, badge_id, earned_at
            FROM guest_badges
            WHERE guest_code = :code
        """), {"user_id": new_user.id, "code": guest_code})

        # Deactivate guest account
        db.session.execute(
            text("UPDATE guest_users SET is_active = 0 WHERE guest_code = :code"),
            {"code": guest_code}
        )

        db.session.commit()

        # Switch session to full account
        session.clear()
        session['user_id'] = new_user.id
        session['role'] = 'student'

        return jsonify({
            'success': True,
            'message': 'Account upgraded successfully!',
            'redirect': '/student'
        }), 200

    except Exception as e:
        db.session.rollback()
        print(f"Error converting guest account: {e}")
        return jsonify({'error': 'Upgrade failed. Please try again.'}), 500


@app.route('/api/guest-leaderboard')
def guest_leaderboard():
    """
    Universal leaderboard showing top 20 guest users across all codes.
    Ranked by total score (sum of all correct answers).
    Public endpoint - no authentication required.
    """
    try:
        from sqlalchemy import text

        # Query to get aggregated stats for each guest_code
        query = text("""
            SELECT
                guest_code,
                COUNT(*) as total_quizzes,
                SUM(score) as total_score,
                SUM(total_questions) as total_questions_attempted,
                ROUND(AVG(CAST(score AS FLOAT) / CAST(total_questions AS FLOAT) * 100), 1) as avg_percentage,
                MIN(completed_at) as first_quiz_date,
                MAX(completed_at) as last_quiz_date
            FROM guest_quiz_attempts
            WHERE guest_code IS NOT NULL
            GROUP BY guest_code
            HAVING COUNT(*) > 0
            ORDER BY total_score DESC
            LIMIT 20
        """)

        results = db.session.execute(query).fetchall()

        leaderboard = []
        for rank, row in enumerate(results, start=1):
            # Generate guest display name from code
            # Uses first 6 characters of code for anonymity
            guest_display = f"Guest-{row.guest_code[:6]}" if len(row.guest_code) > 6 else f"Guest-{row.guest_code}"

            leaderboard.append({
                'rank': rank,
                'guest_code': row.guest_code,  # Full code (not displayed to others)
                'display_name': guest_display,  # Public display name
                'total_quizzes': row.total_quizzes,
                'total_score': row.total_score,
                'total_questions': row.total_questions_attempted,
                'avg_percentage': float(row.avg_percentage) if row.avg_percentage else 0.0,
                'first_quiz': row.first_quiz_date[:10] if row.first_quiz_date else None,  # Extract date part from string
                'last_quiz': row.last_quiz_date[:10] if row.last_quiz_date else None  # Extract date part from string
            })

        return jsonify({
            'success': True,
            'leaderboard': leaderboard,
            'total_guests': len(leaderboard)
        })

    except Exception as e:
        print(f"❌ Error fetching guest leaderboard: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Unable to load leaderboard',
            'leaderboard': []
        }), 500


def cleanup_inactive_guests(days=30):
    """
    Delete guest accounts that haven't been used in X days
    Returns number of deleted accounts
    """
    from sqlalchemy import text
    cutoff_date = datetime.utcnow() - timedelta(days=days)

    result = db.session.execute(text("""
        DELETE FROM guest_users
        WHERE last_active < :cutoff AND is_active = 1
    """), {"cutoff": cutoff_date})

    db.session.commit()
    return result.rowcount


# ==================== PRIZE SYSTEM ADMIN ROUTES ====================
# Admin interface for managing prizes, schools, and redemptions

@app.route('/admin/prizes')
@login_required
@role_required('admin')
def admin_prizes():
    """Prize system admin dashboard"""
    if not FEATURE_FLAGS.get('PRIZE_SYSTEM_ENABLED', False):
        flash('Prize system is not enabled.', 'warning')
        return redirect(url_for('admin_dashboard'))

    return render_template('admin_prizes.html')


@app.route('/api/admin/prizes/settings', methods=['GET'])
@login_required
@role_required('admin')
def get_prize_settings():
    """Get global prize system settings"""
    settings = {
        'global_points_multiplier': float(SystemSetting.get('global_points_multiplier', 5.0)),
        'prize_expiry_days': int(SystemSetting.get('prize_expiry_days', 30)),
        'raffle_enabled': SystemSetting.get('raffle_enabled', 'true') == 'true',
        'level_lock_enabled': SystemSetting.get('prize_level_lock_enabled', 'false') == 'true'
    }
    return jsonify(settings)


@app.route('/api/admin/prizes/settings', methods=['POST'])
@login_required
@role_required('admin')
def update_prize_settings():
    """Update global prize system settings"""
    data = request.get_json()
    user_id = session.get('user_id')

    if 'global_points_multiplier' in data:
        SystemSetting.set('global_points_multiplier', float(data['global_points_multiplier']),
                          'Global multiplier for prize point costs', user_id)

    if 'prize_expiry_days' in data:
        SystemSetting.set('prize_expiry_days', int(data['prize_expiry_days']),
                          'Days before unclaimed prizes expire', user_id)

    if 'raffle_enabled' in data:
        SystemSetting.set('raffle_enabled', 'true' if data['raffle_enabled'] else 'false',
                          'Whether raffle system is enabled', user_id)

    if 'level_lock_enabled' in data:
        SystemSetting.set('prize_level_lock_enabled', 'true' if data['level_lock_enabled'] else 'false',
                          'Whether prizes require minimum level to redeem', user_id)

    return jsonify({'success': True, 'message': 'Settings updated'})


# ----- Global Prize Catalogue -----

@app.route('/api/admin/prizes/catalogue', methods=['GET'])
@login_required
@role_required('admin')
def get_prize_catalogue():
    """Get all prizes in the global catalogue"""
    prizes = Prize.query.order_by(Prize.tier, Prize.sort_order, Prize.name).all()
    global_multiplier = float(SystemSetting.get('global_points_multiplier', 5.0))

    result = []
    for prize in prizes:
        p = prize.to_dict()
        p['effective_cost'] = int(prize.base_point_cost * global_multiplier)
        result.append(p)

    return jsonify({
        'prizes': result,
        'global_multiplier': global_multiplier
    })


@app.route('/api/admin/prizes/catalogue', methods=['POST'])
@login_required
@role_required('admin')
def create_prize():
    """Create a new prize in the global catalogue"""
    data = request.get_json()

    prize = Prize(
        name=data['name'],
        description=data.get('description', ''),
        base_point_cost=int(data['base_point_cost']),
        tier=data.get('tier', 'bronze'),
        prize_type=data.get('prize_type', 'physical'),
        minimum_level=int(data.get('minimum_level', 0)),
        emoji=data.get('emoji', '🎁'),
        sort_order=data.get('sort_order', 0),
        is_active=data.get('is_active', True)
    )

    db.session.add(prize)
    db.session.commit()

    return jsonify({'success': True, 'prize': prize.to_dict()})


@app.route('/api/admin/prizes/catalogue/<int:prize_id>', methods=['PUT'])
@login_required
@role_required('admin')
def update_prize(prize_id):
    """Update a prize in the global catalogue"""
    prize = Prize.query.get_or_404(prize_id)
    data = request.get_json()

    if 'name' in data:
        prize.name = data['name']
    if 'description' in data:
        prize.description = data['description']
    if 'base_point_cost' in data:
        prize.base_point_cost = int(data['base_point_cost'])
    if 'tier' in data:
        prize.tier = data['tier']
    if 'prize_type' in data:
        prize.prize_type = data['prize_type']
    if 'minimum_level' in data:
        prize.minimum_level = int(data['minimum_level'])
    if 'emoji' in data:
        prize.emoji = data['emoji']
    if 'sort_order' in data:
        prize.sort_order = int(data['sort_order'])
    if 'is_active' in data:
        prize.is_active = data['is_active']

    db.session.commit()

    return jsonify({'success': True, 'prize': prize.to_dict()})


@app.route('/api/admin/prizes/catalogue/<int:prize_id>', methods=['DELETE'])
@login_required
@role_required('admin')
def delete_prize(prize_id):
    """Delete a prize from the global catalogue (if no redemptions)"""
    prize = Prize.query.get_or_404(prize_id)

    # Check for redemptions
    redemption_count = PrizeRedemption.query.filter_by(prize_id=prize_id).count()
    if redemption_count > 0:
        return jsonify({
            'success': False,
            'error': f'Cannot delete: {redemption_count} redemptions exist for this prize. Deactivate instead.'
        }), 400

    # Delete school overrides first
    SchoolPrize.query.filter_by(prize_id=prize_id).delete()

    db.session.delete(prize)
    db.session.commit()

    return jsonify({'success': True, 'message': 'Prize deleted'})


# ----- Schools Management -----

@app.route('/api/admin/prizes/schools', methods=['GET'])
@login_required
@role_required('admin')
def get_prize_schools():
    """Get all schools in the prize programme"""
    schools = PrizeSchool.query.order_by(PrizeSchool.name).all()
    return jsonify({'schools': [s.to_dict() for s in schools]})


@app.route('/api/admin/prizes/schools', methods=['POST'])
@login_required
@role_required('admin')
def create_prize_school():
    """Add a new school to the prize programme"""
    data = request.get_json()

    school = PrizeSchool(
        name=data['name'],
        roll_number=data.get('roll_number'),
        county=data.get('county'),
        address=data.get('address'),
        status='approved',  # Admin-created schools are auto-approved
        points_multiplier=float(data.get('points_multiplier', 1.0)),
        rep_name=data.get('rep_name'),
        rep_email=data.get('rep_email'),
        approved_at=datetime.utcnow(),
        approved_by=session.get('user_id')
    )

    db.session.add(school)
    db.session.commit()

    return jsonify({'success': True, 'school': school.to_dict()})


@app.route('/api/admin/prizes/schools/<int:school_id>', methods=['PUT'])
@login_required
@role_required('admin')
def update_prize_school(school_id):
    """Update a school in the prize programme"""
    school = PrizeSchool.query.get_or_404(school_id)
    data = request.get_json()

    if 'name' in data:
        school.name = data['name']
    if 'roll_number' in data:
        school.roll_number = data['roll_number']
    if 'county' in data:
        school.county = data['county']
    if 'address' in data:
        school.address = data['address']
    if 'status' in data:
        old_status = school.status
        school.status = data['status']
        if old_status != 'approved' and data['status'] == 'approved':
            school.approved_at = datetime.utcnow()
            school.approved_by = session.get('user_id')
    if 'points_multiplier' in data:
        school.points_multiplier = float(data['points_multiplier'])
    if 'rep_name' in data:
        school.rep_name = data['rep_name']
    if 'rep_email' in data:
        school.rep_email = data['rep_email']
    if 'notes' in data:
        school.notes = data['notes']

    db.session.commit()

    return jsonify({'success': True, 'school': school.to_dict()})


@app.route('/api/admin/prizes/schools/<int:school_id>', methods=['DELETE'])
@login_required
@role_required('admin')
def delete_prize_school(school_id):
    """Delete a school from the prize programme"""
    school = PrizeSchool.query.get_or_404(school_id)

    # Check for redemptions
    redemption_count = PrizeRedemption.query.filter_by(school_id=school_id).count()
    if redemption_count > 0:
        return jsonify({
            'success': False,
            'error': f'Cannot delete: {redemption_count} redemptions exist for this school. Suspend instead.'
        }), 400

    # Delete school prizes
    SchoolPrize.query.filter_by(school_id=school_id).delete()

    db.session.delete(school)
    db.session.commit()

    return jsonify({'success': True, 'message': 'School deleted'})


@app.route('/api/admin/prizes/schools/<int:school_id>/prizes', methods=['GET'])
@login_required
@role_required('admin')
def get_school_prizes(school_id):
    """Get all prizes available at a specific school (with overrides)"""
    school = PrizeSchool.query.get_or_404(school_id)

    # Get all global prizes
    global_prizes = Prize.query.filter_by(is_active=True).order_by(Prize.tier, Prize.sort_order).all()

    # Get school overrides
    overrides = {sp.prize_id: sp for sp in SchoolPrize.query.filter_by(school_id=school_id).all()}

    # Get school-specific prizes (where prize_id is NULL)
    school_specific = SchoolPrize.query.filter_by(school_id=school_id, prize_id=None).all()

    result = []

    # Add global prizes with override info
    for prize in global_prizes:
        override = overrides.get(prize.id)
        item = prize.to_dict(school=school)
        item['override'] = override.to_dict() if override else None
        item['is_enabled'] = override.is_enabled if override else True
        item['stock_available'] = override.stock_available if override else None
        result.append(item)

    # Add school-specific prizes
    for sp in school_specific:
        result.append({
            'id': None,
            'school_prize_id': sp.id,
            'name': sp.custom_name,
            'description': sp.custom_description,
            'emoji': sp.custom_emoji,
            'point_cost': sp.point_cost_override,
            'is_school_specific': True,
            'is_enabled': sp.is_enabled,
            'stock_available': sp.stock_available
        })

    return jsonify({
        'school': school.to_dict(),
        'prizes': result
    })


@app.route('/api/admin/prizes/schools/<int:school_id>/prizes', methods=['POST'])
@login_required
@role_required('admin')
def create_school_prize(school_id):
    """Create a school-specific prize or override"""
    school = PrizeSchool.query.get_or_404(school_id)
    data = request.get_json()

    school_prize = SchoolPrize(
        school_id=school_id,
        prize_id=data.get('prize_id'),  # NULL for school-specific
        custom_name=data.get('custom_name'),
        custom_description=data.get('custom_description'),
        custom_emoji=data.get('custom_emoji', '🎁'),
        point_cost_override=data.get('point_cost_override'),
        stock_available=data.get('stock_available'),
        is_enabled=data.get('is_enabled', True)
    )

    db.session.add(school_prize)
    db.session.commit()

    return jsonify({'success': True, 'school_prize': school_prize.to_dict()})


@app.route('/api/admin/prizes/schools/<int:school_id>/prizes/<int:school_prize_id>', methods=['PUT'])
@login_required
@role_required('admin')
def update_school_prize(school_id, school_prize_id):
    """Update a school-specific prize or override"""
    school_prize = SchoolPrize.query.get_or_404(school_prize_id)

    if school_prize.school_id != school_id:
        return jsonify({'error': 'Prize does not belong to this school'}), 400

    data = request.get_json()

    if 'custom_name' in data:
        school_prize.custom_name = data['custom_name']
    if 'custom_description' in data:
        school_prize.custom_description = data['custom_description']
    if 'custom_emoji' in data:
        school_prize.custom_emoji = data['custom_emoji']
    if 'point_cost_override' in data:
        school_prize.point_cost_override = data['point_cost_override']
    if 'stock_available' in data:
        school_prize.stock_available = data['stock_available']
    if 'is_enabled' in data:
        school_prize.is_enabled = data['is_enabled']

    db.session.commit()

    return jsonify({'success': True, 'school_prize': school_prize.to_dict()})


# ----- School Requests -----

@app.route('/api/admin/prizes/school-requests', methods=['GET'])
@login_required
@role_required('admin')
def get_school_requests():
    """Get all pending school requests"""
    requests = SchoolRequest.query.order_by(SchoolRequest.created_at.desc()).all()
    return jsonify({'requests': [r.to_dict() for r in requests]})


@app.route('/api/admin/prizes/school-requests/<int:request_id>/approve', methods=['POST'])
@login_required
@role_required('admin')
def approve_school_request(request_id):
    """Approve a school request and create the school"""
    school_request = SchoolRequest.query.get_or_404(request_id)
    data = request.get_json() or {}

    # Create the school
    school = PrizeSchool(
        name=data.get('name', school_request.school_name),
        county=data.get('county', school_request.county),
        status='approved',
        rep_email=data.get('rep_email', school_request.suggested_rep_email),
        rep_name=data.get('rep_name'),
        approved_at=datetime.utcnow(),
        approved_by=session.get('user_id')
    )

    db.session.add(school)
    db.session.flush()  # Get the school ID

    # Update the request
    school_request.status = 'approved'
    school_request.processed_at = datetime.utcnow()
    school_request.processed_by = session.get('user_id')
    school_request.created_school_id = school.id
    school_request.admin_notes = data.get('admin_notes')

    db.session.commit()

    return jsonify({'success': True, 'school': school.to_dict()})


@app.route('/api/admin/prizes/school-requests/<int:request_id>/reject', methods=['POST'])
@login_required
@role_required('admin')
def reject_school_request(request_id):
    """Reject a school request"""
    school_request = SchoolRequest.query.get_or_404(request_id)
    data = request.get_json() or {}

    school_request.status = 'rejected'
    school_request.processed_at = datetime.utcnow()
    school_request.processed_by = session.get('user_id')
    school_request.admin_notes = data.get('admin_notes', 'Request rejected')

    db.session.commit()

    return jsonify({'success': True})


# ----- Redemption Analytics -----

@app.route('/api/admin/prizes/stats', methods=['GET'])
@login_required
@role_required('admin')
def get_prize_stats():
    """Get prize system statistics"""
    from sqlalchemy import func

    total_schools = PrizeSchool.query.filter_by(status='approved').count()
    pending_schools = PrizeSchool.query.filter_by(status='pending').count()
    total_prizes = Prize.query.filter_by(is_active=True).count()

    total_redemptions = PrizeRedemption.query.count()
    pending_redemptions = PrizeRedemption.query.filter_by(status='pending').count()
    fulfilled_redemptions = PrizeRedemption.query.filter_by(status='fulfilled').count()

    total_points_spent = db.session.query(func.sum(PrizeRedemption.points_spent)).scalar() or 0

    # Recent redemptions
    recent = PrizeRedemption.query.order_by(PrizeRedemption.redeemed_at.desc()).limit(10).all()

    return jsonify({
        'schools': {
            'approved': total_schools,
            'pending': pending_schools
        },
        'prizes': {
            'active': total_prizes
        },
        'redemptions': {
            'total': total_redemptions,
            'pending': pending_redemptions,
            'fulfilled': fulfilled_redemptions,
            'total_points_spent': total_points_spent
        },
        'recent_redemptions': [r.to_dict() for r in recent]
    })


# ==================== STUDENT PRIZE SHOP ROUTES ====================
# Student-facing prize shop and redemption

@app.route('/prizes')
@login_required
@approved_required
def student_prize_shop():
    """Student prize shop page"""
    if not FEATURE_FLAGS.get('PRIZE_SYSTEM_ENABLED', False):
        flash('Prize shop is not available yet.', 'info')
        return redirect(url_for('student_app'))

    return render_template('prize_shop.html')


@app.route('/api/prizes/available')
@login_required
@approved_required
def get_available_prizes():
    """Get prizes available to the current student"""
    if not FEATURE_FLAGS.get('PRIZE_SYSTEM_ENABLED', False):
        return jsonify({'error': 'Prize system not enabled'}), 403

    user_id = session.get('user_id')

    # Get student's school (if set)
    user = User.query.get(user_id)
    school_id = session.get('prize_school_id')
    
    # If not in session, try to load from user's default
    if not school_id and user and not user.email.startswith('guest_'):
        try:
            from sqlalchemy import text
            result = db.session.execute(text("""
                SELECT default_school_id FROM users WHERE id = :user_id
            """), {'user_id': user_id}).fetchone()
            if result and result.default_school_id:
                school_id = result.default_school_id
                session['prize_school_id'] = school_id
        except:
            pass
    
    school = PrizeSchool.query.get(school_id) if school_id else None

    # Get student's points and level
    # Check if this is a repeat guest first
    if 'guest_code' in session:
        from sqlalchemy import text
        guest_code = session['guest_code']
        guest_stats = db.session.execute(text("""
            SELECT total_score, quizzes_completed
            FROM guest_users
            WHERE guest_code = :code
        """), {"code": guest_code}).fetchone()
        
        student_points = guest_stats.total_score if guest_stats else 0
        student_level = (student_points // 100) + 1 if guest_stats else 1
    else:
        # Regular users and casual guests use UserStats
        stats = UserStats.query.filter_by(user_id=user_id).first()
        
        # Create UserStats if it doesn't exist (e.g., for guest users)
        if not stats:
            stats = UserStats(user_id=user_id, total_points=0, level=1)
            db.session.add(stats)
            try:
                db.session.commit()
            except:
                db.session.rollback()
                # Try to fetch again in case of race condition
                stats = UserStats.query.filter_by(user_id=user_id).first()
        
        student_points = stats.total_points if stats else 0
        student_level = stats.level if stats else 1

    # Get global multiplier and level lock setting
    global_multiplier = float(SystemSetting.get('global_points_multiplier', 5.0))
    level_lock_enabled = SystemSetting.get('prize_level_lock_enabled', 'false') == 'true'

    # Get all active prizes
    prizes = Prize.query.filter_by(is_active=True).order_by(Prize.tier, Prize.sort_order).all()

    result = []
    for prize in prizes:
        if school:
            # Check if disabled for this school
            override = SchoolPrize.query.filter_by(school_id=school.id, prize_id=prize.id).first()
            if override and not override.is_enabled:
                continue
            point_cost = prize.get_cost_for_school(school)
            stock = override.stock_available if override else None
        else:
            # No school selected - use global multiplier only
            point_cost = int(prize.base_point_cost * global_multiplier)
            stock = None

        # Check level requirement
        min_level = prize.minimum_level or 0
        meets_level = student_level >= min_level if level_lock_enabled else True

        result.append({
            'id': prize.id,
            'name': prize.name,
            'description': prize.description,
            'emoji': prize.emoji,
            'tier': prize.tier,
            'prize_type': prize.prize_type,
            'point_cost': point_cost,
            'can_afford': student_points >= point_cost,
            'minimum_level': min_level,
            'meets_level': meets_level,
            'level_lock_enabled': level_lock_enabled,
            'stock_available': stock
        })

    # Get school-specific prizes if school is selected
    school_specific = []
    if school:
        custom_prizes = SchoolPrize.query.filter_by(
            school_id=school.id,
            prize_id=None,
            is_enabled=True
        ).all()

        for sp in custom_prizes:
            school_specific.append({
                'id': None,
                'school_prize_id': sp.id,
                'name': sp.custom_name,
                'description': sp.custom_description,
                'emoji': sp.custom_emoji or '🎁',
                'tier': 'school',
                'prize_type': 'physical',
                'point_cost': sp.point_cost_override,
                'can_afford': student_points >= (sp.point_cost_override or 0),
                'stock_available': sp.stock_available,
                'is_school_specific': True
            })

    return jsonify({
        'prizes': result,
        'school_prizes': school_specific,
        'student_points': student_points,
        'student_level': student_level,
        'level_lock_enabled': level_lock_enabled,
        'school': school.to_dict() if school else None,
        'has_school': school is not None
    })


@app.route('/api/prizes/schools')
@login_required
@approved_required
def get_prize_schools_for_student():
    """Get list of approved schools for student to select"""
    schools = PrizeSchool.query.filter_by(status='approved').order_by(PrizeSchool.county, PrizeSchool.name).all()

    return jsonify({
        'schools': [{'id': s.id, 'name': s.name, 'county': s.county} for s in schools]
    })


@app.route('/api/prizes/select-school', methods=['POST'])
@login_required
@approved_required
def select_prize_school():
    """Student selects their school for prize redemption"""
    data = request.get_json()
    school_id = data.get('school_id')

    if school_id:
        school = PrizeSchool.query.get(school_id)
        if not school or school.status != 'approved':
            return jsonify({'error': 'Invalid school'}), 400

        # Save to session for immediate use
        session['prize_school_id'] = school_id
        
        # Save to user profile for persistence (registered users only)
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        if user and not user.email.startswith('guest_'):
            try:
                from sqlalchemy import text
                db.session.execute(text("""
                    UPDATE users 
                    SET default_school_id = :school_id 
                    WHERE id = :user_id
                """), {'school_id': school_id, 'user_id': user_id})
                db.session.commit()
            except:
                # Column might not exist yet, ignore
                pass
        
        return jsonify({'success': True, 'school': school.to_dict()})
    else:
        session.pop('prize_school_id', None)
        return jsonify({'success': True, 'school': None})


@app.route('/api/prizes/request-school', methods=['POST'])
@login_required
@approved_required
def request_new_school():
    """Student requests to add their school to the programme"""
    data = request.get_json()
    user_id = session.get('user_id')

    # Check for existing pending request from this user
    existing = SchoolRequest.query.filter_by(
        requested_by=user_id,
        status='pending'
    ).first()

    if existing:
        return jsonify({
            'error': 'You already have a pending school request',
            'existing_request': existing.to_dict()
        }), 400

    school_request = SchoolRequest(
        school_name=data['school_name'],
        county=data.get('county'),
        suggested_rep_email=data.get('suggested_rep_email'),
        requested_by=user_id
    )

    db.session.add(school_request)
    db.session.commit()

    return jsonify({
        'success': True,
        'message': 'School request submitted! An admin will review it soon.',
        'request': school_request.to_dict()
    })


@app.route('/api/prizes/redeem', methods=['POST'])
@login_required
@approved_required
def redeem_prize():
    """Student redeems points for a prize"""
    if not FEATURE_FLAGS.get('PRIZE_SYSTEM_ENABLED', False):
        return jsonify({'error': 'Prize system not enabled'}), 403

    data = request.get_json()
    user_id = session.get('user_id')
    school_id = session.get('prize_school_id')

    # Must have school selected
    if not school_id:
        return jsonify({'error': 'Please select your school first'}), 400

    school = PrizeSchool.query.get(school_id)
    if not school or school.status != 'approved':
        return jsonify({'error': 'Invalid school'}), 400

    # Get prize
    prize_id = data.get('prize_id')
    school_prize_id = data.get('school_prize_id')

    if prize_id:
        prize = Prize.query.get(prize_id)
        if not prize or not prize.is_active:
            return jsonify({'error': 'Prize not available'}), 400
        point_cost = prize.get_cost_for_school(school)
        prize_name = prize.name
    elif school_prize_id:
        school_prize = SchoolPrize.query.get(school_prize_id)
        if not school_prize or school_prize.school_id != school_id or not school_prize.is_enabled:
            return jsonify({'error': 'Prize not available'}), 400
        point_cost = school_prize.point_cost_override
        prize_name = school_prize.custom_name
        prize = None
    else:
        return jsonify({'error': 'No prize specified'}), 400

    # Check student has enough points and level
    stats = UserStats.query.filter_by(user_id=user_id).first()
    if not stats or stats.total_points < point_cost:
        return jsonify({'error': 'Not enough points'}), 400

    # Check level requirement (only for global prizes)
    level_lock_enabled = SystemSetting.get('prize_level_lock_enabled', 'false') == 'true'
    if prize_id and level_lock_enabled and prize:
        min_level = prize.minimum_level or 0
        student_level = stats.level if stats else 1
        if student_level < min_level:
            return jsonify({'error': f'You need to reach Level {min_level} to redeem this prize'}), 400

    # Check stock if applicable
    if school_prize_id:
        sp = SchoolPrize.query.get(school_prize_id)
        if sp.stock_available is not None and sp.stock_available <= 0:
            return jsonify({'error': 'Prize out of stock'}), 400
    elif prize_id:
        override = SchoolPrize.query.filter_by(school_id=school_id, prize_id=prize_id).first()
        if override and override.stock_available is not None and override.stock_available <= 0:
            return jsonify({'error': 'Prize out of stock at your school'}), 400

    # Generate token
    token = generate_prize_token()

    # Calculate expiry
    expiry_days = int(SystemSetting.get('prize_expiry_days', 30))
    expires_at = datetime.utcnow() + timedelta(days=expiry_days)

    # Create redemption
    redemption = PrizeRedemption(
        user_id=user_id,
        school_id=school_id,
        prize_id=prize_id,
        school_prize_id=school_prize_id if not prize_id else None,
        token=token,
        points_spent=point_cost,
        status='pending',
        expires_at=expires_at
    )

    # Deduct points
    stats.total_points -= point_cost

    # Decrease stock if applicable
    if school_prize_id:
        sp = SchoolPrize.query.get(school_prize_id)
        if sp.stock_available is not None:
            sp.stock_available -= 1
    elif prize_id:
        override = SchoolPrize.query.filter_by(school_id=school_id, prize_id=prize_id).first()
        if override and override.stock_available is not None:
            override.stock_available -= 1

    db.session.add(redemption)
    db.session.commit()

    return jsonify({
        'success': True,
        'token': token,
        'prize_name': prize_name,
        'points_spent': point_cost,
        'points_remaining': stats.total_points,
        'expires_at': expires_at.isoformat(),
        'school_name': school.name,
        'message': f'Show token {token} to your school rep to collect your prize!'
    })


@app.route('/api/prizes/my-redemptions')
@login_required
@approved_required
def get_my_redemptions():
    """Get student's prize redemption history"""
    user_id = session.get('user_id')

    redemptions = PrizeRedemption.query.filter_by(user_id=user_id).order_by(
        PrizeRedemption.redeemed_at.desc()
    ).all()

    return jsonify({
        'redemptions': [r.to_dict() for r in redemptions]
    })


# ==================== SCHOOL REP ROUTES ====================
# School representative dashboard for managing prize fulfilment

def school_rep_required(f):
    """Decorator to ensure user is a school rep"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Please log in first'}), 401

        user_id = session['user_id']
        user = User.query.get(user_id)

        if not user:
            return jsonify({'error': 'User not found'}), 401

        # Check if user is a rep for any school
        school = PrizeSchool.query.filter_by(rep_user_id=user_id, status='approved').first()

        # Also allow admins and teachers
        if not school and user.role not in ['admin', 'teacher']:
            return jsonify({'error': 'You are not authorized as a school rep'}), 403

        return f(*args, **kwargs)
    return decorated_function


@app.route('/school-rep')
@login_required
def school_rep_dashboard():
    """School rep dashboard page"""
    if not FEATURE_FLAGS.get('PRIZE_SYSTEM_ENABLED', False):
        flash('Prize system is not enabled.', 'warning')
        return redirect(url_for('dashboard'))

    user_id = session.get('user_id')
    user = User.query.get(user_id)

    # Check if user is a school rep
    school = PrizeSchool.query.filter_by(rep_user_id=user_id, status='approved').first()

    # Allow admin/teacher to access (they can select school)
    if not school and user.role not in ['admin', 'teacher']:
        flash('You are not registered as a school rep.', 'warning')
        return redirect(url_for('dashboard'))

    return render_template('school_rep_dashboard.html')


@app.route('/api/school-rep/my-schools')
@login_required
def get_rep_schools():
    """Get schools this user is a rep for"""
    user_id = session.get('user_id')
    user = User.query.get(user_id)

    # Reps see their assigned schools
    schools = PrizeSchool.query.filter_by(rep_user_id=user_id, status='approved').all()

    # Admins see all schools
    if user.role == 'admin':
        schools = PrizeSchool.query.filter_by(status='approved').all()

    return jsonify({
        'schools': [s.to_dict() for s in schools],
        'is_admin': user.role == 'admin'
    })


@app.route('/api/school-rep/pending/<int:school_id>')
@login_required
def get_pending_redemptions(school_id):
    """Get pending redemptions for a school"""
    user_id = session.get('user_id')
    user = User.query.get(user_id)

    # Verify access
    school = PrizeSchool.query.get_or_404(school_id)
    if school.rep_user_id != user_id and user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    redemptions = PrizeRedemption.query.filter_by(
        school_id=school_id,
        status='pending'
    ).order_by(PrizeRedemption.redeemed_at.desc()).all()

    return jsonify({
        'school': school.to_dict(),
        'redemptions': [r.to_dict(include_user=True) for r in redemptions],
        'count': len(redemptions)
    })


@app.route('/api/school-rep/search-token', methods=['POST'])
@login_required
def search_token():
    """Search for a redemption by token"""
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    data = request.get_json()

    token = data.get('token', '').strip().upper()

    if not token:
        return jsonify({'error': 'Please enter a token'}), 400

    redemption = PrizeRedemption.query.filter_by(token=token).first()

    if not redemption:
        return jsonify({'error': 'Token not found', 'found': False}), 404

    # Verify access to this school
    school = redemption.school
    if school.rep_user_id != user_id and user.role != 'admin':
        return jsonify({'error': 'This token belongs to a different school', 'found': False}), 403

    return jsonify({
        'found': True,
        'redemption': redemption.to_dict(include_user=True),
        'school': school.to_dict()
    })


@app.route('/api/school-rep/fulfil/<int:redemption_id>', methods=['POST'])
@login_required
def fulfil_redemption(redemption_id):
    """Mark a redemption as fulfilled"""
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    data = request.get_json() or {}

    redemption = PrizeRedemption.query.get_or_404(redemption_id)
    school = redemption.school

    # Verify access
    if school.rep_user_id != user_id and user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    if redemption.status != 'pending':
        return jsonify({'error': f'Redemption already {redemption.status}'}), 400

    # Mark as fulfilled
    redemption.status = 'fulfilled'
    redemption.fulfilled_at = datetime.utcnow()
    redemption.fulfilled_by = user_id
    redemption.fulfilment_notes = data.get('notes', '')

    db.session.commit()

    return jsonify({
        'success': True,
        'message': 'Prize marked as delivered!',
        'redemption': redemption.to_dict()
    })


@app.route('/api/school-rep/history/<int:school_id>')
@login_required
def get_fulfilment_history(school_id):
    """Get fulfilment history for a school"""
    user_id = session.get('user_id')
    user = User.query.get(user_id)

    # Verify access
    school = PrizeSchool.query.get_or_404(school_id)
    if school.rep_user_id != user_id and user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    # Get fulfilled redemptions
    redemptions = PrizeRedemption.query.filter_by(
        school_id=school_id,
        status='fulfilled'
    ).order_by(PrizeRedemption.fulfilled_at.desc()).limit(50).all()

    return jsonify({
        'school': school.to_dict(),
        'redemptions': [r.to_dict(include_user=True) for r in redemptions]
    })


@app.route('/api/school-rep/stats/<int:school_id>')
@login_required
def get_school_rep_stats(school_id):
    """Get stats for a school"""
    user_id = session.get('user_id')
    user = User.query.get(user_id)

    # Verify access
    school = PrizeSchool.query.get_or_404(school_id)
    if school.rep_user_id != user_id and user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    from sqlalchemy import func

    pending = PrizeRedemption.query.filter_by(school_id=school_id, status='pending').count()
    fulfilled = PrizeRedemption.query.filter_by(school_id=school_id, status='fulfilled').count()
    expired = PrizeRedemption.query.filter_by(school_id=school_id, status='expired').count()

    total_points = db.session.query(func.sum(PrizeRedemption.points_spent)).filter_by(
        school_id=school_id, status='fulfilled'
    ).scalar() or 0

    return jsonify({
        'school': school.to_dict(),
        'stats': {
            'pending': pending,
            'fulfilled': fulfilled,
            'expired': expired,
            'total_points_redeemed': total_points
        }
    })


# ==================== WHO AM I? FEATURE ====================
# Progressive image reveal gamification feature

def admin_required(f):
    """Decorator to ensure only admins can access these routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in first.', 'warning')
            return redirect(url_for('login'))

        user = User.query.get(session['user_id'])
        if not user or user.role != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard'))

        return f(*args, **kwargs)
    return decorated_function
    return decorated_function


# Helper function for Who Am I answer variants - MUST BE BEFORE ROUTES
def auto_generate_variants(answer):
    """
    Auto-generate acceptable answer variants
    Returns a list of lowercase variants
    """
    variants = set()
    answer_lower = answer.lower().strip()
    variants.add(answer_lower)

    # Remove common titles
    titles = ['dr.', 'dr', 'sir', 'professor', 'prof.', 'prof', 'dame', 'lord', 'lady']
    for title in titles:
        if answer_lower.startswith(title + ' '):
            without_title = answer_lower.replace(title + ' ', '', 1).strip()
            variants.add(without_title)

    # Split into name parts
    parts = answer_lower.split()

    if len(parts) >= 2:
        # First name only
        variants.add(parts[0])

        # Last name only
        variants.add(parts[-1])

        # First and last (skip middle)
        if len(parts) > 2:
            variants.add(f"{parts[0]} {parts[-1]}")

        # Remove middle initials
        filtered_parts = [p for p in parts if len(p) > 2 or not p.endswith('.')]
        if len(filtered_parts) != len(parts):
            variants.add(' '.join(filtered_parts))

    # Remove punctuation variants
    import string
    no_punct = answer_lower.translate(str.maketrans('', '', string.punctuation))
    if no_punct != answer_lower:
        variants.add(no_punct)

    return sorted(list(variants))


@app.route('/admin/who-am-i')
@admin_required
def admin_who_am_i():
    """Display all Who Am I images with multi-topic support"""
    from sqlalchemy import text

    # Get all images with their topics - INCLUDE accepted_answers
    query = text("""
        SELECT
            i.id,
            i.difficulty,
            i.image_filename,
            i.answer,
            i.hint,
            i.active,
            i.created_at,
            i.topic as primary_topic,
            i.accepted_answers,
            GROUP_CONCAT(t.topic) as all_topics
        FROM who_am_i_images i
        LEFT JOIN who_am_i_image_topics t ON i.id = t.image_id
        GROUP BY i.id
        ORDER BY i.created_at DESC
    """)

    results = db.session.execute(query).fetchall()

    images = []
    for row in results:
        # Parse comma-separated topics
        topics = row.all_topics.split(',') if row.all_topics else []
        
        # Parse accepted answers to get count
        accepted_answers_count = 0
        if row.accepted_answers:
            try:
                accepted_answers_count = len(json.loads(row.accepted_answers))
            except:
                pass
        
        images.append({
            'id': row.id,
            'primary_topic': row.primary_topic,
            'topics': topics,
            'difficulty': row.difficulty,
            'image_filename': row.image_filename,
            'answer': row.answer,
            'hint': row.hint,
            'active': row.active,
            'created_at': row.created_at,
            'accepted_answers_count': accepted_answers_count
        })

    # Get ALL topics from questions table
    topics = db.session.execute(text("SELECT DISTINCT topic FROM questions ORDER BY topic")).fetchall()
    all_topics = [row.topic for row in topics]

    # Get enabled topics (topics that have at least one image)
    enabled_query = text("""
        SELECT DISTINCT topic
        FROM who_am_i_image_topics
        ORDER BY topic
    """)
    enabled_results = db.session.execute(enabled_query).fetchall()
    enabled_topics = [row.topic for row in enabled_results]

    return render_template('admin_who_am_i.html',
                         images=images,
                         all_topics=all_topics,
                         enabled_topics=enabled_topics)


@app.route('/admin/who-am-i/upload', methods=['POST'])
@admin_required
def admin_who_am_i_upload():
    """Handle image upload with multi-topic support"""
    from sqlalchemy import text

    # Validate form data
    if 'image' not in request.files:
        flash('No image file provided', 'danger')
        return redirect(url_for('admin_who_am_i'))

    file = request.files['image']
    primary_topic = request.form.get('topic')  # Primary topic for backward compatibility
    selected_topics = request.form.getlist('topics[]')  # Multiple topics
    difficulty = request.form.get('difficulty')
    answer = request.form.get('answer')
    hint = request.form.get('hint', '')

    # Handle accepted answers
    accepted_answers_text = request.form.get('accepted_answers', '').strip()
    if accepted_answers_text:
        # Parse from textarea (one per line)
        variants = [v.strip() for v in accepted_answers_text.split('\n') if v.strip()]
        accepted_answers_json = json.dumps(variants)
    else:
        # Auto-generate if not provided
        variants = auto_generate_variants(answer)
        accepted_answers_json = json.dumps(variants)

    if file.filename == '':
        flash('No file selected', 'danger')
        return redirect(url_for('admin_who_am_i'))

    # Handle both single topic and multi-topic selection
    if not selected_topics and not primary_topic:
        flash('At least one topic is required', 'danger')
        return redirect(url_for('admin_who_am_i'))

    if not difficulty or not answer:
        flash('Difficulty and answer are required', 'danger')
        return redirect(url_for('admin_who_am_i'))

    # If only single topic selected (old form), use it
    if not selected_topics and primary_topic:
        selected_topics = [primary_topic]
    # If multi-topics selected but no primary, use first as primary
    elif selected_topics and not primary_topic:
        primary_topic = selected_topics[0]

    if file and allowed_file(file.filename):
        # Create upload directory if it doesn't exist
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)

        # Generate secure filename
        filename = secure_filename(file.filename)
        # Add timestamp to avoid conflicts
        import time
        timestamp = int(time.time())
        name, ext = os.path.splitext(filename)
        filename = f"{name}_{timestamp}{ext}"

        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)

        # Save to database
        query = text("""
            INSERT INTO who_am_i_images (topic, difficulty, image_filename, answer, hint)
            VALUES (:topic, :difficulty, :filename, :answer, :hint)
        """)
        result = db.session.execute(query, {
            'topic': primary_topic,
            'difficulty': difficulty,
            'filename': filename,
            'answer': answer,
            'hint': hint
        })
        db.session.commit()

        # Get the new image ID
        image_id = result.lastrowid

        # Add topic associations
        for topic in selected_topics:
            db.session.execute(text("""
                INSERT OR IGNORE INTO who_am_i_image_topics (image_id, topic)
                VALUES (:image_id, :topic)
            """), {'image_id': image_id, 'topic': topic})

        db.session.commit()

        flash(f'Image uploaded successfully! Answer: {answer} | Topics: {", ".join(selected_topics)}', 'success')
    else:
        flash('Invalid file type. Allowed types: png, jpg, jpeg, gif, webp', 'danger')

    return redirect(url_for('admin_who_am_i'))


@app.route('/admin/who-am-i/toggle/<int:image_id>', methods=['POST'])
@admin_required
def admin_who_am_i_toggle(image_id):
    """Toggle active status of an image"""
    from sqlalchemy import text

    result = db.session.execute(
        text("SELECT active FROM who_am_i_images WHERE id = :id"),
        {'id': image_id}
    ).fetchone()

    if result:
        new_status = 0 if result.active == 1 else 1
        db.session.execute(
            text("UPDATE who_am_i_images SET active = :status WHERE id = :id"),
            {'status': new_status, 'id': image_id}
        )
        db.session.commit()
        flash('Image status updated', 'success')
    else:
        flash('Image not found', 'danger')

    return redirect(url_for('admin_who_am_i'))


@app.route('/admin/who-am-i/delete/<int:image_id>', methods=['POST'])
@admin_required
def admin_who_am_i_delete(image_id):
    """Delete an image"""
    from sqlalchemy import text

    result = db.session.execute(
        text("SELECT image_filename FROM who_am_i_images WHERE id = :id"),
        {'id': image_id}
    ).fetchone()

    if result:
        # Delete file
        filepath = os.path.join(UPLOAD_FOLDER, result.image_filename)
        if os.path.exists(filepath):
            os.remove(filepath)

        # Delete from database
        db.session.execute(
            text("DELETE FROM who_am_i_images WHERE id = :id"),
            {'id': image_id}
        )
        db.session.commit()
        flash('Image deleted successfully', 'success')
    else:
        flash('Image not found', 'danger')

    return redirect(url_for('admin_who_am_i'))



@app.route('/admin/who-am-i/get/<int:image_id>')
@admin_required
def admin_who_am_i_get(image_id):
    """Get image details for editing (including accepted_answers)"""
    from sqlalchemy import text

    query = text("""
        SELECT
            i.id,
            i.answer,
            i.hint,
            i.difficulty,
            i.accepted_answers,
            i.active,
            GROUP_CONCAT(t.topic) as topics
        FROM who_am_i_images i
        LEFT JOIN who_am_i_image_topics t ON i.id = t.image_id
        WHERE i.id = :image_id
        GROUP BY i.id
    """)

    result = db.session.execute(query, {'image_id': image_id}).fetchone()

    if not result:
        return jsonify({'error': 'Image not found'}), 404

    topics = result.topics.split(',') if result.topics else []

    return jsonify({
        'id': result.id,
        'answer': result.answer,
        'hint': result.hint,
        'difficulty': result.difficulty,
        'accepted_answers': result.accepted_answers,
        'active': result.active,
        'topics': topics
    })


@app.route('/admin/who-am-i/edit/<int:image_id>', methods=['GET', 'POST'])
@admin_required
def admin_who_am_i_edit(image_id):
    """Edit image details including accepted_answers"""
    from sqlalchemy import text

    if request.method == 'GET':
        # Redirect to main page (handled by GET endpoint now)
        return redirect(url_for('admin_who_am_i'))

    # POST - handle edit
    answer = request.form.get('answer')
    hint = request.form.get('hint', '')
    difficulty = request.form.get('difficulty')
    selected_topics = request.form.getlist('topics[]')

    # Handle accepted answers from form
    accepted_answers_json = request.form.get('accepted_answers')

    # If not provided or empty, auto-generate
    if not accepted_answers_json:
        variants = auto_generate_variants(answer)
        accepted_answers_json = json.dumps(variants)

    # Update image
    db.session.execute(text("""
        UPDATE who_am_i_images
        SET answer = :answer,
            hint = :hint,
            difficulty = :difficulty,
            accepted_answers = :accepted_answers
        WHERE id = :image_id
    """), {
        'answer': answer,
        'hint': hint,
        'difficulty': difficulty,
        'accepted_answers': accepted_answers_json,
        'image_id': image_id
    })

    # Update topics - delete old associations
    db.session.execute(text("""
        DELETE FROM who_am_i_image_topics WHERE image_id = :image_id
    """), {'image_id': image_id})

    # Insert new topic associations
    if selected_topics:
        for topic in selected_topics:
            db.session.execute(text("""
                INSERT INTO who_am_i_image_topics (image_id, topic)
                VALUES (:image_id, :topic)
            """), {'image_id': image_id, 'topic': topic})

    db.session.commit()

    flash('Image updated successfully', 'success')
    return jsonify({'success': True})

@app.route('/admin/who-am-i/bulk-assign', methods=['POST'])
@admin_required
def admin_who_am_i_bulk_assign():
    """Bulk assign images to topics"""
    from sqlalchemy import text

    data = request.json
    image_ids = data.get('image_ids', [])
    topics = data.get('topics', [])
    action = data.get('action', 'add')  # 'add' or 'replace'

    if not image_ids or not topics:
        return jsonify({'success': False, 'error': 'Image IDs and topics required'}), 400

    if action == 'replace':
        # Remove existing topics for these images
        for image_id in image_ids:
            db.session.execute(text("""
                DELETE FROM who_am_i_image_topics WHERE image_id = :id
            """), {'id': image_id})

    # Add new topic associations
    for image_id in image_ids:
        for topic in topics:
            db.session.execute(text("""
                INSERT OR IGNORE INTO who_am_i_image_topics (image_id, topic)
                VALUES (:image_id, :topic)
            """), {'image_id': image_id, 'topic': topic})

        # Update primary topic if replacing
        if action == 'replace' and topics:
            db.session.execute(text("""
                UPDATE who_am_i_images SET topic = :topic WHERE id = :id
            """), {'topic': topics[0], 'id': image_id})

    db.session.commit()

    action_text = 'replaced with' if action == 'replace' else 'added to'
    return jsonify({
        'success': True,
        'message': f'{len(image_ids)} images {action_text} {len(topics)} topics'
    })


@app.route('/admin/who-am-i/bulk-delete', methods=['POST'])
@admin_required
def admin_who_am_i_bulk_delete():
    """Bulk delete images"""
    from sqlalchemy import text

    data = request.json
    image_ids = data.get('image_ids', [])

    if not image_ids:
        return jsonify({'success': False, 'error': 'No images selected'}), 400

    # Get filenames for deletion
    placeholders = ','.join([':id' + str(i) for i in range(len(image_ids))])
    params = {f'id{i}': image_id for i, image_id in enumerate(image_ids)}

    results = db.session.execute(text(f"""
        SELECT image_filename FROM who_am_i_images WHERE id IN ({placeholders})
    """), params).fetchall()

    # Delete files
    for row in results:
        filepath = os.path.join(UPLOAD_FOLDER, row.image_filename)
        if os.path.exists(filepath):
            os.remove(filepath)

    # Delete from database
    db.session.execute(text(f"""
        DELETE FROM who_am_i_images WHERE id IN ({placeholders})
    """), params)

    db.session.commit()

    return jsonify({'success': True, 'message': f'{len(image_ids)} images deleted'})


# ==================== WHO AM I? API ENDPOINTS ====================

@app.route('/api/who-am-i/start', methods=['POST'])
def who_am_i_start():
    """Initialize a new Who Am I session for a quiz"""
    from sqlalchemy import text

    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401

    data = request.json
    topic = data.get('topic')
    difficulty = data.get('difficulty')
    quiz_attempt_id = data.get('quiz_attempt_id')

    # Get a random active image for this topic/difficulty
    # Now uses the junction table for multi-topic support
    result = db.session.execute(text("""
        SELECT DISTINCT i.id, i.image_filename, i.answer, i.hint
        FROM who_am_i_images i
        JOIN who_am_i_image_topics t ON i.id = t.image_id
        WHERE t.topic = :topic AND i.difficulty = :difficulty AND i.active = 1
        ORDER BY RANDOM()
        LIMIT 1
    """), {'topic': topic, 'difficulty': difficulty}).fetchone()

    if not result:
        return jsonify({'error': 'No images available for this topic/difficulty'}), 404

    image_id = result.id
    image_filename = result.image_filename
    answer = result.answer
    hint = result.hint

    # Create session
    insert_result = db.session.execute(text("""
        INSERT INTO who_am_i_sessions (user_id, quiz_attempt_id, image_id, tiles_revealed, guesses_made)
        VALUES (:user_id, :quiz_attempt_id, :image_id, '[]', 0)
    """), {
        'user_id': session['user_id'],
        'quiz_attempt_id': quiz_attempt_id,
        'image_id': image_id
    })

    db.session.commit()
    session_id = insert_result.lastrowid

    return jsonify({
        'session_id': session_id,
        'image_url': url_for('static', filename=f'who_am_i_images/{image_filename}'),
        'hint': hint,
        'total_tiles': 25
    })


@app.route('/api/who-am-i/reveal', methods=['POST'])
def who_am_i_reveal():
    """Reveal a tile after correct answer"""
    from sqlalchemy import text

    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401

    data = request.json
    session_id = data.get('session_id')

    # Get current session
    result = db.session.execute(text("""
        SELECT tiles_revealed FROM who_am_i_sessions
        WHERE id = :session_id AND user_id = :user_id
    """), {'session_id': session_id, 'user_id': session['user_id']}).fetchone()

    if not result:
        return jsonify({'error': 'Session not found'}), 404

    tiles_revealed = json.loads(result.tiles_revealed)

    # Find next unrevealed tile
    all_tiles = list(range(16))
    available_tiles = [t for t in all_tiles if t not in tiles_revealed]

    if not available_tiles:
        return jsonify({'tiles_revealed': tiles_revealed, 'all_revealed': True})

    # Pick random tile to reveal
    new_tile = random.choice(available_tiles)
    tiles_revealed.append(new_tile)

    # Update session
    db.session.execute(text("""
        UPDATE who_am_i_sessions
        SET tiles_revealed = :tiles
        WHERE id = :session_id
    """), {'tiles': json.dumps(tiles_revealed), 'session_id': session_id})

    db.session.commit()

    return jsonify({
        'tiles_revealed': tiles_revealed,
        'new_tile': new_tile,
        'all_revealed': len(tiles_revealed) >= 25
    })


@app.route('/api/who-am-i/guess', methods=['POST'])
def who_am_i_guess():
    """Submit a guess for Who Am I"""
    from sqlalchemy import text

    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401

    data = request.json
    session_id = data.get('session_id')
    guess = data.get('guess', '').strip()

    # Get session and image details - IMPORTANT: Include quiz_attempt_id!
    result = db.session.execute(text("""
        SELECT s.tiles_revealed, s.guesses_made, s.correct_guess, s.quiz_attempt_id,
               i.answer, i.accepted_answers
        FROM who_am_i_sessions s
        JOIN who_am_i_images i ON s.image_id = i.id
        WHERE s.id = :session_id AND s.user_id = :user_id
    """), {'session_id': session_id, 'user_id': session['user_id']}).fetchone()

    if not result:
        return jsonify({'error': 'Session not found'}), 404

    tiles_revealed = json.loads(result.tiles_revealed)
    guesses_made = result.guesses_made
    correct_guess = result.correct_guess
    quiz_attempt_id = result.quiz_attempt_id  # NOW IT'S RETRIEVED!
    correct_answer = result.answer
    accepted_answers_json = result.accepted_answers

    # Check if already guessed correctly
    if correct_guess:
        return jsonify({'error': 'Already guessed correctly'}), 400

    # Check guess limit
    if guesses_made >= 3:
        return jsonify({'error': 'No guesses remaining', 'correct': False, 'answer': correct_answer}), 400

    # Flexible answer checking with variants
    # Parse accepted answers
    accepted_answers = []
    if accepted_answers_json:
        try:
            accepted_answers = json.loads(accepted_answers_json)
        except:
            pass

    # If no variants defined, fall back to original answer only
    if not accepted_answers:
        accepted_answers = [correct_answer.lower().strip()]

    # Normalize guess
    guess_normalized = guess.lower().strip()

    # Check if guess matches any accepted variant
    is_correct = guess_normalized in [a.lower().strip() for a in accepted_answers]
    guesses_made += 1

    # Calculate bonus points if correct
    bonus_points = 0
    if is_correct:
        tiles_hidden = 25 - len(tiles_revealed)  # 5×5 grid = 25 tiles
        if tiles_hidden >= 20:      # Guessed with 80%+ hidden (very early)
            bonus_points = 100
        elif tiles_hidden >= 15:    # Guessed with 60-79% hidden (early)
            bonus_points = 75
        elif tiles_hidden >= 10:    # Guessed with 40-59% hidden (moderate)
            bonus_points = 50
        elif tiles_hidden >= 5:     # Guessed with 20-39% hidden (late)
            bonus_points = 25
        else:                        # Less than 5 tiles hidden (very late)
            bonus_points = 10

        # Update session
        db.session.execute(text("""
            UPDATE who_am_i_sessions
            SET guesses_made = :guesses, correct_guess = 1, bonus_points_earned = :bonus, completed_at = CURRENT_TIMESTAMP
            WHERE id = :session_id
        """), {'guesses': guesses_made, 'bonus': bonus_points, 'session_id': session_id})
    else:
        # Just increment guesses
        db.session.execute(text("""
            UPDATE who_am_i_sessions
            SET guesses_made = :guesses
            WHERE id = :session_id
        """), {'guesses': guesses_made, 'session_id': session_id})

    db.session.commit()

    # If correct, try to load another image automatically
    next_session_data = None
    if is_correct:
        try:
            # Get the current quiz topic and difficulty
            quiz_info = db.session.execute(text("""
                SELECT topic, difficulty FROM quiz_attempts WHERE id = :quiz_id
            """), {'quiz_id': quiz_attempt_id}).fetchone()

            print(f"🔍 Looking for next image - quiz_id: {quiz_attempt_id}, topic: {quiz_info.topic if quiz_info else 'None'}, difficulty: {quiz_info.difficulty if quiz_info else 'None'}")

            if quiz_info:
                # Get list of images already shown in this quiz
                shown_images = db.session.execute(text("""
                    SELECT image_id FROM who_am_i_sessions
                    WHERE quiz_attempt_id = :quiz_id
                """), {'quiz_id': quiz_attempt_id}).fetchall()

                shown_image_ids = [row.image_id for row in shown_images]
                print(f"🚫 Already shown image IDs: {shown_image_ids}")

                # Build query to exclude already-shown images
                if shown_image_ids:
                    # Create string of IDs for NOT IN clause
                    id_list = ','.join([str(id) for id in shown_image_ids])

                    print(f"🔎 Searching with: topic={quiz_info.topic}, difficulty={quiz_info.difficulty}, excluding IDs: {id_list}")

                    next_image = db.session.execute(text(f"""
                        SELECT DISTINCT i.id, i.image_filename, i.answer, i.hint
                        FROM who_am_i_images i
                        JOIN who_am_i_image_topics t ON i.id = t.image_id
                        WHERE t.topic = :topic
                        AND LOWER(i.difficulty) = LOWER(:difficulty)
                        AND i.active = 1
                        AND i.id NOT IN ({id_list})
                        ORDER BY RANDOM()
                        LIMIT 1
                    """), {
                        'topic': quiz_info.topic,
                        'difficulty': quiz_info.difficulty
                    }).fetchone()
                else:
                    print(f"🔎 First image search with: topic={quiz_info.topic}, difficulty={quiz_info.difficulty}")
                    # First image, get any
                    next_image = db.session.execute(text("""
                        SELECT DISTINCT i.id, i.image_filename, i.answer, i.hint
                        FROM who_am_i_images i
                        JOIN who_am_i_image_topics t ON i.id = t.image_id
                        WHERE t.topic = :topic
                        AND LOWER(i.difficulty) = LOWER(:difficulty)
                        AND i.active = 1
                        ORDER BY RANDOM()
                        LIMIT 1
                    """), {
                        'topic': quiz_info.topic,
                        'difficulty': quiz_info.difficulty
                    }).fetchone()

                if next_image:
                    print(f"✅ Next image found! ID: {next_image.id}, Answer: {next_image.answer}")
                    # Create new session for next image
                    new_session = db.session.execute(text("""
                        INSERT INTO who_am_i_sessions (user_id, quiz_attempt_id, image_id, tiles_revealed, guesses_made)
                        VALUES (:user_id, :quiz_attempt_id, :image_id, '[]', 0)
                    """), {
                        'user_id': session['user_id'],
                        'quiz_attempt_id': quiz_attempt_id,
                        'image_id': next_image.id
                    })
                    db.session.commit()

                    next_session_data = {
                        'session_id': new_session.lastrowid,
                        'image_url': url_for('static', filename=f'who_am_i_images/{next_image.image_filename}'),
                        'hint': next_image.hint,
                        'total_tiles': 25
                    }
                    print(f"✅ New session created: {new_session.lastrowid}")
                else:
                    print(f"ℹ️ No more images available for topic={quiz_info.topic}, difficulty={quiz_info.difficulty}")
        except Exception as e:
            # Log error but don't break the guess response
            print(f"❌ Error loading next Who Am I image: {e}")
            import traceback
            traceback.print_exc()

    response_data = {
        'correct': is_correct,
        'bonus_points': bonus_points,
        'guesses_remaining': 3 - guesses_made,
        'answer': correct_answer if is_correct or guesses_made >= 3 else None
    }

    # Add next session info if available
    if next_session_data:
        response_data['next_session'] = next_session_data

    return jsonify(response_data)

# ==================== AVATAR SYSTEM ROUTES ====================
# All avatar routes check FEATURE_FLAGS before executing
# BACKOUT: Set AVATAR_SYSTEM_ENABLED=false to disable all routes

@app.route('/avatar/shop')
def avatar_shop_page():
    """Avatar customization shop page"""
    if not FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False):
        flash('Avatar shop is currently unavailable', 'warning')
        return redirect(url_for('student_app'))

    user_id = session.get('user_id')
    guest_code = session.get('guest_code')
    is_casual_guest = session.get('is_guest', False)

    if not user_id and not guest_code:
        flash('Please log in to access the avatar shop', 'warning')
        return redirect(url_for('login'))

    # Get user info based on user type
    user_name = None
    display_name = None

    if guest_code:
        # Repeat guest with animal code - use guest_code as name
        display_name = guest_code
    elif is_casual_guest:
        # Casual guest (Quick Try) - show generic name
        display_name = "Quick Try Guest"
    elif user_id:
        # Regular registered user
        user = User.query.get(user_id)
        user_name = user.full_name if user else None
        display_name = user_name

    # Get points - prioritize guest_code for repeat guests
    if guest_code:
        points, level = get_avatar_user_points(None, guest_code)
    elif user_id and not is_casual_guest:
        points, level = get_avatar_user_points(user_id, None)
    else:
        # Casual guests don't have persistent points for avatar shop
        points, level = 0, 1

    return render_template('avatar_shop.html',
        user_name=display_name,
        guest_code=guest_code,
        points=points,
        level=level,
        is_casual_guest=is_casual_guest
    )

@app.route('/api/avatar/items', methods=['GET'])
def api_avatar_items():
    """Get all available shop items"""
    if not FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False):
        return jsonify({'success': False, 'message': 'Avatar system disabled'}), 503

    item_type = request.args.get('type')  # Optional filter

    query = AvatarItem.query.filter_by(is_active=True)
    if item_type:
        query = query.filter_by(item_type=item_type)

    items = query.order_by(AvatarItem.sort_order).all()

    return jsonify({
        'success': True,
        'items': [item.to_dict() for item in items]
    })

@app.route('/api/avatar/inventory', methods=['GET'])
def api_avatar_inventory():
    """Get current user's inventory and points"""
    if not FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False):
        return jsonify({'success': False, 'message': 'Avatar system disabled'}), 503

    user_id = session.get('user_id')
    guest_code = session.get('guest_code')
    is_casual_guest = session.get('is_guest', False)

    if not user_id and not guest_code:
        return jsonify({
            'success': False,
            'message': 'Not logged in',
            'inventory': [],
            'points': 0
        })

    # Get inventory based on user type
    query = UserAvatarInventory.query
    if guest_code:
        # Repeat guest - use guest_code
        query = query.filter_by(guest_code=guest_code)
        points, level = get_avatar_user_points(None, guest_code)
    elif user_id and not is_casual_guest:
        # Regular registered user
        query = query.filter_by(user_id=user_id)
        points, level = get_avatar_user_points(user_id, None)
    else:
        # Casual guest - no persistent inventory or points
        return jsonify({
            'success': True,
            'inventory': [],
            'points': 0,
            'level': 1,
            'is_casual_guest': True
        })

    inventory = query.all()

    return jsonify({
        'success': True,
        'inventory': [inv.to_dict() for inv in inventory],
        'points': points,
        'level': level
    })

@app.route('/api/avatar/equipped', methods=['GET'])
def api_avatar_equipped():
    """Get currently equipped avatar configuration"""
    if not FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False):
        return jsonify({'success': False, 'message': 'Avatar system disabled'}), 503

    user_id = session.get('user_id')
    guest_code = session.get('guest_code')

    # DEBUG: Log what we're looking for
    print(f"🔍 api_avatar_equipped called: user_id={user_id}, guest_code={guest_code}")

    equipped = get_equipped_avatar(user_id, guest_code)

    # DEBUG: Log what we found
    print(f"🎭 Returning equipped: {equipped}")

    return jsonify({
        'success': True,
        'equipped': equipped,
        '_debug': {
            'session_user_id': user_id,
            'session_guest_code': guest_code
        }
    })

@app.route('/api/avatar/purchase', methods=['POST'])
def api_avatar_purchase():
    """Purchase an item"""
    if not FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False):
        return jsonify({'success': False, 'message': 'Avatar system disabled'}), 503

    if not FEATURE_FLAGS.get('AVATAR_SHOP_ENABLED', False):
        return jsonify({'success': False, 'message': 'Avatar shop disabled'}), 503

    user_id = session.get('user_id')
    guest_code = session.get('guest_code')

    if not user_id and not guest_code:
        return jsonify({'success': False, 'message': 'You must be logged in to purchase items'}), 401

    data = request.get_json()
    item_id = data.get('item_id')

    if not item_id:
        return jsonify({'success': False, 'message': 'Item ID is required'}), 400

    # Get the item
    item = AvatarItem.query.get(item_id)
    if not item:
        return jsonify({'success': False, 'message': 'Item not found'}), 404

    if not item.is_active:
        return jsonify({'success': False, 'message': 'Item is not available'}), 400

    # Check if already owned
    if avatar_owns_item(item_id, user_id, guest_code):
        return jsonify({'success': False, 'message': 'You already own this item'}), 400

    # Check if it's a free/default item
    if item.is_default or item.point_cost == 0:
        # Just add to inventory, no points needed
        inventory_entry = UserAvatarInventory(
            user_id=user_id,
            guest_code=guest_code,
            item_id=item_id
        )
        db.session.add(inventory_entry)
        db.session.commit()
        return jsonify({
            'success': True,
            'message': f"Added {item.display_name} to your collection!",
            'new_points': None
        })

    # Get current points
    current_points, _ = get_avatar_user_points(user_id, guest_code)

    # Check if enough points
    if current_points < item.point_cost:
        return jsonify({
            'success': False,
            'message': f"Not enough points. You need {item.point_cost} but have {current_points}"
        }), 400

    # Deduct points
    from sqlalchemy import text
    new_points = current_points - item.point_cost

    # Deduct from correct table (guest_code takes priority)
    if guest_code:
        db.session.execute(text(
            "UPDATE guest_users SET total_score = :points WHERE guest_code = :code"
        ), {"points": new_points, "code": guest_code})
    elif user_id:
        db.session.execute(text(
            "UPDATE user_stats SET total_points = :points WHERE user_id = :uid"
        ), {"points": new_points, "uid": user_id})

    # Add to inventory (store both for tracking, but guest_code is primary for guests)
    inventory_entry = UserAvatarInventory(
        user_id=user_id if not guest_code else None,  # Only set user_id for actual registered users
        guest_code=guest_code,
        item_id=item_id
    )
    db.session.add(inventory_entry)

    # AUTO-EQUIP: Automatically equip the purchased item
    print(f"🛒 AUTO-EQUIP: user_id={user_id}, guest_code={guest_code}, item_type={item.item_type}, item_key={item.item_key}")

    if guest_code:
        equipped = UserAvatarEquipped.query.filter_by(guest_code=guest_code).first()
        print(f"🔍 Found equipped for guest_code={guest_code}: {equipped}")
        if not equipped:
            equipped = UserAvatarEquipped(guest_code=guest_code)
            db.session.add(equipped)
            print(f"📝 Created new equipped record for guest_code={guest_code}")
    elif user_id:
        equipped = UserAvatarEquipped.query.filter_by(user_id=user_id).first()
        print(f"🔍 Found equipped for user_id={user_id}: {equipped}")
        if not equipped:
            equipped = UserAvatarEquipped(user_id=user_id)
            db.session.add(equipped)
            print(f"📝 Created new equipped record for user_id={user_id}")
    else:
        equipped = None

    # Set the appropriate slot based on item type
    if equipped:
        print(f"📝 Before equip: animal={equipped.animal_key}, hat={equipped.hat_key}, glasses={equipped.glasses_key}")
        if item.item_type == 'animal':
            equipped.animal_key = item.item_key
        elif item.item_type == 'hat':
            equipped.hat_key = item.item_key
        elif item.item_type == 'glasses':
            equipped.glasses_key = item.item_key
        elif item.item_type == 'background':
            equipped.background_key = item.item_key
        elif item.item_type == 'accessory':
            equipped.accessory_key = item.item_key
        equipped.updated_at = datetime.utcnow()
        print(f"📝 After equip: animal={equipped.animal_key}, hat={equipped.hat_key}, glasses={equipped.glasses_key}")

    # Log the purchase
    purchase_log = AvatarPurchaseLog(
        user_id=user_id,
        guest_code=guest_code,
        item_id=item_id,
        points_spent=item.point_cost,
        points_before=current_points,
        points_after=new_points
    )
    db.session.add(purchase_log)

    db.session.commit()

    return jsonify({
        'success': True,
        'message': f"Purchased {item.display_name} for {item.point_cost} points!",
        'new_points': new_points
    })

@app.route('/api/avatar/equip', methods=['POST'])
def api_avatar_equip():
    """Equip an item"""
    if not FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False):
        return jsonify({'success': False, 'message': 'Avatar system disabled'}), 503

    user_id = session.get('user_id')
    guest_code = session.get('guest_code')

    if not user_id and not guest_code:
        return jsonify({'success': False, 'message': 'You must be logged in to equip items'}), 401

    data = request.get_json()
    item_type = data.get('item_type')
    item_key = data.get('item_key')

    if not item_type or not item_key:
        return jsonify({'success': False, 'message': 'Item type and key are required'}), 400

    # Verify item exists
    item = AvatarItem.query.filter_by(
        item_type=item_type,
        item_key=item_key
    ).first()

    if not item:
        return jsonify({'success': False, 'message': 'Item not found'}), 404

    # Check ownership (default items are always available)
    if not item.is_default and not avatar_owns_item(item.id, user_id, guest_code):
        return jsonify({'success': False, 'message': "You don't own this item"}), 400

    # Get or create equipped record (guest_code takes priority)
    if guest_code:
        equipped = UserAvatarEquipped.query.filter_by(guest_code=guest_code).first()
        if not equipped:
            equipped = UserAvatarEquipped(guest_code=guest_code)
            db.session.add(equipped)
    elif user_id:
        equipped = UserAvatarEquipped.query.filter_by(user_id=user_id).first()
        if not equipped:
            equipped = UserAvatarEquipped(user_id=user_id)
            db.session.add(equipped)
    else:
        return jsonify({'success': False, 'message': 'No user or guest identified'}), 400

    # Update the appropriate slot
    if item_type == 'animal':
        equipped.animal_key = item_key
    elif item_type == 'hat':
        equipped.hat_key = item_key
    elif item_type == 'glasses':
        equipped.glasses_key = item_key
    elif item_type == 'background':
        equipped.background_key = item_key
    elif item_type == 'accessory':
        equipped.accessory_key = item_key
    else:
        return jsonify({'success': False, 'message': f'Unknown item type: {item_type}'}), 400

    equipped.updated_at = datetime.utcnow()
    db.session.commit()

    return jsonify({
        'success': True,
        'message': f"Equipped {item.display_name}!"
    })

@app.route('/api/avatar/grant-defaults', methods=['POST'])
def api_avatar_grant_defaults():
    """Grant default items to current user (call on first login)"""
    if not FEATURE_FLAGS.get('AVATAR_SYSTEM_ENABLED', False):
        return jsonify({'success': False, 'message': 'Avatar system disabled'}), 503

    user_id = session.get('user_id')
    guest_code = session.get('guest_code')

    if not user_id and not guest_code:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401

    grant_default_avatar_items(user_id, guest_code)

    return jsonify({
        'success': True,
        'message': 'Default items granted'
    })

# ==================== TOPIC MANAGEMENT MODULE ====================
# Import and register topic management routes
try:
    from topic_management import register_topic_routes
    register_topic_routes(app, db)
except ImportError:
    print("Warning: topic_management.py not found - topic management disabled")
except Exception as e:
    print(f"Warning: Could not load topic management: {e}")

# ==================== QUESTION GENERATOR MODULE ====================
# Import and register AI question generator routes
try:
    from question_generator import register_generator_routes
    register_generator_routes(app, db)
except ImportError:
    print("Warning: question_generator.py not found - question generator disabled")
except Exception as e:
    print(f"Warning: Could not load question generator: {e}")



# =============================================================================
# PHASE 4: RAFFLE SYSTEM (Student & Admin Routes)
# =============================================================================

# Admin Raffle Management Routes
@app.route('/api/admin/raffles', methods=['GET'])
@login_required
@role_required('admin')
def api_admin_get_raffles():
    """Get all raffles"""
    from sqlalchemy import text
    
    raffles = db.session.execute(text("""
        SELECT r.*, ps.name as school_name,
               (SELECT COUNT(*) FROM raffle_entries WHERE raffle_id = r.id AND is_active = 1) as active_entries
        FROM raffles r
        LEFT JOIN prize_schools ps ON r.school_id = ps.id
        ORDER BY r.created_at DESC
    """)).fetchall()
    
    return jsonify([{
        'id': r.id,
        'name': r.name,
        'description': r.description,
        'prize_description': r.prize_description,
        'emoji': r.emoji,
        'school_name': r.school_name or 'All Schools',
        'entry_cost': r.entry_cost,
        'max_entries_per_student': r.max_entries_per_student,
        'draw_frequency': r.draw_frequency,
        'is_active': bool(r.is_active),
        'auto_draw_enabled': bool(r.auto_draw_enabled),
        'total_entries': r.total_entries,
        'total_draws': r.total_draws,
        'active_entries': r.active_entries
    } for r in raffles])


@app.route('/api/admin/raffles', methods=['POST'])
@login_required
@role_required('admin')
def api_admin_create_raffle():
    """Create raffle"""
    from sqlalchemy import text
    
    data = request.json
    
    try:
        result = db.session.execute(text("""
            INSERT INTO raffles (
                name, description, prize_description, emoji,
                school_id, entry_cost, max_entries_per_student,
                draw_frequency, draw_day_of_week, draw_time,
                prize_type, prize_value,
                is_active, auto_draw_enabled, created_by
            ) VALUES (
                :name, :description, :prize_description, :emoji,
                :school_id, :entry_cost, :max_entries,
                :frequency, :day_of_week, :draw_time,
                :prize_type, :prize_value,
                :is_active, :auto_draw, :created_by
            )
        """), {
            'name': data['name'],
            'description': data.get('description'),
            'prize_description': data['prize_description'],
            'emoji': data.get('emoji', '🎟️'),
            'school_id': data.get('school_id'),
            'entry_cost': data['entry_cost'],
            'max_entries': data.get('max_entries_per_student', 10),
            'frequency': data.get('draw_frequency', 'weekly'),
            'day_of_week': data.get('draw_day_of_week', 5),
            'draw_time': data.get('draw_time', '15:00:00'),
            'prize_type': data.get('prize_type', 'physical'),
            'prize_value': data.get('prize_value'),
            'is_active': data.get('is_active', True),
            'auto_draw': data.get('auto_draw_enabled', True),
            'created_by': session['user_id']
        })
        
        raffle_id = result.lastrowid
        db.session.commit()
        
        return jsonify({'success': True, 'raffle_id': raffle_id})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/api/admin/raffles/<int:raffle_id>/draw', methods=['POST'])
@login_required
@role_required('admin')
def api_admin_manual_draw(raffle_id):
    """Manual draw"""
    draw_id = perform_raffle_draw(raffle_id)
    
    if draw_id:
        return jsonify({'success': True, 'draw_id': draw_id})
    else:
        return jsonify({'error': 'Draw failed'}), 500


# Student Raffle Routes
@app.route('/api/raffles/available')
@login_required
def api_raffles_available():
    """Get available raffles for student"""
    from sqlalchemy import text
    
    user_id = session['user_id']
    school_id = get_user_school_id(user_id)
    
    raffles = db.session.execute(text("""
        SELECT r.*,
               (SELECT COUNT(*) FROM raffle_entries WHERE raffle_id = r.id AND student_id = :user_id AND is_active = 1) as my_entries,
               (SELECT COUNT(DISTINCT student_id) FROM raffle_entries WHERE raffle_id = r.id AND is_active = 1) as total_participants
        FROM raffles r
        WHERE r.is_active = 1
        AND (r.school_id IS NULL OR r.school_id = :school_id)
        ORDER BY r.created_at DESC
    """), {'user_id': user_id, 'school_id': school_id}).fetchall()
    
    return jsonify([{
        'id': r.id,
        'name': r.name,
        'description': r.description,
        'prize_description': r.prize_description,
        'emoji': r.emoji,
        'entry_cost': r.entry_cost,
        'max_entries_per_student': r.max_entries_per_student,
        'draw_frequency': r.draw_frequency,
        'my_entries': r.my_entries,
        'total_participants': r.total_participants
    } for r in raffles])


@app.route('/api/raffles/<int:raffle_id>/enter', methods=['POST'])
@login_required
def api_raffle_enter(raffle_id):
    """Buy raffle entries"""
    from sqlalchemy import text
    
    data = request.json
    num_entries = data.get('entries', 1)
    
    user_id = session['user_id']
    school_id = get_user_school_id(user_id)
    
    if not school_id:
        return jsonify({'error': 'No school assigned'}), 400
    
    try:
        raffle = db.session.execute(text("""
            SELECT * FROM raffles WHERE id = :raffle_id AND is_active = 1
        """), {'raffle_id': raffle_id}).fetchone()
        
        if not raffle:
            return jsonify({'error': 'Raffle not found'}), 404
        
        current = db.session.execute(text("""
            SELECT COALESCE(SUM(entry_count), 0) as total
            FROM raffle_entries
            WHERE raffle_id = :raffle_id AND student_id = :user_id AND is_active = 1
        """), {'raffle_id': raffle_id, 'user_id': user_id}).fetchone()
        
        if current.total + num_entries > raffle.max_entries_per_student:
            return jsonify({'error': f'Max {raffle.max_entries_per_student} entries per student'}), 400
        
        cost = raffle.entry_cost * num_entries
        points = db.session.execute(text("""
            SELECT points FROM users WHERE id = :user_id
        """), {'user_id': user_id}).fetchone()
        
        if points.points < cost:
            return jsonify({'error': 'Not enough points'}), 400
        
        db.session.execute(text("""
            UPDATE users SET points = points - :cost WHERE id = :user_id
        """), {'cost': cost, 'user_id': user_id})
        
        db.session.execute(text("""
            INSERT INTO raffle_entries (
                raffle_id, student_id, school_id, entry_count, points_spent
            ) VALUES (
                :raffle_id, :student_id, :school_id, :entries, :cost
            )
        """), {
            'raffle_id': raffle_id,
            'student_id': user_id,
            'school_id': school_id,
            'entries': num_entries,
            'cost': cost
        })
        
        db.session.execute(text("""
            UPDATE raffles SET total_entries = total_entries + :entries
            WHERE id = :raffle_id
        """), {'entries': num_entries, 'raffle_id': raffle_id})
        
        db.session.commit()
        
        return jsonify({'success': True, 'entries_purchased': num_entries})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/api/raffles/check-wins')
@login_required
def api_check_raffle_wins():
    """Check for unacknowledged wins"""
    from sqlalchemy import text
    
    wins = db.session.execute(text("""
        SELECT wn.*, rd.token, rd.token_expires_at,
               r.name as raffle_name, r.prize_description, r.emoji
        FROM winner_notifications wn
        JOIN raffle_draws rd ON wn.draw_id = rd.id
        JOIN raffles r ON rd.raffle_id = r.id
        WHERE wn.winner_id = :user_id AND wn.acknowledged = 0
    """), {'user_id': session['user_id']}).fetchall()
    
    return jsonify([{
        'id': w.id,
        'draw_id': w.draw_id,
        'raffle_name': w.raffle_name,
        'prize_description': w.prize_description,
        'emoji': w.emoji,
        'token': w.token,
        'expires_at': str(w.token_expires_at),
        'message': w.message
    } for w in wins])


@app.route('/api/raffles/acknowledge-win/<int:notification_id>', methods=['POST'])
@login_required
def api_acknowledge_win(notification_id):
    """Acknowledge winner notification"""
    from sqlalchemy import text
    
    db.session.execute(text("""
        UPDATE winner_notifications
        SET acknowledged = 1, acknowledged_at = CURRENT_TIMESTAMP
        WHERE id = :notification_id AND winner_id = :user_id
    """), {'notification_id': notification_id, 'user_id': session['user_id']})
    
    db.session.commit()
    
    return jsonify({'success': True})


# =============================================================================
# RAFFLE HELPER FUNCTIONS
# =============================================================================

def generate_raffle_token():
    """Generate unique token for raffle prize collection"""
    import secrets
    return secrets.token_urlsafe(12)


def get_user_school_id(user_id):
    """Get the school_id for a student"""
    from sqlalchemy import text
    result = db.session.execute(text("""
        SELECT school_id FROM prize_redemptions 
        WHERE user_id = :user_id 
        LIMIT 1
    """), {'user_id': user_id}).fetchone()
    
    if result:
        return result.school_id
    
    result = db.session.execute(text("""
        SELECT c.school_id 
        FROM class_enrollments ce
        JOIN classes c ON ce.class_id = c.id
        WHERE ce.student_id = :user_id
        LIMIT 1
    """), {'user_id': user_id}).fetchone()
    
    return result.school_id if result else None


def select_raffle_winner(raffle_id, draw_id):
    """Randomly select a winner from active entries"""
    from sqlalchemy import text
    import random
    
    entries = db.session.execute(text("""
        SELECT id, student_id, entry_count
        FROM raffle_entries
        WHERE raffle_id = :raffle_id 
        AND is_active = 1
        AND (draw_id IS NULL OR draw_id = :draw_id)
    """), {'raffle_id': raffle_id, 'draw_id': draw_id}).fetchall()
    
    if not entries:
        return None, None
    
    weighted_entries = []
    for entry in entries:
        for _ in range(entry.entry_count):
            weighted_entries.append((entry.id, entry.student_id))
    
    if weighted_entries:
        winning_entry_id, winner_id = random.choice(weighted_entries)
        return winner_id, winning_entry_id
    
    return None, None


def perform_raffle_draw(raffle_id):
    """Perform a raffle draw"""
    from sqlalchemy import text
    from datetime import datetime, timedelta
    
    try:
        raffle = db.session.execute(text("""
            SELECT * FROM raffles WHERE id = :raffle_id
        """), {'raffle_id': raffle_id}).fetchone()
        
        if not raffle:
            return None
        
        draw_date = datetime.now().date()
        draw_time = datetime.now()
        
        result = db.session.execute(text("""
            INSERT INTO raffle_draws (
                raffle_id, school_id, draw_date, draw_time,
                status, drawn_at, drawn_by
            ) VALUES (
                :raffle_id, :school_id, :draw_date, :draw_time,
                'drawing', CURRENT_TIMESTAMP, 'system'
            )
        """), {
            'raffle_id': raffle_id,
            'school_id': raffle.school_id,
            'draw_date': draw_date,
            'draw_time': draw_time
        })
        
        draw_id = result.lastrowid
        db.session.commit()
        
        winner_id, winning_entry_id = select_raffle_winner(raffle_id, draw_id)
        
        stats = db.session.execute(text("""
            SELECT COUNT(*) as total_entries,
                   COUNT(DISTINCT student_id) as total_participants
            FROM raffle_entries
            WHERE raffle_id = :raffle_id AND is_active = 1
        """), {'raffle_id': raffle_id}).fetchone()
        
        if winner_id:
            token = generate_raffle_token()
            token_expires = draw_time + timedelta(days=7)
            
            db.session.execute(text("""
                UPDATE raffle_draws
                SET winner_id = :winner_id,
                    winning_entry_id = :winning_entry_id,
                    total_entries = :total_entries,
                    total_participants = :total_participants,
                    token = :token,
                    token_expires_at = :token_expires,
                    status = 'drawn'
                WHERE id = :draw_id
            """), {
                'winner_id': winner_id,
                'winning_entry_id': winning_entry_id,
                'total_entries': stats.total_entries,
                'total_participants': stats.total_participants,
                'token': token,
                'token_expires': token_expires,
                'draw_id': draw_id
            })
            
            db.session.execute(text("""
                UPDATE raffle_entries
                SET is_active = 0, draw_id = :draw_id
                WHERE raffle_id = :raffle_id AND is_active = 1
            """), {'draw_id': draw_id, 'raffle_id': raffle_id})
            
            message = f"🎉 Congratulations! You won the {raffle.name}! Prize: {raffle.prize_description}"
            
            db.session.execute(text("""
                INSERT INTO winner_notifications (
                    draw_id, winner_id, notification_type, message
                ) VALUES (
                    :draw_id, :winner_id, 'on_login', :message
                )
            """), {
                'draw_id': draw_id,
                'winner_id': winner_id,
                'message': message
            })
            
            db.session.commit()
            
        else:
            db.session.execute(text("""
                UPDATE raffle_draws
                SET status = 'no_entries',
                    total_entries = 0,
                    total_participants = 0
                WHERE id = :draw_id
            """), {'draw_id': draw_id})
            db.session.commit()
        
        db.session.execute(text("""
            UPDATE raffles
            SET total_draws = total_draws + 1
            WHERE id = :raffle_id
        """), {'raffle_id': raffle_id})
        db.session.commit()
        
        return draw_id
        
    except Exception as e:
        db.session.rollback()
        print(f"Error drawing raffle {raffle_id}: {e}")
        return None


# =============================================================================
# ADMIN USER ANALYTICS & MANAGEMENT ROUTES
# =============================================================================

@app.route('/api/admin/analytics/overview')
@login_required
@role_required('admin')
def admin_analytics_overview():
    """Get overview statistics"""
    from sqlalchemy import text
    
    # Count registered users (exclude guest accounts)
    registered_count = db.session.execute(text("""
        SELECT COUNT(*) 
        FROM users 
        WHERE email NOT LIKE 'guest%@%' 
        AND role = 'student'
    """)).scalar()
    
    # Count repeat guests
    repeat_guests_count = db.session.execute(text("""
        SELECT COUNT(*) FROM guest_users
    """)).scalar() or 0
    
    # Count inactive guests (60+ days)
    sixty_days_ago = datetime.utcnow() - timedelta(days=60)
    inactive_guests = db.session.execute(text("""
        SELECT COUNT(*) 
        FROM guest_users 
        WHERE last_active < :cutoff
    """), {'cutoff': sixty_days_ago}).scalar() or 0
    
    # Count casual sessions today (approximate from guest_sessions if exists)
    try:
        casual_today = db.session.execute(text("""
            SELECT COUNT(*) 
            FROM guest_sessions 
            WHERE DATE(created_at) = DATE('now')
        """)).scalar() or 0
    except:
        casual_today = 0
    
    return jsonify({
        'registered_users': registered_count,
        'repeat_guests': repeat_guests_count,
        'inactive_guests': inactive_guests,
        'casual_sessions_today': casual_today
    })


@app.route('/api/admin/analytics/registered-users')
@login_required
@role_required('admin')
def admin_analytics_registered_users():
    """Get list of all registered users with stats"""
    from sqlalchemy import text
    
    try:
        # Query users with stats joined
        users = db.session.execute(text("""
            SELECT 
                u.id,
                u.email,
                u.full_name,
                u.created_at,
                COALESCE(us.total_points, 0) as points,
                us.updated_at as last_active
            FROM users u
            LEFT JOIN user_stats us ON u.id = us.user_id
            WHERE u.email NOT LIKE 'guest%@%'
            AND u.role = 'student'
            ORDER BY u.created_at DESC
        """)).fetchall()
        
        result = []
        now = datetime.utcnow()
        
        for row in users:
            # Access by index: 0=id, 1=email, 2=full_name, 3=created_at, 4=points, 5=last_active
            user_id = row[0]
            email = row[1]
            full_name = row[2] if row[2] else 'Unknown'
            created_at = row[3]
            points = row[4] if row[4] else 0
            last_active = row[5] if row[5] else created_at
            
            days_inactive = (now - last_active).days if last_active else 999
            
            # Determine activity status
            if days_inactive < 7:
                activity_status = 'active'
                activity_label = 'Active'
            elif days_inactive < 30:
                activity_status = 'stale'
                activity_label = 'Inactive'
            else:
                activity_status = 'inactive'
                activity_label = f'{days_inactive}d ago'
            
            result.append({
                'id': user_id,
                'email': email,
                'full_name': full_name,
                'points': points,
                'quizzes': 0,
                'last_active': last_active.isoformat() if last_active else None,
                'activity_status': activity_status,
                'activity_label': activity_label
            })
        
        return jsonify(result)
    except Exception as e:
        import traceback
        print(f"Error in registered-users: {str(e)}")
        print(traceback.format_exc())
        return jsonify([])  # Return empty array instead of error object


@app.route('/api/admin/analytics/repeat-guests')
@login_required
@role_required('admin')
def admin_analytics_repeat_guests():
    """Get list of all repeat guests with stats"""
    from sqlalchemy import text
    
    try:
        # Query with explicit column order
        guests = db.session.execute(text("""
            SELECT 
                guest_code,
                total_score,
                created_at,
                last_active
            FROM guest_users
            ORDER BY last_active DESC
        """)).fetchall()
        
        result = []
        now = datetime.utcnow()
        
        for row in guests:
            # Access by index: 0=guest_code, 1=total_score, 2=created_at, 3=last_active
            guest_code = row[0]
            total_score = row[1] if row[1] else 0
            created_at = row[2]
            last_active = row[3]
            
            days_inactive = (now - last_active).days if last_active else 999
            
            # Determine activity status
            if days_inactive < 7:
                activity_status = 'active'
                activity_label = 'Active'
            elif days_inactive < 60:
                activity_status = 'stale'
                activity_label = f'{days_inactive}d ago'
            else:
                activity_status = 'inactive'
                activity_label = f'Inactive {days_inactive}d'
            
            result.append({
                'guest_code': guest_code,
                'nickname': None,
                'total_score': total_score,
                'quizzes_completed': 0,
                'created_at': created_at.isoformat() if created_at else None,
                'last_active': last_active.isoformat() if last_active else None,
                'days_inactive': days_inactive,
                'activity_status': activity_status,
                'activity_label': activity_label
            })
        
        return jsonify(result)
    except Exception as e:
        import traceback
        print(f"Error in repeat-guests: {str(e)}")
        print(traceback.format_exc())
        return jsonify([])  # Return empty array instead of error object


@app.route('/api/admin/analytics/inactive-users')
@login_required
@role_required('admin')
def admin_analytics_inactive_users():
    """Get list of inactive users (60+ days)"""
    from sqlalchemy import text
    
    try:
        sixty_days_ago = datetime.utcnow() - timedelta(days=60)
        
        # Get inactive repeat guests
        inactive_guests = db.session.execute(text("""
            SELECT 
                guest_code,
                last_active,
                total_score
            FROM guest_users
            WHERE last_active < :cutoff
            ORDER BY last_active ASC
        """), {'cutoff': sixty_days_ago}).fetchall()
        
        result = []
        now = datetime.utcnow()
        
        for row in inactive_guests:
            # Access by index: 0=guest_code, 1=last_active, 2=total_score
            guest_code = row[0]
            last_active = row[1]
            points = row[2] if row[2] else 0
            
            days_inactive = (now - last_active).days if last_active else 999
            
            result.append({
                'type': 'Guest',
                'identifier': guest_code,
                'last_active': last_active.isoformat() if last_active else None,
                'days_inactive': days_inactive,
                'points': points
            })
        
        return jsonify(result)
    except Exception as e:
        import traceback
        print(f"Error in inactive-users: {str(e)}")
        print(traceback.format_exc())
        return jsonify([])  # Return empty array instead of error object


@app.route('/api/admin/analytics/user-detail')
@login_required
@role_required('admin')
def admin_analytics_user_detail():
    """Get detailed info about a specific user"""
    from sqlalchemy import text
    
    user_type = request.args.get('type')
    user_id = request.args.get('id')
    
    if user_type == 'registered':
        # Get registered user details
        user = User.query.get(user_id)
        stats = UserStats.query.filter_by(user_id=user_id).first()
        
        # Get recent activity
        recent_attempts = db.session.execute(text("""
            SELECT topic, difficulty, score, total_questions, completed_at
            FROM quiz_attempts
            WHERE user_id = :user_id
            ORDER BY completed_at DESC
            LIMIT 10
        """), {'user_id': user_id}).fetchall()
        
        recent_activity_html = '<ul>' + ''.join([
            f'<li>{att.topic} ({att.difficulty}): {att.score}/{att.total_questions} - {att.completed_at.strftime("%Y-%m-%d")}</li>'
            for att in recent_attempts
        ]) + '</ul>' if recent_attempts else '<p>No recent activity</p>'
        
        return jsonify({
            'full_name': user.full_name,
            'email': user.email,
            'role': user.role,
            'points': stats.total_points if stats else 0,
            'level': stats.level if stats else 1,
            'quizzes': stats.total_quizzes if stats else 0,
            'accuracy': round((stats.total_correct_answers / stats.total_questions_answered * 100), 1) if stats and stats.total_questions_answered > 0 else 0,
            'streak': stats.current_streak_days if stats else 0,
            'recent_activity': recent_activity_html
        })
    
    else:  # guest
        try:
            # Get guest details
            guest = db.session.execute(text("""
                SELECT 
                    guest_code,
                    total_score,
                    created_at,
                    last_active
                FROM guest_users WHERE guest_code = :code
            """), {'code': user_id}).fetchone()
            
            if not guest:
                return jsonify({'error': 'Guest not found'}), 404
            
            # Access by index: 0=guest_code, 1=total_score, 2=created_at, 3=last_active
            guest_code = guest[0]
            total_score = guest[1] if guest[1] else 0
            created_at = guest[2]
            last_active = guest[3]
            
            # Get recent quizzes
            try:
                recent_quizzes = db.session.execute(text("""
                    SELECT topic, difficulty, score, total_questions, completed_at
                    FROM guest_quiz_attempts
                    WHERE guest_code = :code
                    ORDER BY completed_at DESC
                    LIMIT 10
                """), {'code': user_id}).fetchall()
                
                recent_quizzes_html = '<ul>' + ''.join([
                    f'<li>{q[0]} ({q[1]}): {q[2]}/{q[3]}</li>'
                    for q in recent_quizzes
                ]) + '</ul>' if recent_quizzes else '<p>No quizzes yet</p>'
            except:
                recent_quizzes_html = '<p>No quiz data available</p>'
            
            now = datetime.utcnow()
            days_old = (now - created_at).days if created_at else 0
            days_inactive = (now - last_active).days if last_active else 999
            
            return jsonify({
                'guest_code': guest_code,
                'nickname': None,
                'total_score': total_score,
                'quizzes_completed': 0,
                'days_old': days_old,
                'days_inactive': days_inactive,
                'recent_quizzes': recent_quizzes_html
            })
        except Exception as e:
            import traceback
            print(f"Error in user-detail guest: {str(e)}")
            print(traceback.format_exc())
            return jsonify({'error': str(e)}), 500


@app.route('/api/admin/analytics/recycle-guest', methods=['POST'])
@login_required
@role_required('admin')
def admin_analytics_recycle_guest():
    """Manually recycle a guest code (delete all data)"""
    from sqlalchemy import text
    
    data = request.json
    guest_code = data.get('guest_code')
    
    try:
        # Delete guest quiz attempts
        db.session.execute(text("""
            DELETE FROM guest_quiz_attempts WHERE guest_code = :code
        """), {'code': guest_code})
        
        # Delete guest badges
        try:
            db.session.execute(text("""
                DELETE FROM guest_badges WHERE guest_code = :code
            """), {'code': guest_code})
        except:
            pass  # Table might not exist
        
        # Delete guest user record
        db.session.execute(text("""
            DELETE FROM guest_users WHERE guest_code = :code
        """), {'code': guest_code})
        
        db.session.commit()
        
        return jsonify({'success': True, 'message': f'Guest code {guest_code} recycled'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/admin/analytics/run-cleanup', methods=['POST'])
@login_required
@role_required('admin')
def admin_analytics_run_cleanup():
    """Run cleanup process now"""
    from sqlalchemy import text
    
    # Get cleanup threshold from settings (default 60 days)
    cleanup_days = int(SystemSetting.get('cleanup_days_threshold', '60'))
    cutoff_date = datetime.utcnow() - timedelta(days=cleanup_days)
    
    # Find inactive guest codes
    inactive_codes = db.session.execute(text("""
        SELECT guest_code 
        FROM guest_users 
        WHERE last_active < :cutoff
    """), {'cutoff': cutoff_date}).fetchall()
    
    recycled_count = 0
    
    for row in inactive_codes:
        guest_code = row.guest_code
        
        try:
            # Delete all related data
            db.session.execute(text("""
                DELETE FROM guest_quiz_attempts WHERE guest_code = :code
            """), {'code': guest_code})
            
            try:
                db.session.execute(text("""
                    DELETE FROM guest_badges WHERE guest_code = :code
                """), {'code': guest_code})
            except:
                pass
            
            db.session.execute(text("""
                DELETE FROM guest_users WHERE guest_code = :code
            """), {'code': guest_code})
            
            recycled_count += 1
        except Exception as e:
            print(f"Error recycling {guest_code}: {e}")
            continue
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'recycled_count': recycled_count,
        'message': f'Recycled {recycled_count} inactive guest codes'
    })


@app.route('/api/admin/analytics/cleanup-settings', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def admin_analytics_cleanup_settings():
    """Get or update cleanup settings"""
    
    if request.method == 'GET':
        return jsonify({
            'days_threshold': int(SystemSetting.get('cleanup_days_threshold', '60')),
            'auto_enabled': SystemSetting.get('auto_cleanup_enabled', 'false') == 'true'
        })
    
    else:  # POST
        data = request.json
        user_id = session.get('user_id')
        
        SystemSetting.set(
            'cleanup_days_threshold',
            str(data.get('days_threshold', 60)),
            'Days of inactivity before guest code cleanup',
            user_id
        )
        
        SystemSetting.set(
            'auto_cleanup_enabled',
            'true' if data.get('auto_enabled') else 'false',
            'Enable automatic daily cleanup',
            user_id
        )
        
        return jsonify({'success': True})


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
